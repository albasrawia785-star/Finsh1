export type SubscriptionType = 'permanent' | 'local_permanent' | 'monthly' | 'trial';
export type ManagerModuleAccess = 'both' | 'debts' | 'installments';

export type AppLayoutTheme =
  | 'classic'
  | 'fintech'
  | 'bento'
  | 'ledger'
  | 'minimal_luxury'
  | 'floating_glass'
  | 'compact_dense'
  | 'timeline'
  | 'retail_modern'
  | 'studio_analytics';

export interface DatabaseAccount {
  id: string;
  name: string;
  url: string;
  token: string;
  description?: string;
  isDefault?: boolean;
  createdAt?: string;
}

export interface User {
  id: number;
  username: string;
  role: 'admin' | 'manager' | string;
  branch_name: string;
  phoneOrEmail?: string;
  password?: string;
  isActive?: boolean;
  isNewRegistration?: boolean;
  subscriptionType?: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  allowedModules?: ManagerModuleAccess;
  layoutTheme?: AppLayoutTheme;
  databaseId?: string | null;
  birthYear?: string;
  birthDate?: string;
  securityAnswer?: string;
  createdAt?: string;
}

export interface DebtorTransaction {
  id: string;
  debtorId: number;
  type: 'initial' | 'add' | 'pay';
  amount: number;
  balanceAfter: number;
  date: string;
  description?: string;
  notes?: string;
}

export interface Debtor {
  id: number;
  name: string;
  phone: string;
  amount: number;
  status: string;
  userId: number;
  createdAt?: string;
  lastDebtDate?: string;
  notes?: string;
  history?: DebtorTransaction[];
  isDemo?: boolean;
  type?: 'debtor' | 'creditor';
}

// ----------------------------------------------------
// نظام الأقساط المنفصل (Independent Installments System)
// ----------------------------------------------------

export interface InstallmentPayment {
  id: string;
  installmentId: number;
  amount: number;
  date: string; // YYYY-MM-DD or ISO
  remainingAfter: number;
  notes?: string;
}

export type InstallmentStatus = 'active' | 'due' | 'overdue' | 'completed';

export interface InstallmentRecord {
  id: number;
  name: string;              // 1. الاسم
  phone: string;             // 2. رقم الهاتف (11 رقم)
  item: string;              // 3. السلعة
  totalAmount: number;       // 4. مبلغ الأقساط (الإجمالي)
  downPayment: number;       // 5. الدفعة المقدمة
  remainingAmount: number;   // المتبقي = الإجمالي - المقدمة - مجموع التسديدات
  monthlyInstallmentAmount?: number; // القسط الشهري المتفق عليه (اختياري/افتراضي)
  registrationDate: string;  // 6. تاريخ التسجيل (YYYY-MM-DD)
  nextDueDate: string;       // تاريخ الاستحقاق القادم (بعد شهر من التسجيل أو من آخر دفعة)
  userId: number;            // معرف المستخدم / الفرع
  status: InstallmentStatus; // 'active' | 'due' | 'overdue' | 'completed'
  nationalId?: string;       // البطاقة الوطنية (اختياري - 12 رقم)
  address?: string;          // عنوان السكن وأقرب نقطة دالة
  guarantorEnabled?: boolean;// هل تم تفعيل بيانات الكفيل
  guarantorName?: string;    // اسم الكفيل
  guarantorAddress?: string; // عنوان الكفيل
  guarantorJob?: string;     // مهنة الكفيل
  guarantorRelation?: string;// صلة القرابة بينه وبين صاحب الأقساط
  guarantorPhone?: string;   // رقم هاتف الكفيل (11 رقم)
  notes?: string;
  payments?: InstallmentPayment[];
  createdAt?: string;
  isDemo?: boolean;
}

export interface Manager {
  id: number;
  username: string;
  branch: string;
  phoneOrEmail?: string;
  isActive: boolean;
  isNewRegistration?: boolean;
  subscriptionType: SubscriptionType;
  subscriptionExpiresAt?: string | null;
  allowedModules?: ManagerModuleAccess;
  layoutTheme?: AppLayoutTheme;
  databaseId?: string | null;
  createdAt?: string;
  plainPassword?: string;
  securityAnswer?: string;
  birthDate?: string;
}

export type TabType = 'home' | 'installments' | 'reports' | 'overdue' | 'settings' | 'managers';

export type FilterType = 'all' | 'debtors_only' | 'paid_only' | 'high_debt' | 'debts_on_me' | 'debts_on_me_paid';

export type InstallmentFilterType = 'all' | 'due_and_overdue' | 'due' | 'overdue' | 'active' | 'completed';

export type ViewMode = 'cards' | 'list';

export interface OutboxAction {
  id: string;
  userId: number;
  type:
    | 'ADD_DEBTOR'
    | 'UPDATE_DEBTOR'
    | 'TRANSACTION_DEBT'
    | 'DELETE_DEBTOR'
    | 'ADD_INSTALLMENT'
    | 'UPDATE_INSTALLMENT'
    | 'SETTLE_INSTALLMENT_PAYMENT'
    | 'DELETE_INSTALLMENT'
    | 'ADD_SUPPLIER'
    | 'UPDATE_SUPPLIER'
    | 'TRANSACTION_SUPPLIER'
    | 'DELETE_SUPPLIER';
  payload: any;
  timestamp: number;
}

export interface DebtStats {
  totalAdded: number;
  totalPaid: number;
}

export type Language = 'ar' | 'ku';
export type Currency = 'IQD';
export type NumberFormat = 'english' | 'arabic';
export type AppFontSize = 'small' | 'default' | 'medium' | 'large' | 'xlarge';

export interface AppSettings {
  enableDebtAlerts: boolean;
  alertDaysThreshold: number; // e.g. 1, 2, 7 days
  highDebtThreshold: number; // e.g. 25000 IQD
  numberFormat?: NumberFormat; // 'english' (123) or 'arabic' (١٢٣)
  language?: Language; // 'ar' | 'ku'
  currency?: Currency; // 'IQD'
  layoutTheme?: AppLayoutTheme; // 'classic' | 'fintech' | 'bento' | 'ledger' | 'minimal_luxury' | 'floating_glass' | 'compact_dense' | 'timeline' | 'retail_modern' | 'studio_analytics'
  fontSize?: AppFontSize; // 'small' | 'default' | 'medium' | 'large' | 'xlarge'
  enableUpdateNotice?: boolean;
  updateNoticeMessage?: string;
  updateNoticeTargetVersion?: string; // e.g. 'v3.5'
  updateNoticeTargetUser?: string; // 'all' or specific manager username/id
}

export interface SupplierTransaction {
  id: string;
  supplierId?: number;
  type: 'debt' | 'pay' | 'initial' | 'add_debt' | 'pay_supplier';
  amount: number;
  balanceAfter?: number;
  date: string;
  notes?: string;
  description?: string;
  itemType?: string;
  performedBy?: string;
  managerName?: string;
}

export interface Supplier {
  id: number;
  name: string;
  companyName?: string;
  phone?: string;
  notes?: string;
  totalDebt?: number;
  totalPaid?: number;
  amount?: number;
  createdAt?: string;
  updatedAt?: string;
  history?: SupplierTransaction[];
  userId?: number;
  itemType?: string;
  status?: string;
  lastTransactionDate?: string;
  isDemo?: boolean;
}


