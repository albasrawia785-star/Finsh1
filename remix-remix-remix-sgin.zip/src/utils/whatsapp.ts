import { Debtor, InstallmentRecord } from '../types';

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // Handle 00964...
  if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  }

  // If starts with 07..., convert to 9647...
  if (cleaned.startsWith('07')) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.length === 10 && cleaned.startsWith('7')) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp API URL for sending a message
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  const encodedText = encodeURIComponent(message);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Directly opens WhatsApp without any intermediate UI
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const formattedPhone = formatPhoneNumberForWhatsApp(phone);
    if (!formattedPhone) return false;
    const url = getWhatsAppUrl(phone, message);

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 200);
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp directly:', err);
    try {
      const url = getWhatsAppUrl(phone, message);
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * 1. عند إضافة عميل مدين جديد (New Debtor)
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالجهة / الشركة: ${dComp.trim()}`
    : '';

  const notesStr = debtor.notes && debtor.notes.trim() ? debtor.notes.trim() : '';

  const message = `إشعار تقييد حساب مدين

السيد/ ${debtor.name}${companyLine}
تحية طيبة وبعد،

نود إشعاركم بأنه تم فتح وتقييد حساب مالي بذمتكم في السجلات وفق البيانات التالية:

• المبلغ المقيد: ${formattedAmount} ${currencySymbol}
• تاريخ القيد: ${dateStr}
• إجمالي الرصيد القائم بذمتكم: ${formattedAmount} ${currencySymbol}
${notesStr ? `• البيان / الملاحظات: ${notesStr}\n` : ''}
شاكرين لكم حسن التعاون.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار تقييد حساب مدين',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين إضافي لعميل مدين (Add Debt)
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAdded = addedAmount.toLocaleString('en-US');
  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالجهة / الشركة: ${dComp.trim()}`
    : '';

  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `إشعار تقييد مبلغ إضافي

السيد/ ${debtor.name}${companyLine}
تحية طيبة وبعد،

تم تقييد مبلغ مالي إضافي بذمتكم في السجلات وتحديث رصيد الحساب كالتالي:

• المبلغ المضاف: ${formattedAdded} ${currencySymbol}
• تاريخ القيد: ${dateStr}
• إجمالي الرصيد القائم بذمتكم: ${formattedTotal} ${currencySymbol}
${notesStr ? `• البيان / الملاحظات: ${notesStr}\n` : ''}
شاكرين لكم حسن التعاون.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار تقييد مبلغ إضافي',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دفعة من عميل مدين (Pay Debt - سند قبض)
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالجهة / الشركة: ${dComp.trim()}`
    : '';

  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `سند قبض دفعة مالية

السيد/ ${debtor.name}${companyLine}
تحية طيبة وبعد،

تم استلام وقيد دفعة مالية لحساب الدين القائم بذمتكم وفق التفاصيل التالية:

• المبلغ المقبوض: ${formattedPaid} ${currencySymbol}
• تاريخ الاستلام: ${dateStr}
• الرصيد المتبقي بذمتكم: ${formattedRemaining} ${currencySymbol}
${notesStr ? `• البيان / الملاحظات: ${notesStr}\n` : ''}
شاكرين لكم التزامكم وحسن تعاونكم.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'سند قبض دفعة مالية',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment)
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}
شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment)
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `المتبقي الكلي: ${formattedRemaining} ${currencySymbol}\nموعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}

/**
 * 6. عند تسجيل دائن جديد في دفتر الديون (الذين يطلبوني)
 */
export function createNewSupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const dateStr = new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `إشعار حساب دائن
السيد/ ${supplierName}${companyLine}

تم تسجيل مبلغ مستحق لكم بذمتنا، وفق التفاصيل التالية:

• المبلغ المقيد: ${formattedAmount} ${currencySymbol}
• تاريخ القيد: ${dateStr}
• إجمالي المستحق لكم: ${formattedAmount} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار حساب دائن',
    message,
    url,
  };
}

/**
 * 6.b. عند إضافة دين جديد للدائن (قيد مالي إضافي)
 */
export function createAddSupplierDebtWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  addedAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  notes?: string,
  _itemType?: string,
  txDate?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAdded = Number(addedAmount || 0).toLocaleString('en-US');
  const formattedTotal = Number(newRemainingAmount || 0).toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `السيد/ ${supplierName}${companyLine}
إشعار إضافة مبلغ

تم تسجيل مبلغ مستحق لكم بذمتنا:

• المبلغ المضاف: ${formattedAdded} ${currencySymbol}
• التاريخ: ${dateStr}
• إجمالي المستحق لكم: ${formattedTotal} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار إضافة مبلغ',
    message,
    url,
  };
}

/**
 * 7. عند تسديد دفعة مالية للدائن
 */
export function createPaySupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  paidAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  _itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemainingAmount.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : '';

  const message = `السيد/ ${supplierName}${companyLine}
إشعار تسديد

تم تسجيل تسديد مبلغ من حسابكم:

• المبلغ المسدد: ${formattedPaid} ${currencySymbol}
• التاريخ: ${dateStr}
• المتبقي لكم: ${formattedRemaining} ${currencySymbol}${notesStr ? `\n• الملاحظات: ${notesStr}` : ''}

شكرًا لتعاونكم.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار تسديد',
    message,
    url,
  };
}

/**
 * 8. تذكير أو مطابقة رصيد حساب دائن
 */
export function createSupplierReminderWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  _itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const companyLine = companyName && companyName.trim() ? `\nالجهة / الشركة: ${companyName.trim()}` : '';

  const message = `إشعار مطابقة رصيد حساب دائن

السيد/ ${supplierName}${companyLine}
تحية طيبة وبعد،

نود إشعاركم بمطابقة رصيد حسابكم المالي المسجل لدينا:

• إجمالي الرصيد المستحق لكم: ${formattedAmount} ${currencySymbol}

شاكرين لكم حسن التعاون.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار مطابقة رصيد دائن',
    message,
    url,
  };
}
