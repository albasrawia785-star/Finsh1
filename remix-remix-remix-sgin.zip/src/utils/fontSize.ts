import { AppFontSize } from '../types';

export interface FontSizeOption {
  id: AppFontSize;
  title: string;
  badge: string;
  scalePercent: string;
  description: string;
  previewText: string;
  icon: string;
}

export const FONT_SIZE_OPTIONS: FontSizeOption[] = [
  {
    id: 'small',
    title: 'صغير (مدمج)',
    badge: '90%',
    scalePercent: '90%',
    description: 'عرض بيانات أكثر على الشاشة ومناسب للشاشات الصغيرة لتوفير المساحة.',
    previewText: 'علي حسين البصري • 150,000 د.ع',
    icon: 'fa-solid fa-text-slash',
  },
  {
    id: 'default',
    title: 'قياسي (افتراضي)',
    badge: '100%',
    scalePercent: '100%',
    description: 'الحجم القياسي المصمم بدقة للتطبيق، متوازن ومثالي لجميع الاستخدامات.',
    previewText: 'علي حسين البصري • 150,000 د.ع',
    icon: 'fa-solid fa-font',
  },
  {
    id: 'medium',
    title: 'متوسط (مريح)',
    badge: '110%',
    scalePercent: '110%',
    description: 'خط أكبر قليلاً لقراءة مريحة وسريعة للمبالغ والأسماء دون إجهاد العين.',
    previewText: 'علي حسين البصري • 150,000 د.ع',
    icon: 'fa-solid fa-text-height',
  },
  {
    id: 'large',
    title: 'كبير (واضح)',
    badge: '120%',
    scalePercent: '120%',
    description: 'نصوص واضحة ومقروءة جداً مع الحفاظ التام على أبعاد البطاقات والجداول.',
    previewText: 'علي حسين البصري • 150,000 د.ع',
    icon: 'fa-solid fa-magnifying-glass-plus',
  },
  {
    id: 'xlarge',
    title: 'كبير جداً (فائق الوضوح)',
    badge: '130%',
    scalePercent: '130%',
    description: 'أقصى درجة وضوح وتكبير لقراءة فورية وسلسة للأرقام والأسماء.',
    previewText: 'علي حسين البصري • 150,000 د.ع',
    icon: 'fa-solid fa-eye',
  },
];

const STORAGE_KEY = 'aldion_app_font_size';

export function getStoredFontSize(): AppFontSize {
  try {
    const saved = localStorage.getItem(STORAGE_KEY) as AppFontSize;
    if (saved && ['small', 'default', 'medium', 'large', 'xlarge'].includes(saved)) {
      return saved;
    }
  } catch {}
  return 'default';
}

export function applyAppFontSize(size: AppFontSize) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  
  // Set data-font-size attribute for CSS root scaling
  root.setAttribute('data-font-size', size);
  
  // Apply CSS variable for granular component adjustments
  const scaleMap: Record<AppFontSize, string> = {
    small: '0.90',
    default: '1.0',
    medium: '1.10',
    large: '1.20',
    xlarge: '1.30',
  };
  
  const pxMap: Record<AppFontSize, string> = {
    small: '14.4px',
    default: '16px',
    medium: '17.6px',
    large: '19.2px',
    xlarge: '20.8px',
  };

  root.style.setProperty('--app-font-scale', scaleMap[size] || '1.0');
  root.style.fontSize = pxMap[size] || '16px';

  try {
    localStorage.setItem(STORAGE_KEY, size);
  } catch {}
}
