import { getUserBranchDisplayName, getUserDisplayName } from './userUtils';
import { formatNumber, formatDateDigits } from './formatters';
import { Debtor, Supplier, InstallmentRecord, User } from '../types';

interface PrintReportHeaderOptions {
  title: string;
  subtitle: string;
  branchName: string;
  userName: string;
  periodLabel?: string;
  statsSummaryHtml?: string;
  accentColor?: string; // 'blue' | 'rose' | 'emerald' | 'amber' | 'purple'
}

export function printSystemPdfReport(
  options: PrintReportHeaderOptions,
  tableSectionsHtml: string
) {
  const { title, subtitle, branchName, userName, periodLabel, statsSummaryHtml, accentColor = 'blue' } = options;

  let headerGradient = 'linear-gradient(135deg, #1e293b, #0f172a)';
  let accentBadgeBg = '#3b82f6';
  let primaryColor = '#1e3a8a';

  if (accentColor === 'rose') {
    headerGradient = 'linear-gradient(135deg, #9f1239, #881337)';
    accentBadgeBg = '#e11d48';
    primaryColor = '#881337';
  } else if (accentColor === 'emerald') {
    headerGradient = 'linear-gradient(135deg, #065f46, #064e3b)';
    accentBadgeBg = '#10b981';
    primaryColor = '#064e3b';
  } else if (accentColor === 'amber') {
    headerGradient = 'linear-gradient(135deg, #78350f, #451a03)';
    accentBadgeBg = '#d97706';
    primaryColor = '#78350f';
  } else if (accentColor === 'purple') {
    headerGradient = 'linear-gradient(135deg, #581c87, #3b0764)';
    accentBadgeBg = '#8b5cf6';
    primaryColor = '#3b0764';
  }

  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const dateStr = `${year}/${month}/${day}`;
  
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const timeStr = `${hours}:${minutes}`;

  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('يرجى السماح بالنوافذ المنبثقة للتمكن من طباعة وتصدير الـ PDF');
    return;
  }

  const htmlContent = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8" />
  <title>${title} - ${branchName}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
    
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    
    body {
      font-family: 'Cairo', 'Segoe UI', Tahoma, sans-serif;
      background-color: #ffffff;
      color: #1e293b;
      padding: 20px;
      direction: rtl;
      font-size: 11pt;
      line-height: 1.5;
    }

    .report-header {
      background: ${headerGradient};
      color: #ffffff;
      padding: 20px 24px;
      border-radius: 16px;
      margin-bottom: 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .header-title-box h1 {
      font-size: 18pt;
      font-weight: 900;
      margin-bottom: 4px;
      letter-spacing: -0.5px;
    }

    .header-title-box p {
      font-size: 10pt;
      opacity: 0.85;
      font-weight: 600;
    }

    .meta-badge {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(8px);
      padding: 8px 16px;
      border-radius: 12px;
      text-align: left;
      border: 1px solid rgba(255,255,255,0.2);
    }

    .meta-badge .branch {
      font-size: 11pt;
      font-weight: 800;
      color: #ffffff;
    }

    .meta-badge .date {
      font-size: 8.5pt;
      opacity: 0.85;
      margin-top: 2px;
    }

    .stats-container {
      margin-bottom: 20px;
    }

    /* Cards / Tables styling */
    .person-card {
      background: #ffffff;
      border: 1.5px solid #e2e8f0;
      border-radius: 14px;
      margin-bottom: 18px;
      page-break-inside: avoid;
      overflow: hidden;
    }

    .person-card-header {
      background-color: #f8fafc;
      padding: 12px 16px;
      border-bottom: 1.5px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .person-name {
      font-size: 12pt;
      font-weight: 800;
      color: #0f172a;
    }

    .person-phone {
      font-size: 9.5pt;
      color: #64748b;
      font-weight: 600;
      margin-top: 2px;
    }

    .person-amount-box {
      text-align: left;
    }

    .amount-value {
      font-size: 13pt;
      font-weight: 900;
      color: ${primaryColor};
      direction: ltr;
      display: inline-block;
    }

    .amount-label {
      font-size: 8pt;
      color: #64748b;
      font-weight: 700;
      display: block;
    }

    table.tx-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 9.5pt;
    }

    table.tx-table th {
      background-color: #f1f5f9;
      color: #334155;
      font-weight: 800;
      padding: 8px 12px;
      text-align: right;
      border-bottom: 1px solid #cbd5e1;
      font-size: 9pt;
    }

    table.tx-table td {
      padding: 8px 12px;
      border-bottom: 1px solid #e2e8f0;
      color: #1e293b;
      vertical-align: middle;
    }

    table.tx-table tr:nth-child(even) {
      background-color: #fafafa;
    }

    .tx-type-add {
      color: #dc2626;
      font-weight: 800;
      background: #fef2f2;
      padding: 2px 8px;
      border-radius: 6px;
      display: inline-block;
      font-size: 8.5pt;
    }

    .tx-type-pay {
      color: #16a34a;
      font-weight: 800;
      background: #f0fdf4;
      padding: 2px 8px;
      border-radius: 6px;
      display: inline-block;
      font-size: 8.5pt;
    }

    .tx-type-info {
      color: #2563eb;
      font-weight: 800;
      background: #eff6ff;
      padding: 2px 8px;
      border-radius: 6px;
      display: inline-block;
      font-size: 8.5pt;
    }

    .no-history {
      padding: 12px;
      text-align: center;
      color: #94a3b8;
      font-size: 9pt;
      font-style: italic;
    }

    .report-footer {
      margin-top: 30px;
      padding-top: 12px;
      border-top: 2px solid #e2e8f0;
      display: flex;
      justify-content: space-between;
      align-items: center;
      font-size: 8.5pt;
      color: #64748b;
      font-weight: 600;
    }

    @media print {
      body {
        padding: 0;
      }
      .report-header {
        border-radius: 0;
      }
      .no-print {
        display: none !important;
      }
      @page {
        size: A4 portrait;
        margin: 12mm 10mm;
      }
    }
  </style>
</head>
<body>

  <div class="no-print" style="margin-bottom: 15px; text-align: left;">
    <button onclick="window.print()" style="background-color: ${accentBadgeBg}; color: #ffffff; border: none; padding: 10px 22px; font-family: inherit; font-size: 11pt; font-weight: 800; border-radius: 10px; cursor: pointer; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
      🖨️ حفظ وتصدير PDF / طباعة التقرير
    </button>
  </div>

  <div class="report-header">
    <div class="header-title-box">
      <h1>${title}</h1>
      <p>${subtitle} ${periodLabel ? `(${periodLabel})` : ''}</p>
    </div>
    <div class="meta-badge">
      <div class="branch">فرع: ${branchName}</div>
      <div class="date">${dateStr} - ${timeStr}</div>
      <div class="date" style="opacity: 0.75;">المستخدم: ${userName}</div>
    </div>
  </div>

  ${statsSummaryHtml ? `<div class="stats-container">${statsSummaryHtml}</div>` : ''}

  <div class="report-content">
    ${tableSectionsHtml}
  </div>

  <div class="report-footer">
    <div>تم استخراج هذا التقرير التفصيلي آلياً بواسطة تطبيق دفتر الديون للأعمال</div>
    <div>الصفحة 1 من 1</div>
  </div>

  <script>
    window.onload = function() {
      setTimeout(function() {
        window.print();
      }, 500);
    };
  </script>
</body>
</html>`;

  printWindow.document.open();
  printWindow.document.write(htmlContent);
  printWindow.document.close();
}

export function exportSingleDebtorPdf(
  debtor: Debtor,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const isCreditor = debtor.type === 'creditor';
  const reportTitle = isCreditor ? `كشف حساب دائن (التزام مالي) - ${debtor.name}` : `كشف حساب زبون (مدين) - ${debtor.name}`;
  const accentColor = isCreditor ? 'rose' : 'blue';

  const cleanCreatedAt = debtor.createdAt ? debtor.createdAt.split('T')[0].replace(/-/g, '/') : '-';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: ${isCreditor ? '#fff1f2' : '#eff6ff'}; border: 1px solid ${isCreditor ? '#fecdd3' : '#bfdbfe'}; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: ${isCreditor ? '#881337' : '#1e3a8a'}; font-weight: 700;">الرصيد المالي القائم</span>
      <div style="font-size: 14pt; font-weight: 900; color: ${isCreditor ? '#be123c' : '#1d4ed8'};">${formatNumber(debtor.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #475569; font-weight: 700;">تاريخ فتح الحساب والتسجيل</span>
      <div style="font-size: 12pt; font-weight: 800; color: #334155;">${cleanCreatedAt}</div>
    </div>
  </div>`;

  const rawHistory = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial' as const,
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتسجيل الرصيد الأولي',
        },
      ];

  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد حركات تسديد أو إضافة مسجلة لهذا الحساب</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay';
      const isInitial = tx.type === 'initial';
      const typeLabel = isPay ? 'تسديد دفعة' : isInitial ? 'رصيد افتتاحي' : (isCreditor ? 'دين عليّ إضافي' : 'دين جديد');
      const typeClass = isPay ? 'tx-type-pay' : isInitial ? 'tx-type-info' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const cleanPhone = debtor.phone ? debtor.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${debtor.name}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(debtor.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد القائم</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: reportTitle,
      subtitle: `رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor,
    },
    htmlSection
  );
}

export function exportSingleSupplierPdf(
  supplier: Supplier,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanCreatedAt = supplier.createdAt ? supplier.createdAt.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = supplier.phone ? supplier.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: #fffbe3; border: 1px solid #fef08a; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #713f12; font-weight: 700;">المستحق القائم للمورد</span>
      <div style="font-size: 14pt; font-weight: 900; color: #a16207;">${formatNumber(supplier.amount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #475569; font-weight: 700;">نوع البضائع / الشركة</span>
      <div style="font-size: 12pt; font-weight: 800; color: #334155;">${supplier.companyName || supplier.itemType || 'غير محدد'}</div>
    </div>
  </div>`;

  const history = supplier.history || [];
  const sortedHistory = [...history].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  let txRows = '';
  if (sortedHistory.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد حركات تسديد أو إضافة مسجلة لهذا المورد</td></tr>`;
  } else {
    sortedHistory.forEach((tx, idx) => {
      const isPay = tx.type === 'pay_supplier';
      const typeLabel = isPay ? 'تسديد دفعة' : 'قيد بضاعة/دين آجل';
      const typeClass = isPay ? 'tx-type-pay' : 'tx-type-add';
      const amountPrefix = isPay ? '-' : '+';
      const cleanDate = tx.date ? tx.date.split('T')[0].replace(/-/g, '/') : '-';

      txRows += `<tr>
        <td><strong>${formatNumber(idx + 1, numberFormat)}</strong></td>
        <td><span class="${typeClass}">${typeLabel}</span></td>
        <td><strong>${amountPrefix}${formatNumber(tx.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${tx.itemType ? `[بضاعة: ${tx.itemType}] ` : ''}${tx.notes || tx.description || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${supplier.name} ${supplier.companyName ? `(${supplier.companyName})` : ''}</div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ التسجيل: ${cleanCreatedAt}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(supplier.amount, numberFormat)} د.ع</span>
        <span class="amount-label">الرصيد المستحق القائم</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب مورد / شركة - ${supplier.name}`,
      subtitle: `رقم الهاتف: ${cleanPhone} ${supplier.itemType ? `| السلعة: ${supplier.itemType}` : ''}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'amber',
    },
    htmlSection
  );
}

export function exportSingleInstallmentPdf(
  installment: InstallmentRecord,
  currentUser?: User | null,
  storeName?: string,
  numberFormat: 'english' | 'arabic' = 'english'
) {
  const branchName = currentUser ? getUserBranchDisplayName(currentUser) : (storeName || 'الفرع الرئيسي');
  const userName = currentUser ? getUserDisplayName(currentUser) : 'مدير النظام';

  const cleanRegDate = installment.registrationDate ? installment.registrationDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanNextDue = installment.nextDueDate ? installment.nextDueDate.split('T')[0].replace(/-/g, '/') : '-';
  const cleanPhone = installment.phone ? installment.phone.replace(/[^0-9]/g, '') : 'غير مسجل';

  const statsSummaryHtml = `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px;">
    <div style="background: #fdf4ff; border: 1px solid #f5d0fe; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #701a75; font-weight: 700;">إجمالي مبلغ العقد</span>
      <div style="font-size: 13pt; font-weight: 900; color: #581c87;">${formatNumber(installment.totalAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #f0fdf4; border: 1px solid #bbf7d0; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #14532d; font-weight: 700;">المُسدّد والدفعة الأولى</span>
      <div style="font-size: 13pt; font-weight: 900; color: #15803d;">${formatNumber(installment.totalAmount - installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
    <div style="background: #fff1f2; border: 1px solid #fecdd3; padding: 12px; border-radius: 12px; text-align: center;">
      <span style="font-size: 8.5pt; color: #881337; font-weight: 700;">المتبقي للتحصيل</span>
      <div style="font-size: 13pt; font-weight: 900; color: #be123c;">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</div>
    </div>
  </div>`;

  const payments = installment.payments || [];
  let txRows = '';
  if (payments.length === 0) {
    txRows = `<tr><td colspan="5" class="no-history">لا توجد دفعات تسديد قسط مسجلة لهذا العقد بعد</td></tr>`;
  } else {
    payments.forEach((p, pIdx) => {
      const cleanDate = p.date ? p.date.split('T')[0].replace(/-/g, '/') : '-';
      txRows += `<tr>
        <td><strong>${formatNumber(pIdx + 1, numberFormat)}</strong></td>
        <td><span class="tx-type-pay">تسديد قسط</span></td>
        <td><strong>+${formatNumber(p.amount, numberFormat)} د.ع</strong></td>
        <td>${cleanDate}</td>
        <td>${p.notes || '-'}</td>
      </tr>`;
    });
  }

  const htmlSection = `<div class="person-card">
    <div class="person-card-header">
      <div>
        <div class="person-name">${installment.name} <span style="font-size: 9.5pt; color: #0369a1; font-weight: 800;">[السلعة: ${installment.item}]</span></div>
        <div class="person-phone">رقم الهاتف: ${cleanPhone} | تاريخ العقد: ${cleanRegDate} | الاستحقاق القادم: ${cleanNextDue}</div>
      </div>
      <div class="person-amount-box">
        <span class="amount-value">${formatNumber(installment.remainingAmount, numberFormat)} د.ع</span>
        <span class="amount-label">المتبقي من القسط</span>
      </div>
    </div>
    <div style="padding: 10px 14px; background: #fff;">
      <table class="tx-table">
        <thead>
          <tr>
            <th style="width: 30px;">#</th>
            <th style="width: 120px;">نوع الحركة</th>
            <th style="width: 120px;">المبلغ المسدد</th>
            <th style="width: 110px;">التاريخ</th>
            <th>الملاحظات والتفاصيل</th>
          </tr>
        </thead>
        <tbody>
          ${txRows}
        </tbody>
      </table>
    </div>
  </div>`;

  printSystemPdfReport(
    {
      title: `كشف حساب عقد قسط - ${installment.name}`,
      subtitle: `السلعة: ${installment.item} | رقم الهاتف: ${cleanPhone}`,
      branchName,
      userName,
      statsSummaryHtml,
      accentColor: 'emerald',
    },
    htmlSection
  );
}
