import React, { useState, useMemo, useRef, useEffect } from 'react';
import { AppSettings, Debtor, InstallmentRecord, Supplier, User } from '../types';
import {
  formatNumber,
  formatDateDigits,
  buildWhatsAppReminderUrl,
  calculateDaysElapsed,
  formatDaysElapsedArabic,
  formatIraqiPhoneNumber
} from '../utils/formatters';
import {
  formatDueDateBadge,
  buildInstallmentWhatsAppUrl,
  calculateDateDiffDays
} from '../utils/installmentHelpers';
import { openWhatsAppDirect, createSupplierReminderWhatsAppNotice } from '../utils/whatsapp';
import { SettleInstallmentPaymentModal } from './SettleInstallmentPaymentModal';
import { InstallmentDetailsModal } from './InstallmentDetailsModal';
import { useI18n } from '../i18n/index.tsx';

export type OverdueMode = 'all' | 'debts' | 'creditors' | 'installments' | 'suppliers';

interface OverdueTabProps {
  currentUser?: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  settings?: AppSettings;
  mode?: OverdueMode | 'debts' | 'creditors' | 'installments' | 'suppliers';
  isActive?: boolean;
  onOpenPayModal: (debtor: Debtor) => void;
  onToggleOverdueStatus: (debtor: Debtor) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onViewHistory?: (debtor: Debtor) => void;
  onShare?: (debtor: Debtor) => void;
  onSettleInstallmentPayment?: (installmentId: number, amount: number, date: string, notes?: string) => Promise<void>;
  onDeleteInstallment?: (id: number) => Promise<void>;
  onPaySupplier?: (supplier: Supplier) => void;
  onSupplierHistory?: (supplier: Supplier) => void;
}

export const OverdueTab: React.FC<OverdueTabProps> = React.memo(({
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  settings,
  mode,
  isActive = true,
  onOpenPayModal,
  onToggleOverdueStatus,
  onShowToast,
  onViewHistory,
  onShare,
  onSettleInstallmentPayment,
  onDeleteInstallment,
  onPaySupplier,
  onSupplierHistory,
}) => {
  const { t, numberFormat, currency } = useI18n();

  const canSwitchModules =
    !currentUser ||
    currentUser.role === 'admin' ||
    !currentUser.allowedModules ||
    currentUser.allowedModules === 'both';

  const initialOverdueMode: OverdueMode =
    currentUser?.allowedModules === 'installments'
      ? 'installments'
      : currentUser?.allowedModules === 'debts'
      ? 'debts'
      : mode === 'debts'
      ? 'debts'
      : mode === 'creditors'
      ? 'creditors'
      : mode === 'installments'
      ? 'installments'
      : mode === 'suppliers'
      ? 'suppliers'
      : 'all';

  const [searchTerm, setSearchTerm] = useState('');
  const [overdueMode, setOverdueMode] = useState<OverdueMode>(initialOverdueMode);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync mode if provided or changed by permissions
  useEffect(() => {
    if (currentUser?.allowedModules === 'installments') {
      setOverdueMode('installments');
    } else if (currentUser?.allowedModules === 'debts') {
      setOverdueMode('debts');
    } else if (mode === 'debts' || mode === 'creditors' || mode === 'installments' || mode === 'suppliers' || mode === 'all') {
      setOverdueMode(mode);
    }
  }, [mode, currentUser?.allowedModules]);

  // Modals for installments
  const [selectedInstallmentForSettle, setSelectedInstallmentForSettle] = useState<InstallmentRecord | null>(null);
  const [selectedInstallmentForDetails, setSelectedInstallmentForDetails] = useState<InstallmentRecord | null>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const alertThreshold = settings?.alertDaysThreshold ?? 1;
  const isAlertEnabled = settings?.enableDebtAlerts ?? true;
  const highDebtThreshold = settings?.highDebtThreshold ?? 25000;

  const [visibleDebtorsCount, setVisibleDebtorsCount] = useState(30);
  const [visibleInstallmentsCount, setVisibleInstallmentsCount] = useState(30);

  useEffect(() => {
    setVisibleDebtorsCount(30);
    setVisibleInstallmentsCount(30);
  }, [searchTerm, overdueMode]);

  // 1. Overdue Debtors (لك)
  const { overdueDebtors, totalOverdueDebtsAmount } = useMemo(() => {
    if (!isActive) {
      return { overdueDebtors: [], totalOverdueDebtsAmount: 0 };
    }
    const list: Debtor[] = [];
    let sum = 0;
    const nowMs = Date.now();
    const thresholdMs = alertThreshold * 24 * 60 * 60 * 1000;
    const len = debtors.length;
    const maxCollect = 1000;

    for (let i = 0; i < len; i++) {
      const d = debtors[i];
      if (!d || d.type === 'creditor') continue;
      const amt = Number(d.amount) || 0;
      if (amt <= 0 || d.status === 'خالي من الدين') continue;

      let isOverdue = d.status === 'متأخر';
      if (!isOverdue && isAlertEnabled && d.createdAt) {
        const createdMs = new Date(d.createdAt).getTime();
        if (nowMs - createdMs >= thresholdMs) {
          isOverdue = true;
        }
      }

      if (isOverdue) {
        sum += amt;
        if (list.length < maxCollect) {
          list.push(d);
        }
      }
    }

    list.sort((a, b) => (Number(b.amount) || 0) - (Number(a.amount) || 0));
    return { overdueDebtors: list, totalOverdueDebtsAmount: sum };
  }, [debtors, alertThreshold, isAlertEnabled, isActive]);

  // 1.b Overdue Creditors (ديون عليّ مستحقة)
  const { overdueCreditors, totalOverdueCreditorsAmount } = useMemo(() => {
    if (!isActive) {
      return { overdueCreditors: [], totalOverdueCreditorsAmount: 0 };
    }
    const list: Debtor[] = [];
    let sum = 0;
    const len = debtors.length;

    for (let i = 0; i < len; i++) {
      const d = debtors[i];
      if (!d || d.type !== 'creditor') continue;
      const amt = Number(d.amount) || 0;
      if (amt > 0) {
        sum += amt;
        list.push(d);
      }
    }

    list.sort((a, b) => (Number(b.amount) || 0) - (Number(a.amount) || 0));
    return { overdueCreditors: list, totalOverdueCreditorsAmount: sum };
  }, [debtors, isActive]);

  // 2. Overdue Installments (due or overdue status)
  const { overdueInstallments, totalOverdueInstallmentsAmount } = useMemo(() => {
    if (!isActive) {
      return { overdueInstallments: [], totalOverdueInstallmentsAmount: 0 };
    }
    const list: InstallmentRecord[] = [];
    let sum = 0;
    const len = installments.length;

    for (let i = 0; i < len; i++) {
      const inst = installments[i];
      if (!inst) continue;
      const rem = Number(inst.remainingAmount) || 0;
      if (rem > 0 && (inst.status === 'due' || inst.status === 'overdue')) {
        sum += rem;
        list.push(inst);
      }
    }

    list.sort((a, b) => (Number(b.remainingAmount) || 0) - (Number(a.remainingAmount) || 0));
    return { overdueInstallments: list, totalOverdueInstallmentsAmount: sum };
  }, [installments, isActive]);

  // 3. Overdue Suppliers (active debt amount > 0)
  const { overdueSuppliers, totalOverdueSuppliersAmount } = useMemo(() => {
    if (!isActive) {
      return { overdueSuppliers: [], totalOverdueSuppliersAmount: 0 };
    }
    const list: Supplier[] = [];
    let sum = 0;
    const len = suppliers.length;

    for (let i = 0; i < len; i++) {
      const sup = suppliers[i];
      if (!sup) continue;
      const amt = Number(sup.amount) || 0;
      if (amt > 0) {
        sum += amt;
        list.push(sup);
      }
    }

    list.sort((a, b) => (Number(b.amount) || 0) - (Number(a.amount) || 0));
    return { overdueSuppliers: list, totalOverdueSuppliersAmount: sum };
  }, [suppliers, isActive]);

  // Search Filtering
  const filteredDebtors = useMemo(() => {
    if (!searchTerm.trim()) return overdueDebtors;
    const term = searchTerm.toLowerCase().trim();
    return overdueDebtors.filter(
      (d) => (d.name || '').toLowerCase().includes(term) || (d.phone && String(d.phone).includes(term))
    );
  }, [overdueDebtors, searchTerm]);

  const filteredCreditors = useMemo(() => {
    if (!searchTerm.trim()) return overdueCreditors;
    const term = searchTerm.toLowerCase().trim();
    return overdueCreditors.filter(
      (c) => (c.name || '').toLowerCase().includes(term) || (c.phone && String(c.phone).includes(term))
    );
  }, [overdueCreditors, searchTerm]);

  const filteredInstallments = useMemo(() => {
    if (!searchTerm.trim()) return overdueInstallments;
    const term = searchTerm.toLowerCase().trim();
    return overdueInstallments.filter(
      (i) =>
        (i.name || '').toLowerCase().includes(term) ||
        (i.item || '').toLowerCase().includes(term) ||
        (i.phone && String(i.phone).includes(term))
    );
  }, [overdueInstallments, searchTerm]);

  const filteredSuppliers = useMemo(() => {
    if (!searchTerm.trim()) return overdueSuppliers;
    const term = searchTerm.toLowerCase().trim();
    return overdueSuppliers.filter(
      (s) =>
        (s.name || '').toLowerCase().includes(term) ||
        (s.companyName || '').toLowerCase().includes(term) ||
        (s.itemType || '').toLowerCase().includes(term) ||
        (s.phone && String(s.phone).includes(term))
    );
  }, [overdueSuppliers, searchTerm]);

  const handleSendDebtorWhatsApp = (debtor: Debtor) => {
    if (!debtor.phone || !debtor.phone.trim()) {
      onShowToast(t('debtors.noPhone', 'لا يوجد رقم هاتف مسجل لهذا المدين'), 'error');
      return;
    }
    if (debtor.phone.includes('*')) {
      onShowToast('رقم الهاتف تجريبي ولا يمكن إرسال رسالة حقيقية له', 'info');
      return;
    }
    const whatsappUrl = buildWhatsAppReminderUrl(debtor.phone, debtor.name, debtor.amount);
    window.open(whatsappUrl, '_blank');
  };

  const handleSendSupplierWhatsApp = (supplier: Supplier) => {
    if (!supplier.phone || !supplier.phone.trim()) {
      onShowToast('لا يوجد رقم هاتف مسجل لهذا المورد', 'error');
      return;
    }
    const notice = createSupplierReminderWhatsAppNotice(
      supplier.name,
      supplier.phone,
      supplier.companyName,
      supplier.amount,
      currency
    );
    if (notice) {
      openWhatsAppDirect(notice.phone, notice.message);
    }
  };

  const handleSendInstallmentWhatsApp = (inst: InstallmentRecord) => {
    if (!inst.phone || !inst.phone.trim()) {
      onShowToast(t('debtors.noPhone', 'لا يوجد رقم هاتف مسجل لصاحب الأقساط'), 'error');
      return;
    }
    const whatsappUrl = buildInstallmentWhatsAppUrl(
      inst.phone,
      inst.name,
      inst.item,
      inst.remainingAmount,
      inst.nextDueDate
    );
    if (whatsappUrl) {
      window.open(whatsappUrl, '_blank');
    }
  };

  const showDebts = overdueMode === 'all' || overdueMode === 'debts';
  const showCreditors = overdueMode === 'all' || overdueMode === 'creditors';
  const showInstallments = overdueMode === 'all' || overdueMode === 'installments';
  const showSuppliers = overdueMode === 'all' || overdueMode === 'suppliers';

  const totalFilteredCount =
    (showDebts ? filteredDebtors.length : 0) +
    (showCreditors ? filteredCreditors.length : 0) +
    (showInstallments ? filteredInstallments.length : 0) +
    (showSuppliers ? filteredSuppliers.length : 0);

  return (
    <div id="tab-overdue" className="pb-40 space-y-3.5 animate-in fade-in duration-150">
      {/* Sticky Header & Search Bar */}
      <div className="sticky top-0 z-30 bg-slate-50 px-4 safe-top pb-2.5 border-b border-slate-200 space-y-2 gpu-layer">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <span>{overdueMode === 'creditors' ? 'ديون عليّ مستحقة' : mode === 'suppliers' || overdueMode === 'suppliers' ? 'المستحقة' : t('nav.overdue', 'المتأخرون')}</span>
              </h1>

              {/* DROPDOWN FILTER: الكل / الديون / ديون عليّ / الأقساط / الموردين */}
              {canSwitchModules && (
                <div className="relative" ref={dropdownRef}>
                  <button
                    type="button"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="px-2.5 py-1 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 shadow-xs text-xs font-black text-slate-800 flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span className={`w-2 h-2 rounded-full ${
                      overdueMode === 'creditors' ? 'bg-rose-600' : overdueMode === 'debts' ? 'bg-blue-600' : overdueMode === 'installments' ? 'bg-emerald-600' : overdueMode === 'suppliers' ? 'bg-amber-600' : 'bg-purple-600'
                    }`}></span>
                    <span>
                      {overdueMode === 'creditors'
                        ? 'ديون عليّ'
                        : overdueMode === 'debts'
                        ? t('reports.debtsOnly', 'الديون')
                        : overdueMode === 'installments'
                        ? t('reports.installmentsOnly', 'الأقساط')
                        : overdueMode === 'suppliers'
                        ? 'الموردين'
                        : t('reports.allModules', 'الكل')}
                    </span>
                    <i className="fa-solid fa-chevron-down text-[9px] text-slate-400"></i>
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute top-full start-0 mt-1 w-48 bg-white border border-slate-200 rounded-2xl shadow-xl p-1 z-50 animate-in fade-in zoom-in-95 duration-100 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          setOverdueMode('all');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          overdueMode === 'all' ? 'bg-purple-50 text-purple-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-layer-group text-xs text-purple-600"></i>
                          <span>{t('common.all', 'الكل')} ({formatNumber(overdueDebtors.length + overdueCreditors.length + overdueInstallments.length + overdueSuppliers.length, numberFormat)})</span>
                        </div>
                        {overdueMode === 'all' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOverdueMode('debts');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          overdueMode === 'debts' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-users text-xs text-blue-600"></i>
                          <span>{t('nav.debts', 'الديون (لك)')} ({formatNumber(overdueDebtors.length, numberFormat)})</span>
                        </div>
                        {overdueMode === 'debts' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOverdueMode('creditors');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          overdueMode === 'creditors' ? 'bg-rose-50 text-rose-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-hand-holding-dollar text-xs text-rose-600"></i>
                          <span>ديون عليّ ({formatNumber(overdueCreditors.length, numberFormat)})</span>
                        </div>
                        {overdueMode === 'creditors' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOverdueMode('installments');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          overdueMode === 'installments' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-clock-rotate-left text-xs text-emerald-600"></i>
                          <span>{t('nav.installments', 'الأقساط')} ({formatNumber(overdueInstallments.length, numberFormat)})</span>
                        </div>
                        {overdueMode === 'installments' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setOverdueMode('suppliers');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          overdueMode === 'suppliers' ? 'bg-amber-50 text-amber-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-truck-field text-xs text-amber-600"></i>
                          <span>الموردين ({formatNumber(overdueSuppliers.length, numberFormat)})</span>
                        </div>
                        {overdueMode === 'suppliers' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <p className="text-xs font-medium text-slate-500 mt-1">
              {t('overdue.totalOverdue', 'إجمالي المستحق')}: <span className="font-bold text-rose-600 font-mono">
                {formatNumber(
                  (showDebts ? totalOverdueDebtsAmount : 0) +
                  (showCreditors ? totalOverdueCreditorsAmount : 0) +
                  (showInstallments ? totalOverdueInstallmentsAmount : 0) +
                  (showSuppliers ? totalOverdueSuppliersAmount : 0),
                  numberFormat
                )} {currency}
              </span>
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative pt-0.5">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={t('overdue.searchPlaceholder', 'بحث بالاسم أو الهاتف أو السلعة بين المتأخرين...')}
            className="w-full bg-white border border-slate-200/80 rounded-2xl py-2 px-9 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-rose-400 focus:ring-2 focus:ring-rose-100 shadow-2xs transition-all"
          />
          <i className="fa-solid fa-magnifying-glass absolute start-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
          {searchTerm && (
            <button
              type="button"
              onClick={() => setSearchTerm('')}
              className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1 cursor-pointer"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>
      </div>

      {/* Main List Container */}
      <div className="px-4 space-y-4">
        {totalFilteredCount === 0 ? (
          <div className="bg-white rounded-3xl p-6 text-center border border-dashed border-slate-200 shadow-2xs">
            <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center mx-auto mb-2 text-xl">
              <i className="fa-solid fa-check-double"></i>
            </div>
            <div className="font-bold text-sm text-slate-800 mb-1">
              {searchTerm 
                ? t('installments.noSearchResults', 'لا توجد نتائج مطابقة لبحثك') 
                : t('overdue.noOverdue', 'لا توجد مستحقات أو ديون قائمة حالياً')}
            </div>
            <p className="text-xs text-slate-400 max-w-xs mx-auto">
              {searchTerm
                ? t('installments.noSearchResultsDesc', 'جرب كتابة اسم آخر أو مسح حقل البحث')
                : t('overdue.allSettled', 'كافة الحسابات والأقساط ومستحقات الموردين مسددة بالكامل أو ضمن الفترات المحددة')}
            </p>
          </div>
        ) : (
          <>
            {/* SECTION 1: OVERDUE DEBTORS */}
            {showDebts && filteredDebtors.length > 0 && (
              <div className="space-y-2.5">
                {overdueMode === 'all' && (
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                    <span className="flex items-center gap-1.5 text-blue-800">
                      <i className="fa-solid fa-users text-blue-600"></i>
                      <span>{t('overdue.overdueDebts', 'ديون متأخرة')} ({formatNumber(filteredDebtors.length, numberFormat)})</span>
                    </span>
                    <span className="font-mono text-rose-600">
                      {formatNumber(totalOverdueDebtsAmount, numberFormat)} {currency}
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {filteredDebtors.slice(0, visibleDebtorsCount).map((debtor) => {
                  const daysElapsed = calculateDaysElapsed(debtor.createdAt);
                  const isHighDebt = debtor.amount >= highDebtThreshold;

                  return (
                    <div
                      key={`debtor-${debtor.id}`}
                      className="bg-white rounded-3xl p-4 border border-rose-100/80 shadow-xs flex flex-col gap-3 transition-all hover:border-rose-200"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 flex items-center justify-center text-sm font-black shrink-0 shadow-2xs">
                            {(debtor.name || '').trim().charAt(0) || 'م'}
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-sm text-slate-900 truncate flex items-center gap-1.5">
                              <span>{debtor.name}</span>
                              <span className="text-[10px] bg-blue-50 text-blue-700 px-1.5 py-0.2 rounded-md font-normal">
                                {t('nav.debts', 'دين')}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                              <span className="text-[11px] text-slate-400 font-mono" dir="ltr">
                                {debtor.phone ? formatDateDigits(debtor.phone, numberFormat) : t('debtors.noPhone', 'لا يوجد هاتف')}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="text-end shrink-0">
                          <div className="text-base font-black text-rose-600 font-mono" dir="ltr">
                            {formatNumber(debtor.amount, numberFormat)} {currency}
                          </div>
                          <div className="flex items-center justify-end gap-1 mt-1">
                            <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200/80 text-[10px] font-bold px-2 py-0.5 rounded-md shadow-2xs">
                              <i className="fa-solid fa-clock-rotate-left text-[8.5px] text-rose-500"></i>
                              <span>{t('debtors.overdue', 'متأخر')}</span>
                              {daysElapsed > 0 && (
                                <span className="text-rose-500 font-medium text-[9px]">
                                  ({t('common.daysCount', '{count} يوم', { count: formatNumber(daysElapsed, numberFormat) })})
                                </span>
                              )}
                            </span>
                            {isHighDebt && (
                              <span className="text-[9.5px] font-black bg-red-50 text-red-700 border border-red-200/80 px-1.5 py-0.5 rounded-md">
                                {t('debtors.highDebtBadge', 'مرتفع')}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                        <button
                          type="button"
                          onClick={() => handleSendDebtorWhatsApp(debtor)}
                          className="flex-1 bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-700 font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <i className="fa-brands fa-whatsapp text-sm"></i>
                          <span>{t('debtors.whatsappReminder', 'تذكير واتساب')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onOpenPayModal(debtor)}
                          className="flex-1 bg-blue-600 hover:bg-blue-700 active:scale-98 text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <i className="fa-solid fa-arrow-down text-xs"></i>
                          <span>{t('debtors.payDebt', 'تسديد مبلغ')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onViewHistory?.(debtor)}
                          title={t('common.viewHistory', 'عرض السجل')}
                          className="w-8 h-8 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-clock-rotate-left"></i>
                        </button>

                        <button
                          type="button"
                          onClick={() => onShare?.(debtor)}
                          title={t('debtors.shareStatement', 'مشاركة كشف الحساب')}
                          className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-share-nodes text-xs"></i>
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleOverdueStatus(debtor)}
                          title={t('debtors.toggleOverdue', 'تبديل حالة التأخير')}
                          className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-check"></i>
                        </button>
                      </div>
                    </div>
                  );
                })}
                </div>

                {filteredDebtors.length > visibleDebtorsCount && (
                  <div className="pt-2 pb-4">
                    <button
                      type="button"
                      onClick={() => setVisibleDebtorsCount((prev) => prev + 50)}
                      className="w-full py-3 bg-white hover:bg-slate-50 text-slate-800 font-bold text-xs rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2 border border-slate-300 shadow-sm active:scale-[0.98]"
                    >
                      <i className="fa-solid fa-angles-down text-blue-600 text-xs"></i>
                      <span>عرض المزيد من المتأخرين (+50)</span>
                      <span className="text-[10.5px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-lg font-mono">
                        متبقي {filteredDebtors.length - visibleDebtorsCount}
                      </span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* SECTION 1.b: OVERDUE CREDITORS (ديون عليّ) */}
            {showCreditors && filteredCreditors.length > 0 && (
              <div className="space-y-2.5">
                {overdueMode === 'all' && (
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                    <span className="flex items-center gap-1.5 text-rose-800">
                      <i className="fa-solid fa-hand-holding-dollar text-rose-600"></i>
                      <span>ديون عليّ مستحقة ({formatNumber(filteredCreditors.length, numberFormat)})</span>
                    </span>
                    <span className="font-mono text-rose-600">
                      {formatNumber(totalOverdueCreditorsAmount, numberFormat)} {currency}
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {filteredCreditors.slice(0, visibleDebtorsCount).map((creditor) => (
                    <div
                      key={`cred-${creditor.id}`}
                      className="bg-white rounded-3xl p-4 border border-rose-100 shadow-xs flex flex-col gap-3 transition-all hover:border-rose-200"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 flex items-center justify-center text-sm font-black shrink-0 shadow-2xs">
                            <i className="fa-solid fa-hand-holding-dollar"></i>
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-sm text-slate-900 truncate">
                              {creditor.name}
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                              <span className="font-mono" dir="ltr">{creditor.phone ? formatDateDigits(creditor.phone, numberFormat) : 'بدون هاتف'}</span>
                              <span>•</span>
                              <span>يطلبك مالاً</span>
                            </div>
                          </div>
                        </div>

                        <div className="text-end shrink-0">
                          <div className="text-base font-black text-rose-600 font-mono" dir="ltr">
                            {formatNumber(creditor.amount, numberFormat)} {currency}
                          </div>
                          <div className="flex items-center justify-end gap-1 mt-1">
                            <span className="inline-flex items-center gap-1 bg-rose-50 text-rose-700 border border-rose-200/80 text-[10px] font-bold px-2 py-0.5 rounded-md">
                              <span>مستحق عليك</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                        <button
                          type="button"
                          onClick={() => onOpenPayModal(creditor)}
                          className="flex-1 bg-rose-600 hover:bg-rose-700 active:scale-98 text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <i className="fa-solid fa-arrow-down text-xs"></i>
                          <span>تسديد دفعة</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onViewHistory?.(creditor)}
                          title={t('common.viewHistory', 'عرض السجل')}
                          className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-clock-rotate-left"></i>
                        </button>

                        <button
                          type="button"
                          onClick={() => onShare?.(creditor)}
                          title="مشاركة كشف الحساب"
                          className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-600 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-share-nodes text-xs"></i>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* SECTION 2: OVERDUE / DUE INSTALLMENTS */}
            {showInstallments && filteredInstallments.length > 0 && (
              <div className="space-y-2.5 pt-2">
                {overdueMode === 'all' && (
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                    <span className="flex items-center gap-1.5 text-emerald-800">
                      <i className="fa-solid fa-clock-rotate-left text-emerald-600"></i>
                      <span>{t('overdue.overdueInstallments', 'أقساط مستحقة ومتأخرة')} ({formatNumber(filteredInstallments.length, numberFormat)})</span>
                    </span>
                    <span className="font-mono text-rose-600">
                      {formatNumber(totalOverdueInstallmentsAmount, numberFormat)} {currency}
                    </span>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {filteredInstallments.slice(0, visibleInstallmentsCount).map((inst) => {
                  const badgeInfo = formatDueDateBadge(inst.nextDueDate, inst.status);

                  return (
                    <div
                      key={`inst-${inst.id}`}
                      className="bg-white rounded-3xl p-4 border border-emerald-100/90 shadow-xs flex flex-col gap-3 transition-all hover:border-emerald-200"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-10 h-10 rounded-2xl bg-emerald-50 border border-emerald-100 text-emerald-700 flex items-center justify-center text-sm font-black shrink-0 shadow-2xs">
                            <i className="fa-solid fa-receipt text-emerald-600"></i>
                          </div>
                          <div className="min-w-0">
                            <div className="font-bold text-sm text-slate-900 truncate flex items-center gap-1.5">
                              <span>{inst.name}</span>
                              <span className="text-[10.5px] font-bold bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md">
                                {inst.item}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                              <span className="font-mono" dir="ltr">{inst.phone ? formatDateDigits(inst.phone, numberFormat) : t('debtors.noPhone', 'لا يوجد هاتف')}</span>
                              <span>•</span>
                              <span>{t('installments.dueDate', 'الاستحقاق')}: <strong className="text-slate-700 font-mono">{formatDateDigits(inst.nextDueDate, numberFormat)}</strong></span>
                            </div>
                          </div>
                        </div>

                        <div className="text-end shrink-0">
                          <div className="text-base font-black text-rose-600 font-mono" dir="ltr">
                            {formatNumber(inst.remainingAmount, numberFormat)} {currency}
                          </div>
                          <div className="mt-1">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border flex items-center gap-1 ${badgeInfo.badgeClass}`}>
                              <i className={`fa-solid ${badgeInfo.icon} text-[9px]`}></i>
                              <span>{badgeInfo.label}</span>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action Buttons for Installment */}
                      <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                        {inst.phone && (
                          <button
                            type="button"
                            onClick={() => handleSendInstallmentWhatsApp(inst)}
                            className="flex-1 bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-700 font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                          >
                            <i className="fa-brands fa-whatsapp text-sm"></i>
                            <span>{t('debtors.whatsappReminder', 'تذكير واتساب')}</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => setSelectedInstallmentForSettle(inst)}
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                        >
                          <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
                          <span>{t('installments.payInstallment', 'تسديد قسط')}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setSelectedInstallmentForDetails(inst)}
                          title={t('common.viewDetails', 'عرض تفاصيل المعاملة')}
                          className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                        >
                          <i className="fa-solid fa-eye"></i>
                        </button>
                      </div>
                    </div>
                  );
                })}
                </div>

                {filteredInstallments.length > visibleInstallmentsCount && (
                  <div className="pt-2 pb-4">
                    <button
                      type="button"
                      onClick={() => setVisibleInstallmentsCount((prev) => prev + 50)}
                      className="w-full py-3 bg-white hover:bg-emerald-50 text-emerald-800 font-bold text-xs rounded-2xl transition-all cursor-pointer flex items-center justify-center gap-2 border border-emerald-300 shadow-sm active:scale-[0.98]"
                    >
                      <i className="fa-solid fa-angles-down text-emerald-600 text-xs"></i>
                      <span>عرض المزيد من الأقساط المستحقة (+50)</span>
                      <span className="text-[10.5px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg font-mono">
                        متبقي {filteredInstallments.length - visibleInstallmentsCount}
                      </span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* SECTION 3: OVERDUE SUPPLIERS */}
            {showSuppliers && filteredSuppliers.length > 0 && (
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700 px-1">
                  <span className="flex items-center gap-1.5 text-amber-800">
                    <i className="fa-solid fa-truck-field text-amber-600"></i>
                    <span>موردين وشركات بحسابات مستحقة ({formatNumber(filteredSuppliers.length, numberFormat)})</span>
                  </span>
                  <span className="font-mono text-amber-600">
                    {formatNumber(totalOverdueSuppliersAmount, numberFormat)} {currency}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {filteredSuppliers.map((supplier) => {
                    const curAmt = Number(supplier.amount) || 0;

                    return (
                      <div
                        key={`supplier-${supplier.id}`}
                        className="bg-white rounded-3xl p-4 border border-amber-200 shadow-xs flex flex-col gap-3 transition-all hover:border-amber-300"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-3 min-w-0">
                            <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-600 font-black flex items-center justify-center text-sm shrink-0 shadow-2xs">
                              <i className="fa-solid fa-truck"></i>
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-sm text-slate-900 truncate flex items-center gap-1.5">
                                <span>{typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '')}</span>
                                {typeof supplier.companyName === 'string' && supplier.companyName.trim() ? (
                                  <span className="text-[10px] bg-slate-100 text-slate-700 px-1.5 py-0.2 rounded-md font-normal truncate">
                                    {supplier.companyName}
                                  </span>
                                ) : null}
                              </div>
                              <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                                {typeof supplier.itemType === 'string' && supplier.itemType.trim() ? (
                                  <span className="text-[10px] text-amber-700 font-semibold bg-amber-50 px-1.5 py-0.5 rounded-md border border-amber-200">
                                    {supplier.itemType}
                                  </span>
                                ) : null}
                                {typeof supplier.phone === 'string' && supplier.phone.trim() ? (
                                  <span className="text-[11px] text-slate-400 font-mono" dir="ltr">
                                    {supplier.phone}
                                  </span>
                                ) : null}
                              </div>
                            </div>
                          </div>

                          <div className="text-end shrink-0">
                            <div className="text-base font-black text-amber-600 font-mono" dir="ltr">
                              {formatNumber(curAmt, numberFormat)} {currency}
                            </div>
                            <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200/80 text-[10px] font-bold px-2 py-0.5 rounded-md shadow-2xs mt-1">
                              <span>مستحق للمورد</span>
                            </span>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-2 pt-2 border-t border-slate-50">
                          {supplier.phone && (
                            <button
                              type="button"
                              onClick={() => handleSendSupplierWhatsApp(supplier)}
                              className="flex-1 bg-emerald-50 hover:bg-emerald-100 active:scale-98 text-emerald-700 font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                            >
                              <i className="fa-brands fa-whatsapp text-sm"></i>
                              <span>تذكير</span>
                            </button>
                          )}

                          {onPaySupplier && (
                            <button
                              type="button"
                              onClick={() => onPaySupplier(supplier)}
                              className="flex-1 bg-amber-600 hover:bg-amber-700 active:scale-98 text-white font-bold text-xs py-2 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                            >
                              <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
                              <span>تسديد دفعة</span>
                            </button>
                          )}

                          {onSupplierHistory && (
                            <button
                              type="button"
                              onClick={() => onSupplierHistory(supplier)}
                              title="عرض سجل المعاملات"
                              className="w-8 h-8 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 flex items-center justify-center text-xs transition-colors cursor-pointer shrink-0"
                            >
                              <i className="fa-solid fa-clock-rotate-left"></i>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Settle Installment Modal */}
      {selectedInstallmentForSettle && onSettleInstallmentPayment && (
        <SettleInstallmentPaymentModal
          isOpen={Boolean(selectedInstallmentForSettle)}
          onClose={() => setSelectedInstallmentForSettle(null)}
          installment={selectedInstallmentForSettle}
          onSettle={onSettleInstallmentPayment}
        />
      )}

      {/* Installment Details Modal */}
      {selectedInstallmentForDetails && (
        <InstallmentDetailsModal
          isOpen={Boolean(selectedInstallmentForDetails)}
          onClose={() => setSelectedInstallmentForDetails(null)}
          installment={selectedInstallmentForDetails}
          onOpenSettleModal={(inst) => {
            setSelectedInstallmentForDetails(null);
            setSelectedInstallmentForSettle(inst);
          }}
          onDelete={onDeleteInstallment || (async () => {})}
        />
      )}
    </div>
  );
});

OverdueTab.displayName = 'OverdueTab';

