import React, { useState, useRef, useEffect } from 'react';
import { AppSettings, Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import {
  formatNumber,
  buildWhatsAppReminderUrl,
  formatIraqiPhoneNumber,
  calculateDaysElapsed,
  formatDateArabic
} from '../utils/formatters';
import { exportSingleDebtorPdf } from '../utils/pdfReportGenerator';

interface DebtorCardProps {
  debtor: Debtor;
  onPay: (debtor: Debtor) => void;
  onAddDebt: (debtor: Debtor) => void;
  onDelete: (debtor: Debtor) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onViewHistory?: (debtor: Debtor) => void;
  onShare?: (debtor: Debtor) => void;
  onEditName?: (debtor: Debtor) => void;
  settings?: AppSettings;
}

export const DebtorCard: React.FC<DebtorCardProps> = ({
  debtor,
  onPay,
  onAddDebt,
  onDelete,
  onShowToast,
  onViewHistory,
  onShare,
  onEditName,
  settings,
}) => {
  const { t, formatMoney } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);
  const [openUpwards, setOpenUpwards] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('click', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('click', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
    };
  }, [menuOpen]);

  const handleToggleMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!menuOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      setOpenUpwards(spaceBelow < 240);
    }
    setMenuOpen(!menuOpen);
  };

  const handleWhatsAppReminder = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);

    if (!debtor.phone) {
      onShowToast(t('debts.emptyNoPhone', "لا يوجد رقم هاتف لهذا المدين"), "error");
      return;
    }

    const formatted = formatIraqiPhoneNumber(debtor.phone);
    if (!formatted || formatted.length < 10) {
      onShowToast(t('debts.invalidPhone', "رقم الهاتف غير صحيح أو مكتوب بصيغة خاطئة"), "error");
      return;
    }

    const isCreditor = debtor.type === 'creditor';
    const url = buildWhatsAppReminderUrl(debtor.phone, debtor.name, debtor.amount, isCreditor);
    window.open(url, '_blank');
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);
    onDelete(debtor);
  };

  const isSettled = debtor.amount <= 0;

  // Debt duration & alert calculation
  const daysElapsed = calculateDaysElapsed(debtor.createdAt);
  const alertThreshold = settings?.alertDaysThreshold ?? 1;
  const isAlertEnabled = settings?.enableDebtAlerts ?? true;
  const hasDurationAlert = isAlertEnabled && !isSettled && daysElapsed >= alertThreshold;

  // High debt threshold calculation
  const highThreshold = settings?.highDebtThreshold ?? 25000;
  const isHighDebt = !isSettled && debtor.amount >= highThreshold;
  const isManuallyOverdue = debtor.status === 'متأخر';

  return (
    <div
      className={`bg-white high-contrast-card rounded-2xl p-3 sm:p-3.5 border border-slate-200/90 shadow-[0_2px_10px_-2px_rgba(0,0,0,0.06)] relative flex flex-col gap-2.5 select-none transition-all hover:shadow-md ${
        menuOpen ? 'z-50' : 'z-0'
      }`}
      style={{ zIndex: menuOpen ? 999 : 1 }}
    >
      {/* Colored vertical accent line */}
      <div
        className={`absolute start-0 top-0 bottom-0 w-1.5 sm:w-2 rounded-s-2xl ${
          isSettled
            ? 'bg-emerald-500'
            : hasDurationAlert || isManuallyOverdue
            ? 'bg-rose-500'
            : 'bg-amber-500'
        }`}
      />

      {/* Row 1: Debtor Identity (Avatar + Name with space for long names + Phone/Date) & Options Menu */}
      <div className="flex items-start justify-between gap-2 ps-1.5">
        {/* Start side: Avatar + Name info */}
        <div className="flex items-center gap-2.5 min-w-0 flex-1 text-start">
          {/* Avatar Circle */}
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-blue-100/70 border border-blue-200/50 flex items-center justify-center text-blue-600 shrink-0 shadow-2xs">
            <i className="fa-solid fa-user text-xs sm:text-sm text-blue-600"></i>
          </div>

          {/* Name & Details */}
          <div className="min-w-0 flex-1 text-start">
            <div className="flex items-center gap-1.5 min-w-0">
              <span
                className="font-bold text-[13.5px] sm:text-[14.5px] text-slate-900 leading-tight truncate hover:text-blue-700 transition-colors cursor-pointer"
                title={debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
                onClick={(e) => {
                  e.stopPropagation();
                  onEditName?.(debtor);
                }}
              >
                {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onEditName?.(debtor);
                }}
                className="w-4.5 h-4.5 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                title={t('debts.editDebtorName', "تعديل اسم وهاتف المدين")}
              >
                <i className="fa-solid fa-pen text-[8.5px]"></i>
              </button>
            </div>

            {/* Date and Phone Number */}
            <div className="flex items-center gap-2 text-[10.5px] sm:text-[11.5px] text-slate-600 font-sans mt-0.5 flex-wrap">
              {debtor.phone ? (
                <span className="font-mono text-slate-800 font-semibold flex items-center gap-1 text-[11px]" dir="ltr">
                  <i className="fa-solid fa-phone text-[9px] text-slate-500"></i>
                  <span>{debtor.phone}</span>
                </span>
              ) : (
                <span className="text-slate-500 text-[10.5px] font-medium">{t('common.optional', 'بدون هاتف')}</span>
              )}
              {debtor.createdAt && (
                <>
                  <span className="text-slate-400">•</span>
                  <span className="text-[10.5px] text-slate-700 font-medium flex items-center gap-1 font-sans">
                    <i className="fa-regular fa-calendar text-[9.5px] text-slate-500"></i>
                    <span>{formatDateArabic(debtor.createdAt)}</span>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* End side: 3-dots Menu Button */}
        <div className={`relative shrink-0 ${menuOpen ? 'z-50' : ''}`} ref={menuRef}>
          <button
            ref={buttonRef}
            type="button"
            onClick={handleToggleMenu}
            className="w-7 h-7 rounded-xl hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-700 cursor-pointer transition-colors"
            title={t('common.actions', "خيارات")}
          >
            <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
          </button>

          {/* Dropdown Menu */}
          {menuOpen && (
            <div
              className={`absolute end-0 bg-white border border-slate-200/90 rounded-2xl shadow-2xl w-48 z-50 py-1.5 animate-in fade-in zoom-in-95 duration-100 text-start ring-1 ring-black/5 ${
                openUpwards ? 'bottom-full mb-1.5' : 'top-8'
              }`}
            >
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onEditName?.(debtor);
                }}
                className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-pen-to-square text-blue-600 text-xs shrink-0"></i>
                <span className="font-bold">{t('debts.editDebtorName', "تعديل اسم المدين")}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  exportSingleDebtorPdf(debtor, null, undefined, 'english');
                }}
                className="w-full px-3.5 py-2 text-start text-xs font-bold text-slate-700 hover:bg-purple-50 hover:text-purple-700 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-file-pdf text-purple-600 text-xs shrink-0"></i>
                <span>تصدير PDF الكشف</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onShare?.(debtor);
                }}
                className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-share-nodes text-blue-600 text-xs shrink-0"></i>
                <span>{t('modals.shareDebtorTitle', "مشاركة كشف الحساب")}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setMenuOpen(false);
                  onViewHistory?.(debtor);
                }}
                className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-clock-rotate-left text-blue-600 text-xs shrink-0"></i>
                <span>{t('common.history', "سجل العمليات")}</span>
              </button>
              <button
                type="button"
                onClick={handleWhatsAppReminder}
                className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-600 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-brands fa-whatsapp text-emerald-500 text-sm shrink-0"></i>
                <span>{t('debts.sendReminder', "تذكير واتساب")}</span>
              </button>
              <div className="my-1 border-t border-slate-100"></div>
              <button
                type="button"
                onClick={handleDelete}
                className="w-full px-3.5 py-2 text-start text-xs text-red-600 hover:bg-red-50 flex items-center gap-2.5 cursor-pointer transition-colors"
              >
                <i className="fa-regular fa-trash-can text-red-500 text-xs shrink-0"></i>
                <span>{t('common.delete', "حذف السجل")}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Row 2: Debt Amount & Status Badge */}
      <div className="flex items-center justify-between gap-2.5 ps-1.5">
        <div className="flex items-baseline gap-1">
          <span
            className={`text-[13px] sm:text-[14px] font-bold font-mono tracking-tight ${
              isSettled
                ? 'text-emerald-600'
                : isHighDebt
                ? 'text-red-600'
                : 'text-slate-900'
            }`}
          >
            {formatMoney(debtor.amount)}
          </span>
        </div>

        {/* Status Badges */}
        <div className="flex items-center gap-1.5">
          {isSettled ? (
            <span className="bg-emerald-50 text-emerald-600 border border-emerald-200/50 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs">
              {t('common.completed', 'خالي من الدين')}
            </span>
          ) : hasDurationAlert || isManuallyOverdue ? (
            <span
              className="bg-rose-50 text-rose-600 border border-rose-200/60 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs inline-flex items-center gap-1"
            >
              <i className="fa-solid fa-clock-rotate-left text-[8.5px] text-rose-500"></i>
              <span>{t('common.overdue', 'متأخر')}</span>
            </span>
          ) : (
            <span className="bg-amber-50 text-amber-600 border border-amber-200/60 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs">
              {t('common.active', 'المتبقي')}
            </span>
          )}

          {isHighDebt && !isSettled && (
            <span className="bg-red-50 text-red-600 border border-red-200/60 px-2 py-0.5 rounded-full text-[9.5px] font-black shadow-2xs">
              {t('debts.filterHighDebt', 'مرتفع')}
            </span>
          )}
        </div>
      </div>

      {/* Row 3: Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-0.5">
        <button
          type="button"
          onClick={() => onAddDebt(debtor)}
          className="w-full bg-[#f0f6ff] hover:bg-blue-100 active:scale-[0.98] text-blue-600 font-bold py-1.5 sm:py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs sm:text-[12.5px] cursor-pointer border border-blue-100 shadow-2xs"
          title={t('common.addDebt', "إضافة دين جديد")}
        >
          <i className="fa-solid fa-plus text-[10.5px] sm:text-xs"></i>
          <span>{t('common.addDebt', "إضافة دين")}</span>
        </button>

        <button
          type="button"
          onClick={() => onPay(debtor)}
          className="w-full bg-[#eafaf1] hover:bg-emerald-100 active:scale-[0.98] text-emerald-600 font-bold py-1.5 sm:py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs sm:text-[12.5px] cursor-pointer border border-emerald-100 shadow-2xs"
          title={t('common.settlePayment', "تسديد")}
        >
          <i className="fa-regular fa-credit-card text-xs sm:text-sm"></i>
          <span>{t('common.settlePayment', "تسديد")}</span>
        </button>
      </div>
    </div>
  );
};
