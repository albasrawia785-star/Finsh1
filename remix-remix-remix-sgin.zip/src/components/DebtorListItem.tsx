import React, { useState, useRef, useEffect } from 'react';
import { AppLayoutTheme, AppSettings, Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import {
  formatNumber,
  buildWhatsAppReminderUrl,
  formatIraqiPhoneNumber,
  calculateDaysElapsed,
  formatDateArabic
} from '../utils/formatters';
import { exportSingleDebtorPdf } from '../utils/pdfReportGenerator';

interface DebtorListItemProps {
  debtor: Debtor;
  onPay: (debtor: Debtor) => void;
  onAddDebt: (debtor: Debtor) => void;
  onDelete: (debtor: Debtor) => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onViewHistory?: (debtor: Debtor) => void;
  onShare?: (debtor: Debtor) => void;
  onEditName?: (debtor: Debtor) => void;
  settings?: AppSettings;
  layoutTheme?: AppLayoutTheme;
}

export const DebtorListItem: React.FC<DebtorListItemProps> = React.memo(({
  debtor,
  onPay,
  onAddDebt,
  onDelete,
  onShowToast,
  onViewHistory,
  onShare,
  onEditName,
  settings,
  layoutTheme: propTheme,
}) => {
  const { t, formatMoney } = useI18n();
  const theme: AppLayoutTheme = propTheme || settings?.layoutTheme || 'classic';
  const [menuOpen, setMenuOpen] = useState(false);
  const [openUpwards, setOpenUpwards] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('click', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('click', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
    };
  }, [menuOpen]);

  const handleToggleMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!menuOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      setOpenUpwards(spaceBelow < 240);
    }
    setMenuOpen(!menuOpen);
  };

  const handleWhatsAppReminder = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);

    if (!debtor.phone) {
      onShowToast(t('debts.emptyNoPhone', "لا يوجد رقم هاتف لهذا المدين"), "error");
      return;
    }

    const formatted = formatIraqiPhoneNumber(debtor.phone);
    if (!formatted || formatted.length < 10) {
      onShowToast(t('debts.invalidPhone', "رقم الهاتف غير صحيح أو مكتوب بصيغة خاطئة"), "error");
      return;
    }

    const isCreditor = debtor.type === 'creditor';
    const url = buildWhatsAppReminderUrl(debtor.phone, debtor.name, debtor.amount, isCreditor);
    window.open(url, '_blank');
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);
    onDelete(debtor);
  };

  const isSettled = debtor.amount <= 0;
  const daysElapsed = calculateDaysElapsed(debtor.createdAt);
  const alertThreshold = settings?.alertDaysThreshold ?? 1;
  const isAlertEnabled = settings?.enableDebtAlerts ?? true;
  const hasDurationAlert = isAlertEnabled && !isSettled && daysElapsed >= alertThreshold;
  const highThreshold = settings?.highDebtThreshold ?? 25000;
  const isHighDebt = !isSettled && debtor.amount >= highThreshold;
  const isManuallyOverdue = debtor.status === 'متأخر';

  // Shared Action Menu Component
  const renderDropdownMenu = () => (
    <div
      className={`absolute end-0 bg-white border border-slate-200/90 rounded-2xl shadow-2xl w-52 z-[100] py-1.5 animate-in fade-in zoom-in-95 duration-100 text-start ring-1 ring-black/5 ${
        openUpwards ? 'bottom-full mb-1.5' : 'top-8'
      }`}
    >
      <button
        type="button"
        onClick={() => {
          setMenuOpen(false);
          onEditName?.(debtor);
        }}
        className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-pen-to-square text-blue-600 text-xs shrink-0"></i>
        <span className="font-bold">{t('debts.editDebtorName', "تعديل اسم المدين")}</span>
      </button>
      <button
        type="button"
        onClick={() => {
          setMenuOpen(false);
          exportSingleDebtorPdf(debtor, null, undefined, 'english');
        }}
        className="w-full px-3.5 py-2 text-start text-xs font-bold text-slate-700 hover:bg-purple-50 hover:text-purple-700 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-file-pdf text-purple-600 text-xs shrink-0"></i>
        <span>تصدير PDF الكشف</span>
      </button>
      <button
        type="button"
        onClick={() => {
          setMenuOpen(false);
          onShare?.(debtor);
        }}
        className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-share-nodes text-blue-600 text-xs shrink-0"></i>
        <span>{t('modals.shareDebtorTitle', "مشاركة كشف الحساب")}</span>
      </button>
      <button
        type="button"
        onClick={() => {
          setMenuOpen(false);
          onViewHistory?.(debtor);
        }}
        className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-blue-50 hover:text-blue-700 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-clock-rotate-left text-blue-600 text-xs shrink-0"></i>
        <span>{t('common.history', "سجل العمليات")}</span>
      </button>
      <button
        type="button"
        onClick={handleWhatsAppReminder}
        className="w-full px-3.5 py-2 text-start text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-600 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-brands fa-whatsapp text-emerald-500 text-sm shrink-0"></i>
        <span>{t('debts.sendReminder', "تذكير واتساب")}</span>
      </button>
      <div className="my-1 border-t border-slate-100"></div>
      <button
        type="button"
        onClick={handleDelete}
        className="w-full px-3.5 py-2 text-start text-xs text-red-600 hover:bg-red-50 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-regular fa-trash-can text-red-500 text-xs shrink-0"></i>
        <span>{t('common.delete', "حذف السجل")}</span>
      </button>
    </div>
  );

  // -------------------------------------------------------------
  // THEME 1: FINTECH (Neo-Banking Clean Flow - تصميم 1 الحديث)
  // -------------------------------------------------------------
  if (theme === 'fintech') {
    const customerInitial = (debtor.name || 'ع').trim().charAt(0);
    return (
      <div
        className={`relative rounded-2xl p-3.5 transition-all select-none gpu-layer bg-white high-contrast-card border border-slate-200/90 shadow-[0_2px_10px_-2px_rgba(15,23,42,0.06)] hover:shadow-md ${
          isSettled ? 'border-emerald-200/70' : hasDurationAlert || isManuallyOverdue ? 'border-rose-200' : 'border-slate-200'
        } ${menuOpen ? 'z-50' : 'z-0'}`}
        style={{ zIndex: menuOpen ? 999 : 1 }}
      >
        {/* Top Header: Customer Info & Status Badge & Menu */}
        <div className="flex items-start justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2.5 min-w-0 flex-1 text-start">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-50 via-slate-50 to-emerald-50 text-blue-900 border border-blue-200/60 flex items-center justify-center font-black text-xs shrink-0 shadow-2xs">
              {customerInitial}
            </div>
            <div className="min-w-0 flex-1 text-start">
              <div
                className="text-sm font-black text-slate-900 truncate cursor-pointer hover:text-blue-600 transition-colors"
                onClick={(e) => { e.stopPropagation(); onEditName?.(debtor); }}
                title={debtor.name}
              >
                {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
              </div>
              <div className="text-[11px] text-slate-700 font-semibold font-mono mt-0.5 flex items-center gap-2 truncate">
                {debtor.phone ? (
                  <span dir="ltr" className="hover:text-blue-600 transition-colors">{debtor.phone}</span>
                ) : (
                  <span className="text-slate-500 font-medium">بدون هاتف</span>
                )}
                {debtor.createdAt && <span className="text-slate-600 font-medium">• {formatDateArabic(debtor.createdAt)}</span>}
              </div>
            </div>
          </div>

          {/* Right/End: Status Badge & 3-dots Menu */}
          <div className="flex items-center gap-1.5 shrink-0" ref={menuRef}>
            {debtor.type === 'creditor' ? (
              <span className="bg-rose-50 text-rose-700 border border-rose-200/80 px-2 py-0.5 rounded-full text-[10px] font-extrabold flex items-center gap-1">
                <i className="fa-solid fa-hand-holding-dollar text-[9px]"></i>
                <span>دين عليّ (يطلبني)</span>
              </span>
            ) : isSettled ? (
              <span className="bg-emerald-50 text-emerald-700 border border-emerald-200/80 px-2 py-0.5 rounded-full text-[10px] font-bold">
                خالي من الدين
              </span>
            ) : hasDurationAlert || isManuallyOverdue ? (
              <span className="bg-rose-50 text-rose-700 border border-rose-200/80 px-2 py-0.5 rounded-full text-[10px] font-bold">
                متأخر
              </span>
            ) : isHighDebt ? (
              <span className="bg-amber-50 text-amber-800 border border-amber-200/80 px-2 py-0.5 rounded-full text-[10px] font-bold">
                سقف مرتفع
              </span>
            ) : (
              <span className="bg-blue-50 text-blue-700 border border-blue-200/70 px-2 py-0.5 rounded-full text-[10px] font-bold">
                نشط
              </span>
            )}

            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center cursor-pointer transition-colors"
              title={t('common.more', 'المزيد من الخيارات')}
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        {/* Balance Box (Neo-Banking Deep Navy Display) */}
        <div className="bg-slate-50/90 rounded-xl p-2.5 mb-3 flex items-center justify-between border border-slate-200/70">
          <div>
            <div className="text-[10px] font-bold text-slate-400 mb-0.5">الرصيد المالي القائم</div>
            <div className="text-base font-black font-mono tracking-tight text-blue-950">
              {formatMoney(debtor.amount)}
            </div>
          </div>
          <div className="text-end">
            <div className="text-[10px] font-bold text-slate-400 mb-0.5">مؤشر السداد</div>
            <div className={`text-xs font-bold ${isSettled ? 'text-emerald-600' : 'text-slate-700'}`}>
              {isSettled ? 'مسدد بالكامل' : hasDurationAlert ? 'تجاوز المهلة' : 'قيد المتابعة'}
            </div>
          </div>
        </div>

        {/* Action Buttons: Emerald Pay + Cool Blue Add Debt */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onPay(debtor)}
            className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs active:scale-95"
          >
            <i className="fa-solid fa-check-circle text-xs"></i>
            <span>{debtor.type === 'creditor' ? 'تسديد له' : 'تسديد دفعة'}</span>
          </button>
          <button
            type="button"
            onClick={() => onAddDebt(debtor)}
            className={`flex-1 py-2 px-3 rounded-xl border font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer active:scale-95 ${
              debtor.type === 'creditor'
                ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border-rose-200/80'
                : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200/70'
            }`}
          >
            <i className="fa-solid fa-plus text-xs"></i>
            <span>{debtor.type === 'creditor' ? '+ دين عليّ' : 'إضافة دين'}</span>
          </button>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 2: BENTO (Bento Grid 3D)
  // -------------------------------------------------------------
  if (theme === 'bento') {
    return (
      <div
        className={`bg-white rounded-3xl p-3.5 border border-purple-100 shadow-sm relative flex flex-col gap-2.5 transition-all hover:border-purple-300 gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="grid grid-cols-3 gap-2 text-start">
          {/* Tile 1: Profile */}
          <div className="col-span-2 bg-purple-50/60 rounded-2xl p-2.5 border border-purple-100/80 flex flex-col justify-between">
            <div className="flex items-center justify-between gap-1">
              <span className="text-[10px] font-bold text-purple-600 uppercase">المدين</span>
              <span className={`w-2 h-2 rounded-full ${isSettled ? 'bg-emerald-500' : 'bg-purple-600'}`}></span>
            </div>
            <div
              className="font-black text-xs sm:text-sm text-slate-900 truncate mt-1 cursor-pointer hover:text-purple-700"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </div>
            <div className="text-[10px] font-mono text-slate-500 truncate mt-0.5">
              {debtor.phone || 'بدون هاتف'}
            </div>
          </div>

          {/* Tile 2: Options & Status */}
          <div className="col-span-1 bg-slate-50 rounded-2xl p-2.5 border border-slate-100 flex flex-col justify-between items-end relative" ref={menuRef}>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-6 h-6 rounded-lg bg-white hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer shadow-2xs"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}

            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-lg text-center w-full ${
              isSettled ? 'bg-emerald-100 text-emerald-800' : hasDurationAlert ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
            }`}>
              {isSettled ? 'مسدد' : hasDurationAlert ? 'متأخر' : 'نشط'}
            </span>
          </div>
        </div>

        {/* Tile 3: Financial Value & Actions */}
        <div className="bg-slate-900 text-white rounded-2xl p-2.5 flex items-center justify-between">
          <div className="text-start">
            <div className="text-[9.5px] text-slate-400 font-medium">المبلغ المستحق</div>
            <div className="text-sm font-black font-mono text-white">{formatMoney(debtor.amount)}</div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-2.5 py-1.5 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs cursor-pointer"
            >
              + دين
            </button>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-3 py-1.5 rounded-xl bg-purple-500 hover:bg-purple-600 text-white font-black text-xs cursor-pointer shadow-xs"
            >
              تسديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 3: LEDGER (Enterprise Ledger Table)
  // -------------------------------------------------------------
  if (theme === 'ledger') {
    return (
      <div
        className={`bg-white rounded-2xl border border-slate-200 shadow-2xs hover:border-emerald-300 transition-all text-start overflow-hidden gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="p-3 flex items-center justify-between gap-2.5 flex-wrap">
          {/* Identity */}
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <span className="w-2 h-2 rounded-full shrink-0 bg-emerald-500"></span>
            <div className="min-w-0">
              <div
                className="font-bold text-xs sm:text-[13.5px] text-slate-900 truncate cursor-pointer hover:text-emerald-700"
                onClick={() => onEditName?.(debtor)}
              >
                {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
              </div>
              <div className="text-[10px] font-mono text-slate-400">{debtor.phone || 'بدون هاتف'}</div>
            </div>
          </div>

          {/* Amount */}
          <div className="text-end">
            <div className="font-black font-mono text-xs sm:text-sm text-slate-900">{formatMoney(debtor.amount)}</div>
            <div className="text-[9.5px] text-slate-400">{formatDateArabic(debtor.createdAt || '')}</div>
          </div>

          {/* Fast Actions */}
          <div className="flex items-center gap-1.5 shrink-0" ref={menuRef}>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-200 cursor-pointer"
            >
              تسديد
            </button>
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
            >
              + دين
            </button>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-7 h-7 rounded-xl hover:bg-slate-100 text-slate-500 flex items-center justify-center cursor-pointer"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 4: MINIMAL LUXURY (Ultra Minimalist Luxury)
  // -------------------------------------------------------------
  if (theme === 'minimal_luxury') {
    return (
      <div
        className={`bg-white/95 rounded-3xl p-4 border border-slate-200/70 shadow-2xs hover:shadow-md transition-all text-start relative flex flex-col gap-3 gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <span className="text-[9px] font-bold tracking-widest text-amber-700/80 uppercase">CLIENT ACCOUNT</span>
            <div
              className="text-sm sm:text-base font-black text-slate-900 truncate cursor-pointer hover:text-amber-800"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">{debtor.phone || 'بدون هاتف'}</div>
          </div>

          <div className="flex items-center gap-1.5" ref={menuRef}>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-7 h-7 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-500 flex items-center justify-center cursor-pointer"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        <div className="flex items-baseline justify-between border-t border-slate-100 pt-2.5">
          <div className="text-base sm:text-lg font-black font-mono text-slate-900 tracking-tight">
            {formatMoney(debtor.amount)}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs cursor-pointer"
            >
              إضافة
            </button>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-4 py-1.5 rounded-xl bg-slate-900 hover:bg-black text-white font-black text-xs cursor-pointer shadow-xs"
            >
              تسديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 5: FLOATING GLASS (Floating Glass Cards)
  // -------------------------------------------------------------
  if (theme === 'floating_glass') {
    return (
      <div
        className={`bg-gradient-to-br from-white/95 via-cyan-50/20 to-white rounded-3xl p-3.5 border border-cyan-100/90 shadow-sm hover:shadow-cyan-100/50 hover:border-cyan-300 transition-all text-start relative flex flex-col gap-2.5 gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div className="w-8 h-8 rounded-2xl bg-cyan-100/80 text-cyan-700 flex items-center justify-center text-xs font-black shadow-2xs">
              <i className="fa-solid fa-gem"></i>
            </div>
            <div className="min-w-0">
              <div
                className="font-black text-xs sm:text-sm text-slate-900 truncate cursor-pointer hover:text-cyan-700"
                onClick={() => onEditName?.(debtor)}
              >
                {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
              </div>
              <div className="text-[10px] font-mono text-cyan-800/70">{debtor.phone || 'بدون هاتف'}</div>
            </div>
          </div>

          <div className="flex items-center gap-1" ref={menuRef}>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-7 h-7 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-700 flex items-center justify-center cursor-pointer"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        <div className="bg-white/80 rounded-2xl p-2 border border-cyan-100/60 flex items-center justify-between">
          <div>
            <div className="text-[9.5px] text-slate-400 font-medium">الرصيد الكلي</div>
            <div className="font-black font-mono text-sm text-cyan-950">{formatMoney(debtor.amount)}</div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-2.5 py-1.5 rounded-xl bg-cyan-50 hover:bg-cyan-100 text-cyan-800 font-bold text-xs cursor-pointer"
            >
              + دين
            </button>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-black text-xs cursor-pointer shadow-xs"
            >
              تسديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 6: COMPACT DENSE (Compact Dense Feed)
  // -------------------------------------------------------------
  if (theme === 'compact_dense') {
    return (
      <div
        className={`bg-white rounded-xl p-2.5 border border-slate-200 shadow-2xs hover:bg-slate-50/80 transition-all text-start flex items-center justify-between gap-2 select-none gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full shrink-0 ${isSettled ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            <span
              className="font-bold text-xs text-slate-900 truncate cursor-pointer hover:text-blue-600"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </span>
          </div>
          <div className="text-[9.5px] font-mono text-slate-400 ps-3.5">{debtor.phone || 'بدون هاتف'}</div>
        </div>

        <div className="font-black font-mono text-xs text-slate-900 shrink-0">
          {formatMoney(debtor.amount)}
        </div>

        <div className="flex items-center gap-1 shrink-0" ref={menuRef}>
          <button
            type="button"
            onClick={() => onPay(debtor)}
            className="px-2 py-1 rounded-lg bg-emerald-600 text-white font-bold text-[10.5px] cursor-pointer"
          >
            تسديد
          </button>
          <button
            ref={buttonRef}
            type="button"
            onClick={handleToggleMenu}
            className="w-6 h-6 rounded-lg hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer"
          >
            <i className="fa-solid fa-ellipsis-vertical text-[10px]"></i>
          </button>
          {menuOpen && renderDropdownMenu()}
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 7: TIMELINE (Timeline & Milestones)
  // -------------------------------------------------------------
  if (theme === 'timeline') {
    return (
      <div
        className={`bg-white rounded-3xl p-3.5 border-s-4 ${
          isSettled ? 'border-s-emerald-500' : hasDurationAlert ? 'border-s-rose-500' : 'border-s-indigo-500'
        } border border-slate-200 shadow-2xs hover:shadow-sm transition-all text-start relative flex flex-col gap-2.5 gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <i className="fa-solid fa-timeline text-xs text-indigo-600"></i>
            <div
              className="font-black text-xs sm:text-sm text-slate-900 truncate cursor-pointer hover:text-indigo-600"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </div>
          </div>

          <div className="flex items-center gap-1.5" ref={menuRef}>
            <span className="text-[10px] font-mono font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
              {daysElapsed} يوم مضى
            </span>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-6 h-6 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center cursor-pointer"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        <div className="flex items-center justify-between bg-slate-50 rounded-2xl p-2.5 border border-slate-100">
          <div>
            <div className="text-[9.5px] text-slate-400">تاريخ التسجيل: {formatDateArabic(debtor.createdAt || '')}</div>
            <div className="text-sm font-black font-mono text-slate-900">{formatMoney(debtor.amount)}</div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-2.5 py-1 rounded-xl bg-white border border-slate-200 text-slate-700 font-bold text-xs cursor-pointer"
            >
              + دين
            </button>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-3 py-1 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs cursor-pointer shadow-xs"
            >
              تسديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 8: RETAIL MODERN (Modern Retail Cards)
  // -------------------------------------------------------------
  if (theme === 'retail_modern') {
    return (
      <div
        className={`bg-white rounded-3xl p-4 border-2 border-teal-100 shadow-xs hover:border-teal-300 transition-all text-start relative flex flex-col gap-3 gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="flex items-center gap-1.5 text-[10px] font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded-lg w-fit mb-1">
              <i className="fa-solid fa-store text-[9px]"></i>
              <span>عميل صالة المبيعات</span>
            </div>
            <div
              className="text-sm sm:text-base font-black text-slate-900 truncate cursor-pointer hover:text-teal-700"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </div>
            <div className="text-[11px] font-mono text-slate-500 mt-0.5">{debtor.phone || 'بدون هاتف'}</div>
          </div>

          <div className="text-end" ref={menuRef}>
            <div className="font-black font-mono text-base text-teal-900">{formatMoney(debtor.amount)}</div>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="mt-1 text-[11px] text-slate-400 hover:text-slate-700 font-bold flex items-center gap-1 ms-auto cursor-pointer"
            >
              <span>خيارات</span>
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        {/* Big Retail Touch Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100">
          <button
            type="button"
            onClick={() => onAddDebt(debtor)}
            className="py-2.5 px-3 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all"
          >
            <i className="fa-solid fa-plus text-xs text-teal-600"></i>
            <span>إضافة بضاعة/دين</span>
          </button>
          <button
            type="button"
            onClick={() => onPay(debtor)}
            className="py-2.5 px-3 rounded-2xl bg-teal-600 hover:bg-teal-700 text-white font-black text-xs flex items-center justify-center gap-1.5 cursor-pointer active:scale-95 transition-all shadow-sm"
          >
            <i className="fa-solid fa-cash-register text-xs"></i>
            <span>قبض وتسديد</span>
          </button>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // THEME 9: STUDIO ANALYTICS (Futuristic Pro Analytics)
  // -------------------------------------------------------------
  if (theme === 'studio_analytics') {
    const healthScore = isSettled ? 100 : hasDurationAlert ? 35 : 85;
    return (
      <div
        className={`bg-slate-900 text-white rounded-3xl p-4 border border-violet-800/40 shadow-md relative flex flex-col gap-3 text-start gpu-layer ${
          menuOpen ? 'z-40' : 'z-0'
        }`}
      >
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-1.5 text-[9.5px] font-mono text-violet-300">
              <i className="fa-solid fa-chart-line text-violet-400"></i>
              <span>ANALYTICS PROFILE</span>
            </div>
            <div
              className="text-sm font-black text-white truncate cursor-pointer hover:text-violet-300"
              onClick={() => onEditName?.(debtor)}
            >
              {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
            </div>
          </div>

          <div className="flex items-center gap-1.5" ref={menuRef}>
            <div className={`px-2 py-0.5 rounded-full text-[10px] font-black font-mono border ${
              healthScore >= 80 ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
            }`}>
              التزام {healthScore}%
            </div>
            <button
              ref={buttonRef}
              type="button"
              onClick={handleToggleMenu}
              className="w-6 h-6 rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 flex items-center justify-center cursor-pointer"
            >
              <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
            </button>
            {menuOpen && renderDropdownMenu()}
          </div>
        </div>

        <div className="bg-white/5 rounded-2xl p-2.5 border border-white/10 flex items-center justify-between">
          <div>
            <div className="text-[9.5px] text-slate-400">صافي المتبقي</div>
            <div className="text-base font-black font-mono text-violet-300">{formatMoney(debtor.amount)}</div>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => onAddDebt(debtor)}
              className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs cursor-pointer"
            >
              + دين
            </button>
            <button
              type="button"
              onClick={() => onPay(debtor)}
              className="px-3.5 py-1.5 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-black text-xs cursor-pointer shadow-xs"
            >
              تسديد
            </button>
          </div>
        </div>
      </div>
    );
  }

  // -------------------------------------------------------------
  // DEFAULT THEME (CLASSIC NATIVE PRO)
  // -------------------------------------------------------------
  return (
    <div
      className={`bg-white rounded-2xl p-3 sm:p-3.5 border border-slate-100 shadow-[0_2px_10px_-2px_rgba(0,0,0,0.04)] relative flex flex-col gap-2.5 select-none transition-all hover:shadow-md fast-list-item ${
        menuOpen ? 'z-50' : 'z-0'
      }`}
      style={{ zIndex: menuOpen ? 999 : 1 }}
    >
      {/* Colored vertical accent line */}
      <div
        className={`absolute start-0 top-0 bottom-0 w-1.5 sm:w-2 rounded-s-2xl ${
          isSettled
            ? 'bg-emerald-500'
            : hasDurationAlert || isManuallyOverdue
            ? 'bg-rose-500'
            : 'bg-amber-500'
        }`}
      />

      {/* Row 1: Debtor Identity */}
      <div className="flex items-start justify-between gap-2 ps-1.5">
        <div className="flex items-center gap-2.5 min-w-0 flex-1 text-start">
          <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-blue-100/70 border border-blue-200/50 flex items-center justify-center text-blue-600 shrink-0 shadow-2xs">
            <i className="fa-solid fa-user text-xs sm:text-sm text-blue-600"></i>
          </div>

          <div className="min-w-0 flex-1 text-start">
            <div className="flex items-center gap-1.5 min-w-0">
              <span
                className="font-bold text-[13.5px] sm:text-[14.5px] text-slate-900 leading-tight truncate hover:text-blue-700 transition-colors cursor-pointer"
                title={debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
                onClick={(e) => {
                  e.stopPropagation();
                  onEditName?.(debtor);
                }}
              >
                {debtor.name || t('debts.unnamedDebtor', 'مدين بدون اسم')}
              </span>
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onEditName?.(debtor);
                }}
                className="w-4.5 h-4.5 rounded-md text-slate-400 hover:text-blue-600 hover:bg-blue-50 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                title={t('debts.editDebtorName', "تعديل اسم وهاتف المدين")}
              >
                <i className="fa-solid fa-pen text-[8.5px]"></i>
              </button>
            </div>

            <div className="flex items-center gap-2 text-[10px] sm:text-[11px] text-slate-400 font-sans mt-0.5 flex-wrap">
              {debtor.phone ? (
                <span className="font-mono text-slate-500 flex items-center gap-1 text-[10.5px]" dir="ltr">
                  <i className="fa-solid fa-phone text-[8.5px] text-slate-400"></i>
                  <span>{debtor.phone}</span>
                </span>
              ) : (
                <span className="text-slate-400 text-[10px]">{t('common.optional', 'بدون هاتف')}</span>
              )}
              {debtor.createdAt && (
                <>
                  <span className="text-slate-300">•</span>
                  <span className="text-[10px] text-slate-400 flex items-center gap-1 font-sans">
                    <i className="fa-regular fa-calendar text-[9px] text-slate-400"></i>
                    <span>{formatDateArabic(debtor.createdAt)}</span>
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* 3-dots Menu Button */}
        <div className={`relative shrink-0 ${menuOpen ? 'z-50' : ''}`} ref={menuRef}>
          <button
            ref={buttonRef}
            type="button"
            onClick={handleToggleMenu}
            className="w-7 h-7 rounded-xl hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-700 cursor-pointer transition-colors"
            title={t('common.actions', "خيارات")}
          >
            <i className="fa-solid fa-ellipsis-vertical text-xs"></i>
          </button>
          {menuOpen && renderDropdownMenu()}
        </div>
      </div>

      {/* Row 2: Debt Amount & Status Badge */}
      <div className="flex items-center justify-between gap-2.5 ps-1.5">
        <div className="flex items-baseline gap-1">
          <span
            className={`text-[13px] sm:text-[14px] font-bold font-mono tracking-tight ${
              isSettled
                ? 'text-emerald-600'
                : isHighDebt
                ? 'text-red-600'
                : 'text-slate-900'
            }`}
          >
            {formatMoney(debtor.amount)}
          </span>
        </div>

        <div className="flex items-center gap-1.5">
          {isSettled ? (
            <span className="bg-emerald-50 text-emerald-600 border border-emerald-200/50 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs">
              {t('common.completed', 'خالي من الدين')}
            </span>
          ) : hasDurationAlert || isManuallyOverdue ? (
            <span
              className="bg-rose-50 text-rose-600 border border-rose-200/60 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs inline-flex items-center gap-1"
            >
              <i className="fa-solid fa-clock-rotate-left text-[8.5px] text-rose-500"></i>
              <span>{t('common.overdue', 'متأخر')}</span>
            </span>
          ) : (
            <span className="bg-amber-50 text-amber-600 border border-amber-200/60 px-2.5 py-0.5 rounded-full text-[10.5px] font-bold shadow-2xs">
              {t('common.active', 'المتبقي')}
            </span>
          )}

          {isHighDebt && !isSettled && (
            <span className="bg-red-50 text-red-600 border border-red-200/60 px-2 py-0.5 rounded-full text-[9.5px] font-black shadow-2xs">
              {t('debts.filterHighDebt', 'مرتفع')}
            </span>
          )}
        </div>
      </div>

      {/* Row 3: Action Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-0.5">
        <button
          type="button"
          onClick={() => onAddDebt(debtor)}
          className="w-full bg-[#f0f6ff] hover:bg-blue-100 active:scale-[0.98] text-blue-600 font-bold py-1.5 sm:py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs sm:text-[12.5px] cursor-pointer border border-blue-100 shadow-2xs"
          title={t('common.addDebt', "إضافة دين جديد")}
        >
          <i className="fa-solid fa-plus text-[10.5px] sm:text-xs"></i>
          <span>{t('common.addDebt', "إضافة دين")}</span>
        </button>

        <button
          type="button"
          onClick={() => onPay(debtor)}
          className="w-full bg-[#eafaf1] hover:bg-emerald-100 active:scale-[0.98] text-emerald-600 font-bold py-1.5 sm:py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 text-xs sm:text-[12.5px] cursor-pointer border border-emerald-100 shadow-2xs"
          title={t('common.settlePayment', "تسديد")}
        >
          <i className="fa-regular fa-credit-card text-xs sm:text-sm"></i>
          <span>{t('common.settlePayment', "تسديد")}</span>
        </button>
      </div>
    </div>
  );
});

DebtorListItem.displayName = 'DebtorListItem';
