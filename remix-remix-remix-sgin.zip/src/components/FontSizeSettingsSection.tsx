import React from 'react';
import { AppFontSize } from '../types';
import { FONT_SIZE_OPTIONS, applyAppFontSize } from '../utils/fontSize';
import { useI18n } from '../i18n/index.tsx';

interface FontSizeSettingsSectionProps {
  currentFontSize: AppFontSize;
  onSelectFontSize: (size: AppFontSize) => void;
}

export const FontSizeSettingsSection: React.FC<FontSizeSettingsSectionProps> = ({
  currentFontSize = 'default',
  onSelectFontSize,
}) => {
  const { t, getCurrencySymbol } = useI18n();

  const handleSelect = (size: AppFontSize) => {
    applyAppFontSize(size);
    onSelectFontSize(size);
  };

  const activeOption = FONT_SIZE_OPTIONS.find((opt) => opt.id === currentFontSize) || FONT_SIZE_OPTIONS[1];

  return (
    <div className="space-y-4 text-start">
      {/* Header Info */}
      <div className="flex items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <i className="fa-solid fa-text-height text-indigo-600"></i>
            <span>حجم الخط والنصوص في التطبيق</span>
          </h4>
          <p className="text-xs text-slate-500 mt-0.5">
            التحكم المباشر في حجم خطوط التطبيق بشكل معزول ومستقل تماماً عن إعدادات خط الجهاز، مع الحفاظ الكامل على أبعاد الصفحات والجداول.
          </p>
        </div>

        <div className="shrink-0 bg-indigo-50 border border-indigo-200 text-indigo-700 px-2.5 py-1 rounded-xl text-xs font-bold font-mono">
          {activeOption.badge}
        </div>
      </div>

      {/* Live Interactive Preview Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-950 text-white shadow-md border border-slate-700/60 space-y-2.5">
        <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <i className="fa-solid fa-eye text-indigo-400"></i>
            <span>معاينة حية لشكل النصوص والحجم المختار</span>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 font-mono">
            الحجم: {activeOption.title}
          </span>
        </div>

        {/* Mock debtor item preview */}
        <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 border border-white/10 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="font-black text-sm text-white truncate">
              علي حسين البصري
            </div>
            <div className="text-xs text-slate-300 truncate mt-0.5">
              07701234567 • تسديد أسبوعي
            </div>
          </div>
          <div className="text-end shrink-0">
            <div className="font-black text-sm text-emerald-400 font-mono">
              150,000 {getCurrencySymbol()}
            </div>
            <span className="inline-block mt-0.5 text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-400/20">
              منتظم في السداد
            </span>
          </div>
        </div>
      </div>

      {/* Grid of 5 Font Size Options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
        {FONT_SIZE_OPTIONS.map((item) => {
          const isSelected = currentFontSize === item.id;
          return (
            <div
              key={item.id}
              onClick={() => handleSelect(item.id)}
              className={`relative rounded-2xl p-3.5 border-2 transition-all cursor-pointer flex flex-col justify-between gap-2.5 select-none ${
                isSelected
                  ? 'border-indigo-600 bg-indigo-50/50 shadow-sm ring-2 ring-indigo-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/60'
              }`}
            >
              {/* Top Row: Icon + Title + Scale + Radio */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center text-sm shrink-0 border ${
                      isSelected
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <i className={item.icon}></i>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-black text-xs text-slate-900 leading-tight">
                        {item.title}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-indigo-700 bg-indigo-100/70 px-1.5 py-0.2 rounded-md">
                      {item.scalePercent}
                    </span>
                  </div>
                </div>

                <div className="shrink-0">
                  <div
                    className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-600 text-white'
                        : 'border-slate-300 bg-white'
                    }`}
                  >
                    {isSelected && <i className="fa-solid fa-check text-[10px]"></i>}
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {item.description}
              </p>

              {/* Quick Select Button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleSelect(item.id);
                }}
                className={`w-full py-1.5 px-2.5 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs ${
                  isSelected
                    ? 'bg-indigo-600 text-white hover:bg-indigo-700'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {isSelected ? (
                  <>
                    <i className="fa-solid fa-circle-check text-xs"></i>
                    <span>الحجم المعتمد حالياً</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-hand-pointer text-xs"></i>
                    <span>اختيار وتطبيق</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Reset to Default Button */}
      {currentFontSize !== 'default' && (
        <div className="pt-1 flex justify-end">
          <button
            type="button"
            onClick={() => handleSelect('default')}
            className="px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 transition-all flex items-center gap-2 cursor-pointer shadow-2xs"
          >
            <i className="fa-solid fa-rotate-left text-xs"></i>
            <span>إعادة ضبط الحجم إلى الافتراضي (100%)</span>
          </button>
        </div>
      )}
    </div>
  );
};
