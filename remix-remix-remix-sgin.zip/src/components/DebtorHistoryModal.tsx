import React, { useState } from 'react';
import { Debtor, DebtorTransaction, User } from '../types';
import { formatNumber, formatDateDigits, formatFullDateTime, buildWhatsAppReminderUrl } from '../utils/formatters';
import { exportSingleDebtorPdf } from '../utils/pdfReportGenerator';
import { useI18n } from '../i18n/index.tsx';

interface DebtorHistoryModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  currentUser?: User | null;
  storeName?: string;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onUpdateTransaction?: (debtorId: number, txId: string, newAmount: number, newNotes?: string, newDate?: string) => void;
  onDeleteTransaction?: (debtorId: number, txId: string) => void;
  onClearAllHistory?: (debtorId: number) => void;
}

interface MonthGroup {
  monthKey: string;
  monthTitle: string;
  transactions: DebtorTransaction[];
  totalAdded: number;
  totalPaid: number;
}

export const DebtorHistoryModal: React.FC<DebtorHistoryModalProps> = ({
  isOpen,
  debtor,
  currentUser,
  storeName,
  onClose,
  onShowToast,
  onUpdateTransaction,
  onDeleteTransaction,
  onClearAllHistory,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const [filterType, setFilterType] = useState<'all' | 'add' | 'pay'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedTxId, setExpandedTxId] = useState<string | null>(null);
  const [isConfirmClearOpen, setIsConfirmClearOpen] = useState<boolean>(false);

  // Month collapse state: record of monthKey -> boolean (true if collapsed)
  const [collapsedMonths, setCollapsedMonths] = useState<Record<string, boolean>>({});

  // Transaction Edit & Delete State
  const [editingTx, setEditingTx] = useState<DebtorTransaction | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [deletingTx, setDeletingTx] = useState<DebtorTransaction | null>(null);

  if (!isOpen || !debtor) return null;

  const currSym = getCurrencySymbol();

  // Build history list, fallback to initial creation entry if empty
  const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
    ? debtor.history
    : [
        {
          id: `initial-${debtor.id}`,
          debtorId: debtor.id,
          type: 'initial',
          amount: debtor.amount,
          balanceAfter: debtor.amount,
          date: debtor.createdAt || new Date().toISOString(),
          description: t('debtorHistory.initialBalance', 'فتح حساب وتسجيل الرصيد الأولي'),
        },
      ];

  // Sort descending by date (newest first)
  const sortedHistory = [...rawHistory].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const filteredHistory = sortedHistory.filter((item) => {
    // Filter by type
    if (filterType === 'add' && !(item.type === 'add' || item.type === 'initial')) return false;
    if (filterType === 'pay' && item.type !== 'pay') return false;

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const descMatch = (item.description || '').toLowerCase().includes(q);
      const noteMatch = (item.notes || '').toLowerCase().includes(q);
      const amountMatch = item.amount.toString().includes(q);
      if (!descMatch && !noteMatch && !amountMatch) return false;
    }

    return true;
  });

  // Helper for Month title in Arabic
  const getMonthYearTitle = (dateStr: string): string => {
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return 'حركات أخرى';
      const monthNames = [
        'كانون الثاني (يناير)', 'شباط (فبراير)', 'آذار (مارس)', 'نيسان (أبريل)',
        'أيار (مايو)', 'حزيران (يونيو)', 'تموز (يوليو)', 'آب (أغسطس)',
        'أيلول (سبتمبر)', 'تشرين الأول (أكتوبر)', 'تشرين الثاني (نوفمبر)', 'كانون الأول (ديسمبر)'
      ];
      const mName = monthNames[d.getMonth()];
      const yStr = formatDateDigits(String(d.getFullYear()), numberFormat);
      return `${mName} ${yStr}`;
    } catch {
      return 'حركات أخرى';
    }
  };

  // Group filtered history into Monthly Accordions
  const monthGroups: MonthGroup[] = [];
  const groupMap: Record<string, MonthGroup> = {};

  filteredHistory.forEach((tx) => {
    let monthKey = 'other';
    try {
      const d = new Date(tx.date);
      if (!isNaN(d.getTime())) {
        monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      }
    } catch {}

    if (!groupMap[monthKey]) {
      const title = getMonthYearTitle(tx.date);
      groupMap[monthKey] = {
        monthKey,
        monthTitle: title,
        transactions: [],
        totalAdded: 0,
        totalPaid: 0,
      };
      monthGroups.push(groupMap[monthKey]);
    }

    groupMap[monthKey].transactions.push(tx);
    if (tx.type === 'add' || tx.type === 'initial') {
      groupMap[monthKey].totalAdded += tx.amount;
    } else if (tx.type === 'pay') {
      groupMap[monthKey].totalPaid += tx.amount;
    }
  });

  const toggleMonth = (mKey: string) => {
    setCollapsedMonths((prev) => ({ ...prev, [mKey]: !(prev[mKey] ?? true) }));
  };

  const toggleAllMonths = () => {
    const allCollapsed = monthGroups.every((g) => (collapsedMonths[g.monthKey] ?? true));
    const newState: Record<string, boolean> = {};
    monthGroups.forEach((g) => {
      newState[g.monthKey] = !allCollapsed;
    });
    setCollapsedMonths(newState);
  };

  // Calculate overall totals
  const totalAdded = rawHistory
    .filter((h) => h.type === 'add' || h.type === 'initial')
    .reduce((sum, h) => sum + h.amount, 0);

  const totalPaid = rawHistory
    .filter((h) => h.type === 'pay')
    .reduce((sum, h) => sum + h.amount, 0);

  const currentBalance = debtor.amount;

  // Format amount input with commas
  const handleAmountInputChange = (valStr: string) => {
    const raw = valStr.replace(/[^\d]/g, '');
    if (!raw) {
      setEditAmount('');
      return;
    }
    setEditAmount(Number(raw).toLocaleString('en-US'));
  };

  // Device current time helper
  const setCurrentDeviceTime = () => {
    const d = new Date();
    const iso = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    setEditDate(iso);
  };

  const handleCopyStatement = () => {
    try {
      let text = `*${t('debtorHistory.statementHeader', 'كشف حساب وسجل عمليات:')} ${debtor.name}*\n`;
      text += `${t('debtorHistory.phone', 'الهاتف:')} ${debtor.phone || t('debtorHistory.unregistered', 'غير مسجل')}\n`;
      if (debtor.notes) {
        text += `${t('debtorHistory.notes', 'ملاحظات:')} ${debtor.notes}\n`;
      }
      text += `* ${t('debtorHistory.currentBalance', 'الرصيد المتبقي:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorHistory.totalDebts', 'إجمالي الديون:')} ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorHistory.totalPaid', 'إجمالي المسدد:')} ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;
      text += `--------------------\n`;
      text += `*${t('debtorHistory.opsDetails', 'تفاصيل العمليات السابقة:')}*\n`;

      sortedHistory.forEach((tx, idx) => {
        const typeStr =
          tx.type === 'pay'
            ? t('common.settlePayment', 'تسديد دفعة')
            : tx.type === 'initial'
            ? t('debtorShare.initialType', 'رصيد أولي')
            : t('common.addDebt', 'إضافة دين');
        const sign = tx.type === 'pay' ? '-' : '+';
        text += `${idx + 1}) ${typeStr}: ${sign}${formatNumber(tx.amount, numberFormat)} ${currSym}\n`;
        text += `   ${t('common.date', 'التاريخ')}: ${formatFullDateTime(tx.date, numberFormat)}\n`;
        if (tx.notes || (tx.description && tx.description !== 'إضافة دين جديد' && tx.description !== 'تسديد دفعة نقدية')) {
          text += `   ${t('common.notes', 'ملاحظة')}: ${tx.notes || tx.description}\n`;
        }
        text += `   ${t('debtorHistory.balanceAfter', 'الرصيد بعد العملية:')} ${formatNumber(tx.balanceAfter, numberFormat)} ${currSym}\n`;
      });

      navigator.clipboard.writeText(text);
      onShowToast(t('toast.copiedToClipboard', 'تم النسخ إلى الحافظة بنجاح'), 'success');
    } catch {
      onShowToast(t('toast.copyFailed', 'تعذر نسخ كشف الحساب'), 'error');
    }
  };

  const handleShareWhatsApp = () => {
    if (!debtor.phone) {
      onShowToast(t('toast.phoneRequiredWhatsApp', 'لا يوجد رقم هاتف مسجل لهذا العميل'), 'error');
      return;
    }

    let text = `${t('debtorShare.greeting', 'السلام عليكم')} ${debtor.name}،\n${t('debtorHistory.statementWhatsAppIntro', 'إليك كشف الحساب وسجل العمليات الخاص بك:')}\n`;
    text += `* ${t('debtorHistory.currentBalance', 'الرصيد المتبقي:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
    text += `* ${t('debtorHistory.totalDebts', 'إجمالي الديون:')} ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
    text += `* ${t('debtorHistory.totalPaid', 'إجمالي المسدد:')} ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;
    text += `--------------------\n${t('debtorShare.recentOperations', 'آخر العمليات:')}\n`;

    sortedHistory.slice(0, 5).forEach((tx) => {
      const typeStr = tx.type === 'pay' ? t('debtorShare.paymentType', 'تسديد') : t('debtorShare.debtType', 'دين');
      const sign = tx.type === 'pay' ? '-' : '+';
      text += `• ${typeStr}: ${sign}${formatNumber(tx.amount, numberFormat)} ${currSym} (${formatFullDateTime(tx.date, numberFormat)})\n`;
    });

    const url = buildWhatsAppReminderUrl(debtor.phone, debtor.name, undefined);
    const baseWithoutText = url.split('?')[0];
    const fullUrl = `${baseWithoutText}?text=${encodeURIComponent(text)}`;
    window.open(fullUrl, '_blank');
  };

  return (
    <div
      className="fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-2.5 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
      dir={dir}
    >
      <div
        className="bg-white rounded-2xl w-full max-w-lg shadow-xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100/80 animate-in zoom-in-95 duration-200 text-start"
        onClick={(e) => e.stopPropagation()}
        id="debtorHistoryModal"
      >
        {/* 1. HEADER: Customer Name at Top */}
        <div className="px-3.5 py-3 border-b border-slate-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
              {debtor.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <h2 className="text-sm sm:text-base font-bold text-slate-800 leading-tight truncate">
                {debtor.name}
              </h2>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5 flex-wrap">
                {debtor.phone ? (
                  <span className="font-mono text-slate-500 dir-ltr flex items-center gap-1">
                    <i className="fa-solid fa-phone text-[9px] text-slate-400"></i>
                    {debtor.phone}
                  </span>
                ) : (
                  <span className="text-slate-400 text-[10px]">لا يوجد هاتف</span>
                )}
                {debtor.notes && (
                  <>
                    <span className="text-slate-300">•</span>
                    <span className="text-[10px] text-slate-500 truncate max-w-[130px]">{debtor.notes}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => exportSingleDebtorPdf(debtor, currentUser, storeName, numberFormat)}
              className="px-2.5 py-1.5 rounded-full bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-1 text-xs font-bold transition-colors cursor-pointer"
              title="تصدير كشف حساب PDF"
            >
              <i className="fa-solid fa-file-pdf text-[11px]"></i>
              <span>PDF</span>
            </button>
            {rawHistory.length > 0 && (
              <button
                type="button"
                onClick={() => setIsConfirmClearOpen(true)}
                className="w-8 h-8 rounded-full bg-rose-50 hover:bg-rose-100 text-rose-600 flex items-center justify-center cursor-pointer transition-colors"
                title={t('debtorHistory.clearAllHistory', 'مسح وتصفير كافة حركات السجل')}
              >
                <i className="fa-solid fa-trash-can text-[11px]"></i>
              </button>
            )}
            <button
              type="button"
              onClick={handleCopyStatement}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center cursor-pointer transition-colors"
              title={t('debtorHistory.copyStatement', 'نسخ كشف الحساب')}
            >
              <i className="fa-regular fa-copy text-[11px]"></i>
            </button>
            {debtor.phone && (
              <button
                type="button"
                onClick={handleShareWhatsApp}
                className="w-8 h-8 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-600 flex items-center justify-center cursor-pointer transition-colors"
                title={t('debtorHistory.sendWhatsApp', 'مشاركة واتساب')}
              >
                <i className="fa-brands fa-whatsapp text-xs"></i>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center cursor-pointer transition-colors mr-0.5"
              title={t('common.close', 'إغلاق')}
            >
              <i className="fa-solid fa-xmark text-xs"></i>
            </button>
          </div>
        </div>

        {/* BODY */}
        <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50/50">

          {/* 2. COMPACT BALANCE SUMMARY CARD */}
          <div className="bg-white rounded-xl p-3 border border-slate-200/80 shadow-2xs">
            <div className="text-center pb-2 mb-2 border-b border-slate-100">
              <span className="text-[10.5px] font-bold text-slate-400 block mb-0.5">
                {t('debtorHistory.currentBalance', 'الرصيد المتبقي')}
              </span>
              <div
                className={`text-xl sm:text-2xl font-bold font-mono tracking-tight ${
                  currentBalance <= 0 ? 'text-emerald-600' : 'text-blue-700'
                }`}
              >
                {formatNumber(currentBalance, numberFormat)}
                <span className="text-[11px] font-normal text-slate-400 mx-1 font-sans">{currSym}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="bg-rose-50/50 p-1.5 rounded-lg border border-rose-100/70">
                <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                  {t('debtorHistory.totalDebts', 'إجمالي الديون')}
                </span>
                <span className="text-xs sm:text-sm font-bold text-rose-600 font-mono">
                  +{formatNumber(totalAdded, numberFormat)} <span className="text-[9px] font-normal text-slate-400">{currSym}</span>
                </span>
              </div>

              <div className="bg-emerald-50/50 p-1.5 rounded-lg border border-emerald-100/70">
                <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                  {t('debtorHistory.totalPaid', 'إجمالي المسدد')}
                </span>
                <span className="text-xs sm:text-sm font-bold text-emerald-600 font-mono">
                  -{formatNumber(totalPaid, numberFormat)} <span className="text-[9px] font-normal text-slate-400">{currSym}</span>
                </span>
              </div>
            </div>
          </div>

          {/* 3. SEARCH & FILTER */}
          <div className="space-y-2">
            <div className="relative">
              <i className="fa-solid fa-magnifying-glass absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-[11px] pointer-events-none"></i>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="بحث في الحركات أو الملاحظات..."
                className="w-full pr-8 pl-8 py-1.5 bg-white border border-slate-200/80 rounded-lg text-xs font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                >
                  <i className="fa-solid fa-circle-xmark"></i>
                </button>
              )}
            </div>

            <div className="flex items-center justify-between gap-1.5">
              <div className="flex items-center gap-1 bg-slate-200/60 p-0.5 rounded-lg flex-1">
                <button
                  type="button"
                  onClick={() => setFilterType('all')}
                  className={`flex-1 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                    filterType === 'all'
                      ? 'bg-white text-slate-800 shadow-2xs font-extrabold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t('common.all', 'الكل')} ({rawHistory.length})
                </button>

                <button
                  type="button"
                  onClick={() => setFilterType('add')}
                  className={`flex-1 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                    filterType === 'add'
                      ? 'bg-white text-rose-600 shadow-2xs font-extrabold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t('debtorHistory.filterDebts', 'ديون')} ({rawHistory.filter((h) => h.type === 'add' || h.type === 'initial').length})
                </button>

                <button
                  type="button"
                  onClick={() => setFilterType('pay')}
                  className={`flex-1 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer ${
                    filterType === 'pay'
                      ? 'bg-white text-emerald-600 shadow-2xs font-extrabold'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t('debtorHistory.filterPayments', 'تسديدات')} ({rawHistory.filter((h) => h.type === 'pay').length})
                </button>
              </div>

              {monthGroups.length > 1 && (
                <button
                  type="button"
                  onClick={toggleAllMonths}
                  className="px-2.5 py-1 bg-white border border-slate-200/80 rounded-lg text-[10.5px] font-bold text-slate-600 hover:text-slate-800 hover:bg-slate-50 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
                  title="طي/فتح جميع الأقسام الشهرية"
                >
                  <i className="fa-solid fa-layer-group text-[10px] text-blue-600"></i>
                  <span>طي/فتح الأقسام</span>
                </button>
              )}
            </div>
          </div>

          {/* 4. TRANSACTIONS ACCORDIONS LIST */}
          <div className="space-y-3">
            {monthGroups.length === 0 ? (
              <div className="text-center py-8 bg-white rounded-xl border border-slate-200/60 p-4">
                <i className="fa-regular fa-folder-open text-2xl text-slate-300 mb-1.5 block"></i>
                <p className="text-xs font-bold text-slate-500">
                  {t('debtorHistory.noTransactions', 'لا توجد حركات تطابق هذا الفلتر أو البحث')}
                </p>
              </div>
            ) : (
              monthGroups.map((group) => {
                const isCollapsed = collapsedMonths[group.monthKey] ?? true;

                return (
                  <div key={group.monthKey} className="space-y-1.5">
                    {/* ACCORDION HEADER FOR EACH MONTH */}
                    <div
                      onClick={() => toggleMonth(group.monthKey)}
                      className="bg-slate-100 hover:bg-slate-200/80 transition-colors p-2 rounded-xl flex items-center justify-between cursor-pointer border border-slate-200/60 select-none"
                    >
                      <div className="flex items-center gap-2">
                        <i
                          className={`fa-solid fa-chevron-down text-[10px] text-slate-500 transition-transform duration-200 ${
                            isCollapsed ? '-rotate-90' : 'rotate-0'
                          }`}
                        ></i>
                        <span className="text-xs font-bold text-slate-800">
                          {group.monthTitle}
                        </span>
                        <span className="text-[10px] font-bold text-slate-400 bg-white px-1.5 py-0.5 rounded-md border border-slate-200/60 font-mono">
                          {group.transactions.length}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[10px] font-mono">
                        {group.totalAdded > 0 && (
                          <span className="text-rose-600 font-bold">
                            +{formatNumber(group.totalAdded, numberFormat)} {currSym}
                          </span>
                        )}
                        {group.totalPaid > 0 && (
                          <span className="text-emerald-600 font-bold">
                            -{formatNumber(group.totalPaid, numberFormat)} {currSym}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* MONTH TRANSACTIONS LIST */}
                    {!isCollapsed && (
                      <div className="space-y-1.5 pl-1 pr-1">
                        {group.transactions.map((tx) => {
                          const isPay = tx.type === 'pay';
                          const isInitial = tx.type === 'initial';
                          const isExpanded = expandedTxId === tx.id;

                          return (
                            <div
                              key={tx.id}
                              onClick={() => setExpandedTxId(isExpanded ? null : tx.id)}
                              className={`bg-white rounded-xl p-2.5 sm:p-3 border transition-all cursor-pointer select-none ${
                                isExpanded
                                  ? 'border-blue-500 ring-2 ring-blue-500/10 shadow-xs'
                                  : 'border-slate-200/80 hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-center justify-between gap-2.5">
                                {/* Left: Compact Icon & Description */}
                                <div className="flex items-center gap-2.5 min-w-0">
                                  <div
                                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 font-bold text-xs ${
                                      isPay
                                        ? 'bg-emerald-50 text-emerald-600 border border-emerald-100'
                                        : isInitial
                                        ? 'bg-amber-50 text-amber-600 border border-amber-100'
                                        : 'bg-rose-50 text-rose-600 border border-rose-100'
                                    }`}
                                  >
                                    {isPay ? (
                                      <i className="fa-solid fa-arrow-down-left text-[11px]"></i>
                                    ) : isInitial ? (
                                      <i className="fa-solid fa-wallet text-[11px]"></i>
                                    ) : (
                                      <i className="fa-solid fa-plus text-[11px]"></i>
                                    )}
                                  </div>

                                  <div className="truncate">
                                    <div className="font-bold text-xs text-slate-800 flex items-center gap-1.5 truncate">
                                      <span className="truncate">{tx.notes || tx.description || (isPay ? 'تسديد دفعة' : 'إضافة دين')}</span>
                                      <i className={`fa-solid ${isExpanded ? 'fa-chevron-up text-blue-600' : 'fa-chevron-down text-slate-400'} text-[9px] shrink-0 transition-transform`}></i>
                                    </div>

                                    <div className="text-[9.5px] text-slate-400 mt-0.5 flex items-center gap-1 font-mono">
                                      <i className="fa-regular fa-calendar-days text-[8.5px]"></i>
                                      <span>{formatFullDateTime(tx.date, numberFormat)}</span>
                                    </div>
                                  </div>
                                </div>

                                {/* Right: Amount & Balance after */}
                                <div className="text-left shrink-0">
                                  <div
                                    className={`text-xs sm:text-sm font-bold font-mono ${
                                      isPay ? 'text-emerald-600' : 'text-rose-600'
                                    }`}
                                  >
                                    {isPay ? '-' : '+'}
                                    {formatNumber(tx.amount, numberFormat)}
                                    <span className="text-[9px] font-normal text-slate-400 mx-0.5 font-sans">{currSym}</span>
                                  </div>

                                  <div className="text-[9.5px] text-slate-400 font-mono mt-0.5">
                                    <span className="text-[8.5px] text-slate-400 font-sans mx-0.5">بعد العملية:</span>
                                    {formatNumber(tx.balanceAfter, numberFormat)} {currSym}
                                  </div>
                                </div>
                              </div>

                              {/* EXPANDED DETAILS: Show Full Notes, Edit & Delete when tapped */}
                              {isExpanded && (
                                <div
                                  className="mt-2.5 pt-2.5 border-t border-slate-100 space-y-2.5 animate-in fade-in duration-150"
                                  onClick={(e) => e.stopPropagation()}
                                >
                                  {/* Full Notes Container for Long Text */}
                                  {(tx.notes || tx.description) && (
                                    <div className="p-2.5 bg-slate-50/90 rounded-xl border border-slate-200/80 text-xs text-slate-800 leading-relaxed break-words font-medium space-y-1">
                                      <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500">
                                        <i className="fa-solid fa-note-sticky text-amber-500"></i>
                                        <span>تفاصيل الملاحظات الكاملة:</span>
                                      </div>
                                      <p className="text-slate-900 font-bold select-text leading-snug whitespace-pre-wrap" dir="auto">
                                        {tx.notes || tx.description}
                                      </p>
                                    </div>
                                  )}

                                  <div className="flex items-center justify-between gap-2">
                                    <div className="text-[11px] text-slate-500">
                                      <span className="font-bold text-slate-700">نوع الحركة: </span>
                                      <span>{isPay ? 'تسديد دفعة' : isInitial ? 'رصيد أولي' : 'إضافة دين'}</span>
                                    </div>

                                    <div className="flex items-center gap-1.5">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setEditingTx(tx);
                                          setEditAmount(tx.amount ? Number(tx.amount).toLocaleString('en-US') : '');
                                          setEditNotes(tx.notes || tx.description || '');
                                          try {
                                            const d = tx.date ? new Date(tx.date) : new Date();
                                            const iso = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
                                            setEditDate(iso);
                                          } catch {
                                            setEditDate('');
                                          }
                                        }}
                                        className="px-2.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg text-[11px] font-bold border border-blue-200/80 flex items-center gap-1 cursor-pointer transition-colors"
                                      >
                                        <i className="fa-solid fa-pen-to-square text-[10px]"></i>
                                        <span>تعديل</span>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => setDeletingTx(tx)}
                                        className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg text-[11px] font-bold border border-rose-200/80 flex items-center gap-1 cursor-pointer transition-colors"
                                      >
                                        <i className="fa-solid fa-trash-can text-[10px]"></i>
                                        <span>حذف</span>
                                      </button>
                                    </div>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* FOOTER */}
        <div className="p-3 bg-white border-t border-slate-100 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold cursor-pointer transition-colors"
          >
            {t('common.close', 'إغلاق')}
          </button>
        </div>
      </div>

      {/* EDIT TRANSACTION MODAL */}
      {editingTx && (
        <div
          className="fixed inset-0 bg-slate-900/60 z-60 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setEditingTx(null)}
        >
          <div
            className="bg-white rounded-2xl p-4 sm:p-5 w-full max-w-sm shadow-xl border border-slate-100 space-y-3 animate-in zoom-in-95 duration-200 text-start"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold">
                  <i className="fa-solid fa-pen-to-square"></i>
                </div>
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-800">
                    {t('debtorHistory.editTxTitle', 'تعديل العملية الماليّة')}
                  </h3>
                  <p className="text-[10px] text-slate-400">
                    {editingTx.type === 'pay' ? t('common.settlePayment', 'تسديد دفعة') : t('common.addDebt', 'إضافة دين')}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setEditingTx(null)}
                className="w-7 h-7 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center cursor-pointer transition-colors"
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            </div>

            <div className="space-y-2.5">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    {t('debtorHistory.newAmountLabel', 'المبلغ الجديد')} ({currSym})
                  </label>
                  <span className="text-[9.5px] text-slate-400 font-mono">تنسيق الآلاف تلقائي</span>
                </div>
                <input
                  type="text"
                  inputMode="numeric"
                  value={editAmount}
                  onChange={(e) => handleAmountInputChange(e.target.value)}
                  className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg font-mono text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 text-left dir-ltr"
                  placeholder="0"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {t('common.notes', 'الملاحظات / وصف الحركة')}
                </label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 leading-relaxed resize-y"
                  placeholder={t('debtorHistory.notesPlaceholder', 'مثلاً: عمل طبلات عدد 1 سعر الطبله 60 الف...')}
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">
                    {t('common.date', 'تاريخ الحركة')}
                  </label>
                  <button
                    type="button"
                    onClick={setCurrentDeviceTime}
                    className="text-[10px] font-bold text-blue-600 hover:text-blue-800 bg-blue-50 hover:bg-blue-100 px-2 py-0.5 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <i className="fa-solid fa-calendar-day text-[9px]"></i>
                    <span>اليوم (تاريخ الجهاز)</span>
                  </button>
                </div>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1.5">
              <button
                type="button"
                onClick={() => {
                  const rawNum = editAmount.replace(/,/g, '');
                  const numVal = parseFloat(rawNum);
                  if (isNaN(numVal) || numVal < 0) {
                    onShowToast(t('debts.invalidAmount', 'يرجى إدخال مبلغ صحيح'), 'error');
                    return;
                  }
                  if (onUpdateTransaction) {
                    const formattedDate = editDate ? new Date(editDate).toISOString() : editingTx.date;
                    onUpdateTransaction(debtor.id, editingTx.id, numVal, editNotes, formattedDate);
                  }
                  setEditingTx(null);
                }}
                className="flex-1 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
              >
                {t('common.saveChanges', 'حفظ التعديل وإعادة الحساب')}
              </button>
              <button
                type="button"
                onClick={() => setEditingTx(null)}
                className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs cursor-pointer"
              >
                {t('common.cancel', 'إلغاء')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DELETE TRANSACTION CONFIRMATION MODAL */}
      {deletingTx && (
        <div
          className="fixed inset-0 bg-slate-900/60 z-60 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setDeletingTx(null)}
        >
          <div
            className="bg-white rounded-2xl p-4 sm:p-5 w-full max-w-sm shadow-xl border border-slate-100 space-y-3 animate-in zoom-in-95 duration-200 text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center text-lg font-bold shadow-2xs">
              <i className="fa-solid fa-trash-can"></i>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-800">
                {t('debtorHistory.deleteTxTitle', 'حذف هذه الحركة نهائياً؟')}
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                {t('debtorHistory.deleteTxConfirmDesc', 'سيتم إزالة الحركة')} (
                <span className="font-bold text-slate-700">
                  {deletingTx.type === 'pay' ? t('common.settlePayment', 'تسديد') : t('common.addDebt', 'دين')}: {formatNumber(deletingTx.amount, numberFormat)} {currSym}
                </span>
                ) {t('debtorHistory.recalculateNote', 'وسيتم إعادة احتساب الرصيد المتبقي للزبون تلقائياً.')}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1.5">
              <button
                type="button"
                onClick={() => {
                  if (onDeleteTransaction) {
                    onDeleteTransaction(debtor.id, deletingTx.id);
                  }
                  setDeletingTx(null);
                }}
                className="flex-1 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
              >
                {t('debtorHistory.confirmDeleteBtn', 'نعم، حذف الحركة')}
              </button>
              <button
                type="button"
                onClick={() => setDeletingTx(null)}
                className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs cursor-pointer"
              >
                {t('common.cancel', 'إلغاء')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CONFIRM CLEAR ALL HISTORY MODAL */}
      {isConfirmClearOpen && (
        <div
          className="fixed inset-0 bg-slate-900/60 z-60 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setIsConfirmClearOpen(false)}
        >
          <div
            className="bg-white rounded-2xl p-4 sm:p-5 w-full max-w-sm shadow-xl border border-slate-100 space-y-3 animate-in zoom-in-95 duration-200 text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-10 rounded-xl bg-rose-100 text-rose-600 mx-auto flex items-center justify-center text-lg font-bold shadow-2xs">
              <i className="fa-solid fa-trash-can"></i>
            </div>

            <div>
              <h3 className="text-sm font-bold text-slate-800">
                {t('debtorHistory.confirmClearTitle', 'تأكيد مسح حركات السجل بالكامل؟')}
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                {t('debtorHistory.confirmClearDesc', 'هل أنت متأكد من حذف كافة الحركات المسجلة لـ')} (<span className="font-bold text-slate-700">{debtor.name}</span>)؟
                {t('debtorHistory.confirmClearNote', ' سيتم تصفير رصيد الدين إلى (0) وحذف جميع المسجلات. لا يمكن التراجع عن هذا الإجراء.')}
              </p>
            </div>

            <div className="flex items-center gap-2 pt-1.5">
              <button
                type="button"
                onClick={() => {
                  if (onClearAllHistory) {
                    onClearAllHistory(debtor.id);
                  } else {
                    onShowToast(t('debtorHistory.clearedSuccess', 'تم مسح جميع الحركات بنجاح'), 'success');
                  }
                  setIsConfirmClearOpen(false);
                }}
                className="flex-1 py-2 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs shadow-xs transition-all cursor-pointer"
              >
                {t('debtorHistory.confirmClearBtn', 'نعم، مسح السجل بالكامل')}
              </button>
              <button
                type="button"
                onClick={() => setIsConfirmClearOpen(false)}
                className="px-3 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-xs cursor-pointer"
              >
                {t('common.cancel', 'إلغاء')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
