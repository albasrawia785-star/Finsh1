import { ALDION_DATABASE_CONFIG, BACKUP_SYNC_DATABASES } from '../aldion';

interface DB {
  name: string;
  url: string;
  token: string;
}

const allDbs: DB[] = [
  { name: 'Primary DB', url: ALDION_DATABASE_CONFIG.url, token: ALDION_DATABASE_CONFIG.token },
  ...BACKUP_SYNC_DATABASES
];

function formatArg(arg: any) {
  if (arg === null || arg === undefined) return { type: 'null' };
  if (typeof arg === 'number') {
    return Number.isInteger(arg)
      ? { type: 'integer', value: String(arg) }
      : { type: 'float', value: arg };
  }
  if (typeof arg === 'boolean') return { type: 'integer', value: arg ? '1' : '0' };
  return { type: 'text', value: String(arg) };
}

function parseVal(cell: any) {
  if (cell === null || cell === undefined) return null;
  if (typeof cell === 'object' && 'value' in cell) return cell.value;
  return cell;
}

async function query(db: DB, sql: string, args: any[] = []) {
  const res = await fetch(db.url, {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer ' + db.token,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      requests: [
        {
          type: 'execute',
          stmt: {
            sql,
            args: args.map(formatArg),
          },
        },
        { type: 'close' },
      ],
    }),
  });

  const data = await res.json();
  if (data.results?.[0]?.type === 'error') {
    throw new Error(`${db.name} Error: ` + (data.results[0].error?.message || 'Query failed'));
  }
  return data.results?.[0]?.response?.result;
}

async function getRows(db: DB, sql: string, args: any[] = []): Promise<Record<string, any>[]> {
  const result = await query(db, sql, args);
  if (!result || !result.cols || !result.rows) return [];
  const cols = result.cols.map((c: any) => (typeof c === 'string' ? c : c.name));
  return result.rows.map((row: any[]) => {
    const obj: Record<string, any> = {};
    cols.forEach((col: string, idx: number) => {
      obj[col] = parseVal(row[idx]);
    });
    return obj;
  });
}

async function reconcileTable(tableName: string, primaryKey: string, createTableSql?: string) {
  console.log(`\n========================================`);
  console.log(`🔄 Reconciling table: [${tableName}] by PK [${primaryKey}]`);
  console.log(`========================================`);

  // Ensure table exists on all DBs
  if (createTableSql) {
    for (const db of allDbs) {
      try {
        await query(db, createTableSql);
      } catch (e: any) {
        console.warn(`Table create note for ${db.name}:`, e.message);
      }
    }
  }

  // Fetch all rows from all DBs
  const rowsByDb: Map<string, Record<string, any>[]> = new Map();
  const allRecordsMap: Map<any, Record<string, any>> = new Map();

  for (const db of allDbs) {
    try {
      const rows = await getRows(db, `SELECT * FROM ${tableName};`);
      rowsByDb.set(db.name, rows);
      console.log(`- ${db.name}: found ${rows.length} rows`);
      
      for (const row of rows) {
        const pkVal = row[primaryKey];
        if (pkVal === undefined || pkVal === null) continue;
        
        if (!allRecordsMap.has(pkVal)) {
          allRecordsMap.set(pkVal, row);
        } else {
          // Merge / prefer record with most non-null fields or newer updated_at
          const existing = allRecordsMap.get(pkVal)!;
          const merged = { ...existing, ...row };
          allRecordsMap.set(pkVal, merged);
        }
      }
    } catch (e: any) {
      console.error(`Error reading ${tableName} from ${db.name}:`, e.message);
    }
  }

  const allRecords = Array.from(allRecordsMap.values());
  console.log(`📊 Unified total unique records for [${tableName}]: ${allRecords.length}`);

  if (allRecords.length === 0) {
    console.log(`No records to sync for ${tableName}.`);
    return;
  }

  // Determine columns
  const firstRecord = allRecords[0];
  const columns = Object.keys(firstRecord);
  const placeholders = columns.map(() => '?').join(', ');
  const upsertSql = `INSERT OR REPLACE INTO ${tableName} (${columns.join(', ')}) VALUES (${placeholders});`;

  // Upsert all records into every database
  for (const db of allDbs) {
    console.log(`💾 Syncing ${allRecords.length} records into [${db.name}]...`);
    let synced = 0;
    for (const record of allRecords) {
      const args = columns.map((col) => record[col] ?? null);
      try {
        await query(db, upsertSql, args);
        synced++;
      } catch (e: any) {
        console.error(`Failed to upsert row ${record[primaryKey]} to ${db.name}:`, e.message);
      }
    }
    console.log(`✅ [${db.name}]: Synced ${synced}/${allRecords.length} records in [${tableName}]`);
  }
}

async function verifyAllCounts() {
  console.log('\n\n========================================');
  console.log('🏁 VERIFICATION: ALL TABLE COUNTS ACROSS ALL DATABASES');
  console.log('========================================');
  
  const tables = ['users', 'debtors', 'installments', 'user_settings', 'suppliers', 'supplier_transactions'];
  
  for (const db of allDbs) {
    const counts: Record<string, any> = {};
    for (const t of tables) {
      try {
        const rows = await getRows(db, `SELECT COUNT(*) as count FROM ${t};`);
        counts[t] = rows[0]?.count ?? 'ERR';
      } catch (e: any) {
        counts[t] = 'NOT_FOUND';
      }
    }
    console.log(`✨ ${db.name}:`, JSON.stringify(counts));
  }
}

async function main() {
  console.log('🚀 Starting Full Cross-Database Reconciliation & Sync...');

  // 1. Users
  await reconcileTable('users', 'id', `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'viewer',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      branch_name TEXT,
      phone TEXT,
      status TEXT DEFAULT 'active',
      custom_permissions TEXT
    );
  `);

  // 2. Debtors
  await reconcileTable('debtors', 'id', `
    CREATE TABLE IF NOT EXISTS debtors (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      initial_debt REAL NOT NULL,
      current_debt REAL NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      notes TEXT,
      category TEXT,
      currency TEXT DEFAULT 'IQD',
      credit_limit REAL DEFAULT 0,
      due_date TEXT,
      updated_at DATETIME
    );
  `);

  // 3. Installments
  await reconcileTable('installments', 'id', `
    CREATE TABLE IF NOT EXISTS installments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      debtor_id INTEGER NOT NULL,
      user_id INTEGER,
      amount REAL NOT NULL,
      payment_date TEXT NOT NULL,
      notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      discount REAL DEFAULT 0,
      currency TEXT DEFAULT 'IQD'
    );
  `);

  // 4. User Settings
  await reconcileTable('user_settings', 'user_id', `
    CREATE TABLE IF NOT EXISTS user_settings (
      user_id INTEGER PRIMARY KEY,
      settings_json TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);

  // 5. Suppliers
  await reconcileTable('suppliers', 'id', `
    CREATE TABLE IF NOT EXISTS suppliers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      phone TEXT,
      initial_balance REAL NOT NULL DEFAULT 0,
      current_balance REAL NOT NULL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      notes TEXT,
      category TEXT,
      currency TEXT DEFAULT 'IQD',
      updated_at DATETIME
    );
  `);

  // 6. Supplier Transactions
  await reconcileTable('supplier_transactions', 'id', `
    CREATE TABLE IF NOT EXISTS supplier_transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      supplier_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      type TEXT NOT NULL,
      amount REAL NOT NULL,
      transaction_date TEXT NOT NULL,
      notes TEXT,
      invoice_number TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      currency TEXT DEFAULT 'IQD'
    );
  `);

  // Verify
  await verifyAllCounts();
}

main().catch((err) => {
  console.error('Reconciliation error:', err);
  process.exit(1);
});
