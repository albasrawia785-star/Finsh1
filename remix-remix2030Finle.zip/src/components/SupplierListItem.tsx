import React, { useState, useRef, useEffect } from 'react';
import { Supplier } from '../types';
import { formatNumber, formatDateOnly } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface SupplierListItemProps {
  supplier: Supplier;
  onPayClick: (supplier: Supplier) => void;
  onAddDebtClick: (supplier: Supplier) => void;
  onHistoryClick: (supplier: Supplier) => void;
  onEditClick?: (supplier: Supplier) => void;
  onDeleteSupplier?: (supplierId: number) => void;
  onShowToast?: (msg: string, type?: 'success' | 'error' | 'info') => void;
  currencySymbol?: string;
}

export const SupplierListItem: React.FC<SupplierListItemProps> = ({
  supplier,
  onPayClick,
  onAddDebtClick,
  onHistoryClick,
  onEditClick,
  onDeleteSupplier,
  onShowToast,
  currencySymbol = 'د.ع',
}) => {
  const { numberFormat } = useI18n();
  const [menuOpen, setMenuOpen] = useState(false);
  const [openUpwards, setOpenUpwards] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const isSettled = supplier.amount <= 0;

  const displayName = typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '');
  const displayCompany = typeof supplier.companyName === 'string' && supplier.companyName.trim() ? supplier.companyName.trim() : null;
  const displayPhone = typeof supplier.phone === 'string' && supplier.phone.trim() ? supplier.phone.trim() : null;
  const numAmount = Number(supplier.amount) || 0;

  const rawDate = supplier.lastTransactionDate || supplier.createdAt || (supplier.history && supplier.history.length > 0 ? supplier.history[supplier.history.length - 1].date : null);
  const displayDate = rawDate ? formatDateOnly(rawDate, numberFormat) : null;

  // Handle outside click to close dropdown menu reliably
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent | TouchEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target as Node) &&
        buttonRef.current &&
        !buttonRef.current.contains(e.target as Node)
      ) {
        setMenuOpen(false);
      }
    };
    if (menuOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('touchstart', handleOutsideClick);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('touchstart', handleOutsideClick);
    };
  }, [menuOpen]);

  const handleToggleMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!menuOpen && buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const spaceBelow = window.innerHeight - rect.bottom;
      setOpenUpwards(spaceBelow < 240);
    }
    setMenuOpen((prev) => !prev);
  };

  const handleWhatsAppShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);

    if (!displayPhone) {
      onShowToast?.("لا يوجد رقم هاتف مسجل لهذا المورد", "error");
      return;
    }

    const cleanPhone = displayPhone.replace(/[^0-9]/g, '');
    const formattedPhone = cleanPhone.startsWith('0') ? '964' + cleanPhone.substring(1) : cleanPhone;
    let text = `إشعار مطابقة رصيد حساب دائن\n\n`;
    text += `السيد/ ${displayName}\n`;
    if (displayCompany) {
      text += `الجهة / الشركة: ${displayCompany}\n`;
    }
    text += `تحية طيبة وبعد،\n\n`;
    text += `نود إشعاركم بمطابقة رصيد حسابكم المالي المسجل لدينا:\n\n`;
    text += `• إجمالي الرصيد المستحق لكم: ${formatNumber(numAmount, numberFormat)} ${currencySymbol}\n\n`;
    text += `شاكرين لكم حسن التعاون.`;

    window.open(`https://wa.me/${formattedPhone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    setMenuOpen(false);
    if (onDeleteSupplier) {
      onDeleteSupplier(supplier.id);
    }
  };

  // Three-dots dropdown menu renderer
  const renderDropdownMenu = () => (
    <div
      ref={menuRef}
      className={`absolute end-0 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl shadow-2xl w-56 z-[100] py-1.5 text-start ring-1 ring-black/5 animate-in fade-in zoom-in-95 duration-100 ${
        openUpwards ? 'bottom-full mb-1.5' : 'top-9'
      }`}
    >
      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setMenuOpen(false);
          onHistoryClick(supplier);
        }}
        className="w-full px-3.5 py-2 text-start text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-700 dark:hover:text-amber-400 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-clock-rotate-left text-amber-600 text-xs shrink-0"></i>
        <span>عرض كشف الحساب والسجل</span>
      </button>

      {displayPhone && (
        <button
          type="button"
          onClick={handleWhatsAppShare}
          className="w-full px-3.5 py-2 text-start text-xs font-bold text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 flex items-center gap-2.5 cursor-pointer transition-colors"
        >
          <i className="fa-brands fa-whatsapp text-emerald-600 text-sm shrink-0"></i>
          <span>مشاركة كشف عبر واتساب</span>
        </button>
      )}

      <button
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setMenuOpen(false);
          if (onEditClick) {
            onEditClick(supplier);
          } else {
            onHistoryClick(supplier);
          }
        }}
        className="w-full px-3.5 py-2 text-start text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-700 dark:hover:text-blue-400 flex items-center gap-2.5 cursor-pointer transition-colors"
      >
        <i className="fa-solid fa-pen-to-square text-blue-600 text-xs shrink-0"></i>
        <span>تعديل بيانات المورد / المندوب</span>
      </button>

      {onDeleteSupplier && (
        <div className="pt-1 mt-1 border-t border-slate-100 dark:border-slate-700/60">
          <button
            type="button"
            onClick={handleDelete}
            className="w-full px-3.5 py-2 text-start text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2.5 cursor-pointer transition-colors"
          >
            <i className="fa-solid fa-trash-can text-rose-500 text-xs shrink-0"></i>
            <span>حذف المورد نهائياً</span>
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className={`p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl border transition-all duration-200 text-start relative overflow-visible group shadow-xs ${
      isSettled
        ? 'bg-slate-50 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 opacity-85'
        : 'bg-white dark:bg-slate-900 border-amber-200/80 dark:border-amber-900/40 hover:border-amber-400 dark:hover:border-amber-600 shadow-amber-500/5'
    }`}>
      {/* Header Row */}
      <div className="flex items-start justify-between gap-2 mb-2">
        {/* Supplier Info */}
        <div className="flex items-start gap-2.5 min-w-0 flex-1">
          <div className={`w-9 h-9 rounded-2xl flex items-center justify-center text-sm shrink-0 font-bold ${
            isSettled 
              ? 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400' 
              : 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
          }`}>
            <i className="fa-solid fa-truck-field"></i>
          </div>

          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-black text-sm text-slate-900 dark:text-white truncate">
                {displayName}
              </h3>
              <span className={`px-2 py-0.5 rounded-full text-[9.5px] font-extrabold shrink-0 ${
                isSettled
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                  : 'bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-300'
              }`}>
                {isSettled ? 'خالص الذمة 100%' : 'مطلوب للمورد'}
              </span>
            </div>

            <div className="flex items-center gap-3 flex-wrap mt-0.5 text-[11px] font-medium text-slate-500 dark:text-slate-400">
              {displayCompany && displayCompany !== displayPhone && (
                <span className="font-bold text-amber-700 dark:text-amber-400 flex items-center gap-1">
                  <i className="fa-solid fa-building text-[10px]"></i>
                  <span>{displayCompany}</span>
                </span>
              )}
              {displayPhone && !displayName.includes(displayPhone) && (
                <span className="flex items-center gap-1 font-mono dir-ltr text-slate-600 dark:text-slate-300">
                  <i className="fa-solid fa-phone text-[9px] text-emerald-600"></i>
                  <span>{displayPhone}</span>
                </span>
              )}
              {displayDate && (
                <span className="text-[10px] font-bold text-slate-400 dark:text-slate-500 flex items-center gap-1 font-mono dir-ltr">
                  <i className="fa-regular fa-calendar-days text-[9px] text-amber-500"></i>
                  <span>{displayDate}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Action Menu (Three Dots ⋮) Button */}
        <div className="relative shrink-0">
          <button
            ref={buttonRef}
            type="button"
            onClick={handleToggleMenu}
            className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 flex items-center justify-center transition-all cursor-pointer"
            title="خيارات إضافية"
          >
            <i className="fa-solid fa-ellipsis-vertical text-sm"></i>
          </button>
          {menuOpen && renderDropdownMenu()}
        </div>
      </div>

      {/* Middle Row: Balance Amount */}
      <div className="my-2.5 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl flex items-center justify-between gap-3">
        <div>
          <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block mb-0.5">الدين المتبقي للمورد عليك</span>
          <span className="text-base sm:text-lg font-black text-amber-600 dark:text-amber-400 font-mono">
            {formatNumber(numAmount, numberFormat)} {currencySymbol}
          </span>
        </div>
      </div>

      {/* Footer Action Buttons: Only Add Debt & Pay (السجل button removed as requested) */}
      <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => onAddDebtClick(supplier)}
          className="flex-1 px-3 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center gap-1.5"
          title="إضافة بضاعة أو دين جديد للمورد"
        >
          <i className="fa-solid fa-plus text-[10px]"></i>
          <span>إضافة دين</span>
        </button>

        <button
          type="button"
          onClick={() => onPayClick(supplier)}
          className="flex-1 px-3 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95 flex items-center justify-center gap-1.5"
        >
          <i className="fa-solid fa-hand-holding-dollar text-[11px]"></i>
          <span>تسديد</span>
        </button>
      </div>
    </div>
  );
};
