/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface Product {
  id: string;
  commercialName: string;
  scientificName: string;
  manufacturer: string;
  categoryId: string;
  batchNumber: string;
  productionDate: string; // YYYY-MM-DD
  expirationDate: string; // YYYY-MM-DD
  buyPrice: number;       // In IQD
  sellPrice: number;      // In IQD
  wholesalePrice: number; // In IQD
  quantity: number;
  minStock: number;
  location: string;       // Shelf or section
  dosageForm?: string;    // e.g. "شريط", "كبسول", "أمبولة", "شراب", "بخاخ", "قطرات", "مستلزم طبي"
  barcode?: string;       // Barcode number (EAN-13, EAN-8, etc.)
  notes?: string;
}

export interface SaleInvoiceItem {
  productId: string;
  commercialName: string;
  scientificName: string;
  price: number;
  quantity: number;
  total: number;
}

export interface SaleInvoice {
  id: string;
  invoiceNumber: string;
  date: string; // ISO datetime
  customerId: string | null;
  items: SaleInvoiceItem[];
  subtotal: number;
  discount: number;
  total: number;
  notes?: string;
}

export interface PurchaseInvoiceItem {
  productId: string;
  commercialName: string;
  buyPrice: number;
  quantity: number;
  total: number;
}

export interface PurchaseInvoice {
  id: string;
  invoiceNumber: string;
  date: string; // ISO datetime
  supplierId: string;
  items: PurchaseInvoiceItem[];
  subtotal: number;
  total: number;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  debts: number; // In IQD
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address: string;
  balance: number; // In IQD (what we owe them)
}

export interface PharmacySettings {
  pharmacyName: string;
  address: string;
  phone: string;
  currency: string;
}
