/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import SplashScreen from "./components/SplashScreen";
import Navigation from "./components/Navigation";
import DashboardView from "./components/DashboardView";
import POSView from "./components/POSView";
import ProductsView from "./components/ProductsView";
import CategoriesView from "./components/CategoriesView";
import InvoicesView from "./components/InvoicesView";
import InventoryView from "./components/InventoryView";
import PurchasesView from "./components/PurchasesView";
import CustomersView from "./components/CustomersView";
import SuppliersView from "./components/SuppliersView";
import ReportsView from "./components/ReportsView";
import BackupView from "./components/BackupView";
import SettingsView from "./components/SettingsView";

import { IndexedDBService } from "./db/indexedDB";
import { PharmacySettings } from "./types";

import LoginView from "./components/LoginView";
import AdminView from "./components/AdminView";
import { FirebaseService } from "./firebase";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [darkMode, setDarkMode] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [lowStockCount, setLowStockCount] = useState(0);
  const [expiredCount, setExpiredCount] = useState(0);

  // Auth / Subscription states
  const [user, setUser] = useState<any>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Pharmacy config
  const [settings, setSettings] = useState<PharmacySettings>({
    pharmacyName: "صيدلية الياسمين التخصصية",
    address: "بغداد - الكرادة - قرب ساحة التحريات",
    phone: "07701234567",
    currency: "د.ع"
  });

  const handleLogout = () => {
    localStorage.removeItem("pharmapro_uid");
    localStorage.removeItem("pharmapro_username");
    localStorage.removeItem("pharmapro_role");
    localStorage.removeItem("pharmapro_pharmacyName");
    localStorage.removeItem("pharmapro_expireDate");
    localStorage.removeItem("pharmapro_ownerName");
    setUser(null);
    setIsLoggedIn(false);
    setActiveTab("dashboard");
  };

  const verifySession = async (uid: string) => {
    try {
      const res = await FirebaseService.syncSession(uid);
      if (res.success && res.user) {
        const synced = res.user;
        if (synced.username !== "ali" && synced.role !== "super_admin") {
          if (synced.active === false || synced.active === "false" || synced.active === 0) {
            handleLogout();
            alert("تم تعطيل هذا الحساب من قبل الإدارة!");
            return;
          }
          const todayStr = new Date().toISOString().split("T")[0];
          if (synced.expireDate < todayStr) {
            handleLogout();
            alert("انتهت صلاحية الاشتراك الخاص بك. يرجى التجديد.");
            return;
          }
        } else if (synced.username !== "ali" && synced.role === "super_admin") {
          if (synced.active === false || synced.active === "false" || synced.active === 0) {
            handleLogout();
            alert("تم تعطيل هذا الحساب من قبل الإدارة!");
            return;
          }
        }
        
        setUser(synced);
        localStorage.setItem("pharmapro_expireDate", synced.expireDate || "");
        localStorage.setItem("pharmapro_pharmacyName", synced.pharmacyName || "");
        localStorage.setItem("pharmapro_ownerName", synced.ownerName || "");
        if (synced.pharmacyName) {
          setSettings(prev => ({ ...prev, pharmacyName: synced.pharmacyName }));
        }
      }
    } catch (e) {
      console.log("Offline mode or sync failed, continuing with cached session.");
    }
  };

  // Calculate alerts dynamically on load or tab switch
  const calculateAlerts = async () => {
    try {
      const prods = await IndexedDBService.getAll<any>("products");
      const todayStr = new Date().toISOString().split("T")[0];
      const low = prods.filter((p) => p.quantity > 0 && p.quantity <= p.minStock).length;
      const exp = prods.filter((p) => p.expirationDate <= todayStr).length;
      setLowStockCount(low);
      setExpiredCount(exp);
    } catch (err) {
      console.error("Error calculating alerts:", err);
    }
  };

  // Load configuration and bootstrap DB on mount
  useEffect(() => {
    const bootstrap = async () => {
      try {
        // Initialize DB and Seed
        await IndexedDBService.initDB();
        
        // Fetch saved settings
        const savedSettings = await IndexedDBService.getSettings();
        if (savedSettings) {
          setSettings(savedSettings);
        }

        // Bootstrap Firebase (Pre-generate Super Admin ali if not exists)
        await FirebaseService.bootstrapSystem();

        // Check Local Storage Login Session
        const storedUid = localStorage.getItem("pharmapro_uid");
        if (storedUid) {
          const storedUser = {
            uid: storedUid,
            username: localStorage.getItem("pharmapro_username") || "",
            role: localStorage.getItem("pharmapro_role") || "user",
            pharmacyName: localStorage.getItem("pharmapro_pharmacyName") || "",
            expireDate: localStorage.getItem("pharmapro_expireDate") || "",
            ownerName: localStorage.getItem("pharmapro_ownerName") || ""
          };

          // Offline-first verification
          const todayStr = new Date().toISOString().split("T")[0];
          if (storedUser.username === "ali" || storedUser.role === "super_admin" || storedUser.expireDate >= todayStr) {
            setUser(storedUser);
            setIsLoggedIn(true);
            if (storedUser.pharmacyName) {
              setSettings(prev => ({ ...prev, pharmacyName: storedUser.pharmacyName }));
            }
            // Verify online in background
            verifySession(storedUid);
          } else {
            handleLogout();
          }
        }

        // Calculate initial alerts
        await calculateAlerts();

        // Simulating loading splash to make the UX smooth
        setTimeout(() => {
          setShowSplash(false);
        }, 2200);
      } catch (err) {
        console.error("Database boot failure:", err);
        setShowSplash(false);
      }
    };

    bootstrap();
  }, []);

  // Recalculate alerts when switching views
  useEffect(() => {
    if (!showSplash) {
      calculateAlerts();
    }
  }, [showSplash, activeTab]);

  // Sync dark mode class with root document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);

  const handleUpdateSettings = (newSettings: PharmacySettings) => {
    setSettings(newSettings);
  };

  const handleToggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  if (showSplash) {
    return <SplashScreen pharmacyName={settings.pharmacyName} />;
  }

  // Render active view component
  const renderActiveView = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardView currency={settings.currency} onNavigate={setActiveTab} />;
      case "pos":
        return <POSView currency={settings.currency} onNavigate={setActiveTab} />;
      case "products":
        return <ProductsView currency={settings.currency} />;
      case "categories":
        return <CategoriesView />;
      case "invoices":
        return <InvoicesView currency={settings.currency} />;
      case "inventory":
        return <InventoryView currency={settings.currency} />;
      case "purchases":
        return <PurchasesView currency={settings.currency} />;
      case "customers":
        return <CustomersView currency={settings.currency} />;
      case "suppliers":
        return <SuppliersView currency={settings.currency} />;
      case "reports":
        return <ReportsView currency={settings.currency} />;
      case "backup":
        return <BackupView />;
      case "settings":
        return (
          <SettingsView
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            darkMode={darkMode}
            onToggleDarkMode={handleToggleDarkMode}
          />
        );
      case "admin":
        return user?.role === "super_admin" ? <AdminView /> : <DashboardView currency={settings.currency} onNavigate={setActiveTab} />;
      default:
        return <DashboardView currency={settings.currency} onNavigate={setActiveTab} />;
    }
  };

  const handleLoginSuccess = (loggedInUser: any) => {
    setUser(loggedInUser);
    setIsLoggedIn(true);
    if (loggedInUser.pharmacyName) {
      setSettings(prev => ({ ...prev, pharmacyName: loggedInUser.pharmacyName }));
    }
  };

  if (!isLoggedIn) {
    return <LoginView onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-100 flex flex-col lg:flex-row rtl" dir="rtl">
      {/* Sidebar Navigation for Desktop & Bottom Nav for Mobile */}
      <Navigation
        currentView={activeTab}
        onViewChange={setActiveTab}
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        pharmacyName={settings.pharmacyName}
        logo=""
        lowStockCount={lowStockCount}
        expiredCount={expiredCount}
        userRole={user?.role}
        onLogout={handleLogout}
      />

      {/* Main content body */}
      <main className="flex-1 p-4 md:p-8 pb-24 md:pb-8 overflow-y-auto w-full max-w-7xl mx-auto">
        {renderActiveView()}
      </main>
    </div>
  );
}
