/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { initializeApp, getApps, getApp } from "firebase/app";
import { getDatabase, ref, set, get, child, update, remove } from "firebase/database";

// ==========================================
// 1. Firebase Configuration (تكوين فايربيس)
// ==========================================
// عند إنشاء مشروع Firebase Realtime Database جديد، يكفي فقط تعديل البيانات أدناه.
export const firebaseConfig = {
  apiKey: "AIzaSyAg1pfc-CcxjPFLqzUeeoNaP9LvBlJhKgA",
  authDomain: "project-2633249655177112121.firebaseapp.com",
  databaseURL: "https://project-2633249655177112121-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "project-2633249655177112121",
  storageBucket: "project-2633249655177112121.firebasestorage.app",
  messagingSenderId: "929737360669",
  appId: "1:929737360669:web:55e332f798c9cd0e9a8df4",
  measurementId: "G-8XXN1ZH86G"
};

// تهيئة تطبيق فايربيس مع معالجة الأخطاء والتحقق من التهيئة المسبقة
let app;
let db: any = null;
let isFirebaseConfigured = false;

if (
  firebaseConfig.apiKey &&
  firebaseConfig.apiKey !== "YOUR_API_KEY_HERE" &&
  firebaseConfig.databaseURL &&
  !firebaseConfig.databaseURL.includes("YOUR_PROJECT_ID")
) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    db = getDatabase(app);
    isFirebaseConfigured = true;
    console.log("Firebase Realtime Database initialized successfully!");
  } catch (err) {
    console.error("Firebase Initialization Error:", err);
  }
} else {
  console.warn("Firebase is not fully configured yet. Running in demo/local sandbox mode.");
}

// دالة مساعدة لتجنب تجمد النظام عند تأخر استجابة الخادم
function withTimeout<T>(promise: Promise<T>, ms: number = 3000): Promise<T> {
  let timeoutId: any;
  const timeoutPromise = new Promise<never>((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error("تأخر استجابة الخادم (Timeout)"));
    }, ms);
  });
  return Promise.race([
    promise.then((val) => {
      clearTimeout(timeoutId);
      return val;
    }),
    timeoutPromise
  ]);
}

// ==========================================
// 2. Pure JS SHA-256 Password Hash (تشفير آمن)
// ==========================================
export function hashPassword(ascii: string): string {
  function rightRotate(value: number, amount: number) {
    return (value >>> amount) | (value << (32 - amount));
  }
  
  const mathPow = Math.pow;
  const maxWord = mathPow(2, 32);
  const lengthProperty = 'length';
  let i, j;
  let result = '';

  const words: number[] = [];
  const asciiLength = ascii[lengthProperty];
  let hash: number[] = [];
  const k: number[] = [];
  let primeCounter = 0;

  const isPrime: { [key: number]: number } = {};
  for (let candidate = 2; primeCounter < 64; candidate++) {
    if (!isPrime[candidate]) {
      for (i = 0; i < 313; i += candidate) {
        isPrime[i] = i;
      }
      hash[primeCounter] = (mathPow(candidate, .5) * maxWord) | 0;
      k[primeCounter++] = (mathPow(candidate, 1 / 3) * maxWord) | 0;
    }
  }
  
  ascii += '\x80';
  while (ascii[lengthProperty] % 64 - 56) ascii += '\x00';
  for (i = 0; i < ascii[lengthProperty]; i++) {
    j = ascii.charCodeAt(i);
    if (j >> 8) return ""; // ASCII only
    words[i >> 2] |= j << ((3 - i) % 4 * 8);
  }
  words[words[lengthProperty]] = ((asciiLength * 8) / maxWord) | 0;
  words[words[lengthProperty]] = (asciiLength * 8);
  
  for (j = 0; j < words[lengthProperty];) {
    const w = words.slice(j, j += 16);
    const oldHash = hash.slice(0);
    
    for (i = 0; i < 64; i++) {
      let wItem = w[i];
      if (i < 16) {
        wItem = w[i];
      } else {
        const s0 = rightRotate(w[i - 15], 7) ^ rightRotate(w[i - 15], 18) ^ (w[i - 15] >>> 3);
        const s1 = rightRotate(w[i - 2], 17) ^ rightRotate(w[i - 2], 19) ^ (w[i - 2] >>> 10);
        wItem = w[i] = (w[i - 16] + s0 + w[i - 7] + s1) | 0;
      }
      
      const temp1 = (hash[7] + (rightRotate(hash[4], 6) ^ rightRotate(hash[4], 11) ^ rightRotate(hash[4], 25)) +
        ((hash[4] & hash[5]) ^ (~hash[4] & hash[6])) +
        k[i] + wItem) | 0;
      const temp2 = ((rightRotate(hash[0], 2) ^ rightRotate(hash[0], 13) ^ rightRotate(hash[0], 22)) +
        ((hash[0] & hash[1]) ^ (hash[0] & hash[2]) ^ (hash[1] & hash[2]))) | 0;
      
      hash = [(temp1 + temp2) | 0].concat(hash);
      hash[4] = (hash[4] + temp1) | 0;
      hash.length = 8;
    }
    
    for (i = 0; i < 8; i++) {
      hash[i] = (hash[i] + oldHash[i]) | 0;
    }
  }
  
  for (i = 0; i < 8; i++) {
    let val = hash[i];
    if (val < 0) val += maxWord;
    let str = val.toString(16);
    while (str[lengthProperty] < 8) str = '0' + str;
    result += str;
  }
  return result;
}

// Generate unique ID
export function generateUUID() {
  return "usr_" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

// Generate Random License Code: ABCD-1234-EFGH
export function generateLicenseCode() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const part = (len: number) => {
    let s = "";
    for (let i = 0; i < len; i++) {
      s += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return s;
  };
  return `${part(4)}-${part(4)}-${part(4)}`;
}

// Sandbox local storage keys for demo mode
const LOCAL_USERS_KEY = "pharmapro_sb_users";
const LOCAL_CODES_KEY = "pharmapro_sb_codes";

// Sanitize and guarantee all user properties are populated (Default values for missing keys, ignoring corrupted files)
export function sanitizeUser(u: any): any {
  if (!u || typeof u !== "object") return null;
  // If a record is extremely corrupted (e.g. no username and no uid), ignore it
  if (!u.username && !u.uid) return null;

  return {
    uid: u.uid || "",
    username: u.username || "",
    password: u.password || "",
    role: u.role || "user",
    active: u.active !== undefined ? (u.active === true || u.active === "true" || u.active === 1) : true,
    expireDate: u.expireDate || "",
    pharmacyName: u.pharmacyName || "",
    ownerName: u.ownerName || "",
    phone: u.phone || "",
    createdAt: u.createdAt || "",
    lastLogin: u.lastLogin || ""
  };
}

function getSandboxUsers(): any[] {
  const saved = localStorage.getItem(LOCAL_USERS_KEY);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed
          .map(u => sanitizeUser(u))
          .filter(Boolean);
      }
    } catch (e) {
      console.error("Error reading local sandbox users:", e);
    }
  }
  // Default ali Super Admin
  const defaultAdmin = {
    uid: "super_ali",
    username: "ali",
    password: hashPassword("19971997"),
    role: "super_admin",
    active: true,
    expireDate: "2099-12-31",
    pharmacyName: "إدارة النظام العام",
    ownerName: "علي",
    phone: "07700000000",
    createdAt: new Date().toISOString(),
    lastLogin: new Date().toISOString()
  };
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify([defaultAdmin]));
  return [defaultAdmin];
}

function saveSandboxUsers(users: any[]) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

function getSandboxCodes(): any[] {
  const saved = localStorage.getItem(LOCAL_CODES_KEY);
  if (saved) return JSON.parse(saved);
  const defaultCodes = [
    { code: "FREE-1MTH-CODE", duration: "1_month", used: false, usedBy: "", createdAt: new Date().toISOString() },
    { code: "GOLD-1YRS-CODE", duration: "1_year", used: false, usedBy: "", createdAt: new Date().toISOString() }
  ];
  localStorage.setItem(LOCAL_CODES_KEY, JSON.stringify(defaultCodes));
  return defaultCodes;
}

function saveSandboxCodes(codes: any[]) {
  localStorage.setItem(LOCAL_CODES_KEY, JSON.stringify(codes));
}

// Helper to check if online
export function isOnline(): boolean {
  return navigator.onLine;
}

// ==========================================
// 3. Main Exported Database API
// ==========================================

export const FirebaseService = {
  isConfigured(): boolean {
    return isFirebaseConfigured;
  },

  // 1. Bootstrap Database & Create Super Admin if not exists
  async bootstrapSystem(): Promise<void> {
    if (!isFirebaseConfigured) {
      // Initialize sandbox local storage values
      getSandboxUsers();
      getSandboxCodes();
      return;
    }

    try {
      const usersRef = ref(db, "users");
      const snapshot = await withTimeout(get(usersRef));
      let aliExists = false;

      if (snapshot.exists()) {
        const data = snapshot.val();
        for (const key in data) {
          if (data[key] && data[key].username === "ali") {
            aliExists = true;
            break;
          }
        }
      }

      if (!aliExists) {
        // Create Super Admin Ali
        const superAdminUid = "super_ali";
        await withTimeout(set(ref(db, `users/${superAdminUid}`), {
          uid: superAdminUid,
          username: "ali",
          password: hashPassword("19971997"),
          role: "super_admin",
          active: true,
          expireDate: "2099-12-31", // infinite
          pharmacyName: "إدارة النظام العام",
          ownerName: "علي",
          phone: "07700000000",
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString()
        }));
        console.log("Super Admin account 'ali' created in Realtime Database.");
      }
    } catch (err) {
      console.error("Failed to bootstrap Firebase Database:", err);
    }
  },

  // 2. Login User
  async login(username: string, passwordPlain: string): Promise<{ success: boolean; error?: string; user?: any }> {
    const hashed = hashPassword(passwordPlain);
    const lowerUsername = (username || "").trim().toLowerCase();

    // A. Demo Sandbox Mode (Offline/Unconfigured)
    if (!isFirebaseConfigured || !isOnline()) {
      console.log("Attempting login via Sandbox/LocalStorage fallback...");
      const users = getSandboxUsers();
      const matched = users.find(u => (u.username || "").toLowerCase() === lowerUsername);

      if (!matched) {
        return { success: false, error: "اسم المستخدم غير موجود!" };
      }
      if (matched.password !== hashed) {
        return { success: false, error: "كلمة المرور غير صحيحة!" };
      }
      
      if ((matched.username || "").toLowerCase() !== "ali") {
        if (!matched.active) {
          return { success: false, error: "DISABLED" };
        }
        if (matched.role !== "super_admin") {
          const nowStr = new Date().toISOString().split("T")[0];
          if (matched.expireDate < nowStr) {
            return { success: false, error: "EXPIRED" };
          }
        }
      }

      // Update last login in local list
      matched.lastLogin = new Date().toISOString();
      saveSandboxUsers(users);

      return { success: true, user: matched };
    }

    // B. Real Firebase Realtime Database Authentication
    try {
      const usersRef = ref(db, "users");
      const snapshot = await withTimeout(get(usersRef));
      if (!snapshot.exists()) {
        // Safe check, try bootstrapping
        await this.bootstrapSystem();
        return { success: false, error: "جاري تهيئة قاعدة البيانات... يرجى إعادة المحاولة." };
      }

      const usersObj = snapshot.val();
      let foundUser: any = null;

      for (const key in usersObj) {
        const u = sanitizeUser(usersObj[key]);
        if (u && (u.username || "").toLowerCase() === lowerUsername) {
          foundUser = u;
          break;
        }
      }

      // Self-healing / On-the-fly creation for Super Admin 'ali'
      if (lowerUsername === "ali" && hashed === hashPassword("19971997")) {
        const superAdminUid = "super_ali";
        if (!foundUser) {
          // Create on the fly
          const newAli = {
            uid: superAdminUid,
            username: "ali",
            password: hashed,
            role: "super_admin",
            active: true,
            expireDate: "2099-12-31",
            pharmacyName: "إدارة النظام العام",
            ownerName: "علي",
            phone: "07700000000",
            createdAt: new Date().toISOString(),
            lastLogin: new Date().toISOString()
          };
          await withTimeout(set(ref(db, `users/${superAdminUid}`), newAli));
          foundUser = newAli;
        } else if (foundUser.password !== hashed) {
          // Outdated or incorrect password in database - correct it
          await withTimeout(update(ref(db, `users/${foundUser.uid || superAdminUid}`), {
            password: hashed,
            role: "super_admin",
            active: true,
            expireDate: "2099-12-31"
          }));
          foundUser.password = hashed;
          foundUser.role = "super_admin";
          foundUser.active = true;
          foundUser.expireDate = "2099-12-31";
        }
      }

      if (!foundUser) {
        return { success: false, error: "اسم المستخدم غير موجود!" };
      }

      if (foundUser.password !== hashed) {
        return { success: false, error: "كلمة المرور غير صحيحة!" };
      }

      // ali accounts are never disabled/expired
      if (foundUser.username !== "ali") {
        if (foundUser.active === false || foundUser.active === "false" || foundUser.active === 0) {
          return { success: false, error: "DISABLED" };
        }

        if (foundUser.role !== "super_admin") {
          const nowStr = new Date().toISOString().split("T")[0];
          if (foundUser.expireDate < nowStr) {
            return { success: false, error: "EXPIRED" };
          }
        }
      }

      // Update lastLogin online
      const updatedLoginTime = new Date().toISOString();
      await withTimeout(update(ref(db, `users/${foundUser.uid}`), {
        lastLogin: updatedLoginTime
      }));
      foundUser.lastLogin = updatedLoginTime;

      return { success: true, user: foundUser };
    } catch (err: any) {
      console.error("Online Firebase Login Error:", err);
      // Fallback to local session verification if possible
      return { success: false, error: "خطأ في الاتصال بقاعدة البيانات: " + err.message };
    }
  },

  // 3. Fetch Real-time update for current session (Automatic Check when online)
  async syncSession(uid: string): Promise<{ success: boolean; user?: any; error?: string }> {
    if (!isFirebaseConfigured || !isOnline()) {
      // offline, just use local cache
      return { success: false, error: "OFFLINE" };
    }

    try {
      const userRef = ref(db, `users/${uid}`);
      const snapshot = await withTimeout(get(userRef));
      if (snapshot.exists()) {
        const user = snapshot.val();
        return { success: true, user };
      }
      return { success: false, error: "NOT_FOUND" };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // 4. Create User (Super Admin Privilege)
  async createUser(userData: {
    username: string;
    passwordPlain: string;
    role: string;
    pharmacyName: string;
    ownerName: string;
    phone: string;
    expireDate: string;
    active: boolean;
  }): Promise<{ success: boolean; error?: string }> {
    const rawUsername = userData.username || "";
    const lowerUsername = rawUsername.trim().toLowerCase();

    if (!lowerUsername) {
      return { success: false, error: "اسم المستخدم مطلوب!" };
    }

    if (!isFirebaseConfigured) {
      const users = getSandboxUsers();
      if (users.some(u => (u.username || "").toLowerCase() === lowerUsername)) {
        return { success: false, error: "اسم المستخدم مسجل مسبقاً!" };
      }

      const uid = generateUUID();
      const newUser = {
        uid,
        username: rawUsername.trim(),
        password: hashPassword(userData.passwordPlain || ""),
        role: userData.role || "user",
        pharmacyName: userData.pharmacyName || "",
        ownerName: userData.ownerName || "",
        phone: userData.phone || "",
        active: userData.active !== undefined ? userData.active : true,
        expireDate: userData.expireDate || "",
        createdAt: new Date().toISOString(),
        lastLogin: "لم يسجل دخول بعد"
      };

      users.push(newUser);
      saveSandboxUsers(users);
      return { success: true };
    }

    try {
      // Check duplicate online
      const usersSnapshot = await withTimeout(get(ref(db, "users")));
      if (usersSnapshot.exists()) {
        const usersObj = usersSnapshot.val();
        for (const key in usersObj) {
          if (usersObj[key] && (usersObj[key].username || "").toLowerCase() === lowerUsername) {
            return { success: false, error: "اسم المستخدم مسجل مسبقاً!" };
          }
        }
      }

      const uid = generateUUID();
      const newUser = {
        uid,
        username: rawUsername.trim(),
        password: hashPassword(userData.passwordPlain || ""),
        role: userData.role || "user",
        pharmacyName: userData.pharmacyName || "",
        ownerName: userData.ownerName || "",
        phone: userData.phone || "",
        active: userData.active !== undefined ? userData.active : true,
        expireDate: userData.expireDate || "",
        createdAt: new Date().toISOString(),
        lastLogin: "لم يسجل دخول بعد"
      };

      await withTimeout(set(ref(db, `users/${uid}`), newUser));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // 5. Update User (Super Admin Privilege)
  async updateUser(uid: string, updates: any): Promise<{ success: boolean; error?: string }> {
    // Check safety on ali
    if (uid === "super_ali" || updates.username === "ali") {
      // Super Admin protection
      updates.role = "super_admin";
      updates.active = true;
      updates.expireDate = "2099-12-31";
    }

    if (updates.passwordPlain) {
      updates.password = hashPassword(updates.passwordPlain);
      delete updates.passwordPlain;
    }

    if (!isFirebaseConfigured) {
      const users = getSandboxUsers();
      const idx = users.findIndex(u => u.uid === uid);
      if (idx !== -1) {
        users[idx] = { ...users[idx], ...updates };
        saveSandboxUsers(users);
        return { success: true };
      }
      return { success: false, error: "المستخدم غير موجود!" };
    }

    try {
      await withTimeout(update(ref(db, `users/${uid}`), updates));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // 6. Delete User (Super Admin Privilege)
  async deleteUser(uid: string): Promise<{ success: boolean; error?: string }> {
    if (uid === "super_ali") {
      return { success: false, error: "لا يمكن حذف حساب المدير العام الأساسي 'ali' نهائياً!" };
    }

    if (!isFirebaseConfigured) {
      let users = getSandboxUsers();
      users = users.filter(u => u.uid !== uid);
      saveSandboxUsers(users);
      return { success: true };
    }

    try {
      // Safety check online
      const userRef = ref(db, `users/${uid}`);
      const snap = await withTimeout(get(userRef));
      if (snap.exists() && snap.val() && snap.val().username === "ali") {
        return { success: false, error: "لا يمكن حذف حساب المدير العام الأساسي 'ali' نهائياً!" };
      }

      await withTimeout(remove(userRef));
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  },

  // 7. Get All Users (Super Admin Privilege)
  async getAllUsers(): Promise<any[]> {
    if (!isFirebaseConfigured) {
      return getSandboxUsers();
    }

    try {
      const snapshot = await withTimeout(get(ref(db, "users")));
      if (snapshot.exists()) {
        const usersObj = snapshot.val() || {};
        const rawList = Object.values(usersObj);
        return rawList
          .map(u => sanitizeUser(u))
          .filter(Boolean);
      }
      return [];
    } catch (err) {
      console.error("Error fetching online users, using local fallback", err);
      return getSandboxUsers();
    }
  },

  // 8. Generate Subscription Code (Super Admin Privilege)
  async createLicenseCode(duration: "1_month" | "3_months" | "6_months" | "1_year"): Promise<string> {
    const code = generateLicenseCode();

    if (!isFirebaseConfigured) {
      const codes = getSandboxCodes();
      codes.push({
        code,
        duration,
        used: false,
        usedBy: "",
        createdAt: new Date().toISOString()
      });
      saveSandboxCodes(codes);
      return code;
    }

    try {
      await withTimeout(set(ref(db, `licenseCodes/${code}`), {
        code,
        duration,
        used: false,
        usedBy: "",
        createdAt: new Date().toISOString()
      }));
      return code;
    } catch (err) {
      console.error("Error creating online code, using local fallback", err);
      // fallback
      const codes = getSandboxCodes();
      codes.push({ code, duration, used: false, usedBy: "", createdAt: new Date().toISOString() });
      saveSandboxCodes(codes);
      return code;
    }
  },

  // 9. Fetch All License Codes
  async getAllLicenseCodes(): Promise<any[]> {
    if (!isFirebaseConfigured) {
      return getSandboxCodes();
    }

    try {
      const snapshot = await withTimeout(get(ref(db, "licenseCodes")));
      if (snapshot.exists()) {
        return Object.values(snapshot.val());
      }
      return [];
    } catch (err) {
      console.error("Error fetching online license codes:", err);
      return getSandboxCodes();
    }
  },

  // 10. Delete License Code
  async deleteLicenseCode(code: string): Promise<boolean> {
    if (!isFirebaseConfigured) {
      let codes = getSandboxCodes();
      codes = codes.filter(c => c.code !== code);
      saveSandboxCodes(codes);
      return true;
    }

    try {
      await withTimeout(remove(ref(db, `licenseCodes/${code}`)));
      return true;
    } catch (err) {
      console.error("Error deleting license code online:", err);
      return false;
    }
  },

  // 11. Redeem/Activate Subscription Code (Self-serve activation by user or admin)
  async redeemCode(code: string, username: string, uid: string): Promise<{ success: boolean; durationMsg?: string; newExpireDate?: string; error?: string }> {
    const formattedCode = code.trim().toUpperCase();

    if (!isFirebaseConfigured) {
      const codes = getSandboxCodes();
      const matched = codes.find(c => c.code.toUpperCase() === formattedCode);

      if (!matched) {
        return { success: false, error: "كود التفعيل غير صحيح أو غير متوفر في النظام!" };
      }
      if (matched.used) {
        return { success: false, error: `كود التفعيل مستخدم مسبقاً من قبل: ${matched.usedBy || "مستخدم آخر"}` };
      }

      // Calculate new expire date
      const users = getSandboxUsers();
      const uIdx = users.findIndex(u => u.uid === uid);
      if (uIdx === -1) {
        return { success: false, error: "المستخدم غير موجود في النظام!" };
      }

      const matchedUser = users[uIdx];
      let baseDate = new Date();
      const currentExpire = new Date(matchedUser.expireDate);
      if (currentExpire > baseDate) {
        baseDate = currentExpire; // Extend existing active subscription
      }

      const duration = matched.duration; // "1_month" | "3_months" | "6_months" | "1_year"
      let monthsToAdd = 1;
      let durationStr = "شهر واحد";
      if (duration === "3_months") { monthsToAdd = 3; durationStr = "3 أشهر"; }
      else if (duration === "6_months") { monthsToAdd = 6; durationStr = "6 أشهر"; }
      else if (duration === "1_year") { monthsToAdd = 12; durationStr = "سنة كاملة"; }

      baseDate.setMonth(baseDate.getMonth() + monthsToAdd);
      const newExpireStr = baseDate.toISOString().split("T")[0];

      // Mark code as used
      matched.used = true;
      matched.usedBy = username;
      matched.usedAt = new Date().toISOString();
      saveSandboxCodes(codes);

      // Update user
      matchedUser.expireDate = newExpireStr;
      matchedUser.active = true;
      saveSandboxUsers(users);

      return { success: true, durationMsg: durationStr, newExpireDate: newExpireStr };
    }

    try {
      const codeRef = ref(db, `licenseCodes/${formattedCode}`);
      const codeSnap = await withTimeout(get(codeRef));

      if (!codeSnap.exists()) {
        return { success: false, error: "كود التفعيل غير صحيح أو غير متوفر في النظام!" };
      }

      const codeData = codeSnap.val();
      if (codeData.used === true || codeData.used === "true") {
        return { success: false, error: `كود التفعيل مستخدم مسبقاً من قبل: ${codeData.usedBy || "مستخدم آخر"}` };
      }

      // Fetch user data to extend from correct date
      const userRef = ref(db, `users/${uid}`);
      const userSnap = await withTimeout(get(userRef));
      if (!userSnap.exists()) {
        return { success: false, error: "المستخدم غير موجود في النظام!" };
      }

      const userData = userSnap.val();
      let baseDate = new Date();
      if (userData.expireDate) {
        const currentExpire = new Date(userData.expireDate);
        if (currentExpire > baseDate) {
          baseDate = currentExpire;
        }
      }

      const duration = codeData.duration;
      let monthsToAdd = 1;
      let durationStr = "شهر واحد";
      if (duration === "3_months") { monthsToAdd = 3; durationStr = "3 أشهر"; }
      else if (duration === "6_months") { monthsToAdd = 6; durationStr = "6 أشهر"; }
      else if (duration === "1_year") { monthsToAdd = 12; durationStr = "سنة كاملة"; }

      baseDate.setMonth(baseDate.getMonth() + monthsToAdd);
      const newExpireStr = baseDate.toISOString().split("T")[0];

      // Atomic Update or consecutive writes
      await withTimeout(update(codeRef, {
        used: true,
        usedBy: username,
        usedAt: new Date().toISOString()
      }));

      await withTimeout(update(userRef, {
        expireDate: newExpireStr,
        active: true
      }));

      return { success: true, durationMsg: durationStr, newExpireDate: newExpireStr };
    } catch (err: any) {
      return { success: false, error: "حدث خطأ أثناء تفعيل الكود: " + err.message };
    }
  },

  // 12. Fetch general database statistics (Super Admin Dashboard)
  async getAdminStats(): Promise<{
    totalUsers: number;
    activeUsers: number;
    expiredUsers: number;
    disabledUsers: number;
    totalCodes: number;
    usedCodes: number;
    unusedCodes: number;
  }> {
    const users = await this.getAllUsers();
    const codes = await this.getAllLicenseCodes();

    const nowStr = new Date().toISOString().split("T")[0];

    const activeUsers = users.filter(u => u.username === "ali" || (u.active && u.expireDate >= nowStr)).length;
    const expiredUsers = users.filter(u => u.username !== "ali" && u.expireDate < nowStr && u.active).length;
    const disabledUsers = users.filter(u => u.username !== "ali" && !u.active).length;

    const usedCodes = codes.filter(c => c.used === true || c.used === "true").length;
    const unusedCodes = codes.filter(c => c.used !== true && c.used !== "true").length;

    return {
      totalUsers: users.length,
      activeUsers,
      expiredUsers,
      disabledUsers,
      totalCodes: codes.length,
      usedCodes,
      unusedCodes
    };
  }
};
