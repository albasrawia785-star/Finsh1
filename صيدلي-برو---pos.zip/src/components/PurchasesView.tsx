/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ShoppingBag,
  Plus,
  Trash2,
  CheckCircle,
  AlertCircle,
  Truck,
  DollarSign,
  Search,
  Eye,
  X,
  FileText
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, Supplier, PurchaseInvoice, PurchaseInvoiceItem } from "../types";

interface PurchasesViewProps {
  currency: string;
}

export default function PurchasesView({ currency }: PurchasesViewProps) {
  // DB States
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [purchaseHistory, setPurchaseHistory] = useState<PurchaseInvoice[]>([]);
  const [loading, setLoading] = useState(true);

  // Cart State for new Purchase Invoice
  const [selectedSupplierId, setSelectedSupplierId] = useState("");
  const [purchaseItems, setPurchaseItems] = useState<{ product: Product; buyPrice: number; quantity: number }[]>([]);
  const [invoiceNotes, setInvoiceNotes] = useState("");

  // Search/Pick product state
  const [productSearch, setProductSearch] = useState("");
  const [filteredProductDropdown, setFilteredProductDropdown] = useState<Product[]>([]);
  const [selectedProdForInbound, setSelectedProdForInbound] = useState<Product | null>(null);
  const [inboundBuyPrice, setInboundBuyPrice] = useState(0);
  const [inboundQty, setInboundQty] = useState(10);

  // Detail / Delete State
  const [viewInvoice, setViewInvoice] = useState<PurchaseInvoice | null>(null);

  // Toast / Messages
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const sups = await IndexedDBService.getAll<Supplier>("suppliers");
      const prods = await IndexedDBService.getAll<Product>("products");
      const purHist = await IndexedDBService.getAll<PurchaseInvoice>("purchases");
      setSuppliers(sups);
      setProducts(prods);
      setPurchaseHistory(purHist);
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء تحميل بيانات المشتريات", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Filter products for pick list dropdown
  useEffect(() => {
    if (productSearch.trim().length > 0) {
      const q = productSearch.toLowerCase();
      const matches = products.filter(
        (p) => 
          (p.commercialName || "").toLowerCase().includes(q) || 
          (p.scientificName || "").toLowerCase().includes(q)
      );
      setFilteredProductDropdown(matches.slice(0, 10)); // limit 10
    } else {
      setFilteredProductDropdown([]);
    }
  }, [productSearch, products]);

  const selectProductForAdd = (prod: Product) => {
    setSelectedProdForInbound(prod);
    setInboundBuyPrice(prod.buyPrice);
    setProductSearch(prod.commercialName);
    setFilteredProductDropdown([]);
  };

  const addProductToDocket = () => {
    if (!selectedProdForInbound) return;

    const existingIdx = purchaseItems.findIndex((item) => item.product.id === selectedProdForInbound.id);
    if (existingIdx > -1) {
      const updated = [...purchaseItems];
      updated[existingIdx].quantity += inboundQty;
      updated[existingIdx].buyPrice = inboundBuyPrice;
      setPurchaseItems(updated);
    } else {
      setPurchaseItems([...purchaseItems, { product: selectedProdForInbound, buyPrice: inboundBuyPrice, quantity: inboundQty }]);
    }

    // Reset pickup inputs
    setSelectedProdForInbound(null);
    setProductSearch("");
    setInboundBuyPrice(0);
    setInboundQty(10);
  };

  const removeProductFromDocket = (idx: number) => {
    setPurchaseItems(purchaseItems.filter((_, i) => i !== idx));
  };

  const subtotal = purchaseItems.reduce((acc, item) => acc + item.buyPrice * item.quantity, 0);

  const handleSavePurchaseInvoice = async () => {
    if (!selectedSupplierId) {
      showToast("الرجاء اختيار المورد أولاً لتسجيل المشتريات", "error");
      return;
    }

    if (purchaseItems.length === 0) {
      showToast("قائمة المشتريات فارغة! الرجاء إضافة أدوية مقتناة.", "error");
      return;
    }

    try {
      // 1. Process products stock & buyPrice updates
      for (const item of purchaseItems) {
        const prod = (await IndexedDBService.getById<Product>("products", item.product.id))!;
        prod.quantity += item.quantity;
        prod.buyPrice = item.buyPrice; // Update Buy Price as requested
        await IndexedDBService.update("products", prod);
      }

      // 2. Add total to supplier balance as credit
      const supplier = (await IndexedDBService.getById<Supplier>("suppliers", selectedSupplierId))!;
      supplier.balance += subtotal;
      await IndexedDBService.update("suppliers", supplier);

      // 3. Create purchase invoice
      const invoiceNumber = `PUR-${new Date().toISOString().replace(/[-:T]/g, "").slice(0, 8)}-${Math.floor(100 + Math.random() * 900)}`;
      const items: PurchaseInvoiceItem[] = purchaseItems.map((item) => ({
        productId: item.product.id,
        commercialName: item.product.commercialName,
        buyPrice: item.buyPrice,
        quantity: item.quantity,
        total: item.buyPrice * item.quantity,
      }));

      const newInvoice: PurchaseInvoice = {
        id: `pur-inv-${Date.now()}`,
        invoiceNumber,
        date: new Date().toISOString(),
        supplierId: selectedSupplierId,
        items,
        subtotal,
        total: subtotal,
        notes: invoiceNotes,
      };

      await IndexedDBService.add("purchases", newInvoice);

      showToast(`تم حفظ فاتورة الشراء وتحديث المخازن: ${invoiceNumber}`, "success");

      // Reset
      setPurchaseItems([]);
      setSelectedSupplierId("");
      setInvoiceNotes("");
      loadData();
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء حفظ فاتورة المشتريات", "error");
    }
  };

  const getSupplierName = (id: string) => {
    const s = suppliers.find((x) => x.id === id);
    return s ? s.name : "مورد مجهول";
  };

  const sortedHistory = [...purchaseHistory].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-8 flex flex-col lg:flex-row gap-6">
      {/* LEFT COLUMN: Record Inbound Purchase */}
      <div className="flex-1 space-y-6">
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <ShoppingBag className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-sm">تسجيل فاتورة شراء (مذخر/مورد)</h2>
          </div>

          <div className="space-y-4 text-xs font-sans">
            {/* Pick Supplier */}
            <div>
              <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1.5">اختر المورد:</label>
              <select
                value={selectedSupplierId}
                onChange={(e) => setSelectedSupplierId(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-xs text-slate-700 dark:text-slate-200 focus:outline-none focus:border-emerald-500"
              >
                <option value="">— اختر المورد أو مذخر الأدوية —</option>
                {suppliers.map((sup) => (
                  <option key={sup.id} value={sup.id}>
                    {sup.name} (الهاتف: {sup.phone || "لا يوجد"})
                  </option>
                ))}
              </select>
            </div>

            {/* Pick Product Inbound Form */}
            <div className="p-4 bg-slate-50 dark:bg-slate-850 rounded-xl border border-slate-200/60 dark:border-slate-800 space-y-3">
              <span className="font-bold text-slate-700 dark:text-slate-350 block mb-1">إضافة دواء للجدول:</span>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Search product */}
                <div className="relative">
                  <label className="block text-slate-500 font-medium mb-1">ابحث عن الدواء:</label>
                  <input
                    type="text"
                    placeholder="اكتب الاسم التجاري أو العلمي..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs text-slate-800 dark:text-slate-100 focus:outline-none"
                  />
                  
                  {/* Dropdown matched */}
                  {filteredProductDropdown.length > 0 && (
                    <div className="absolute right-0 left-0 top-[48px] bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg z-20 max-h-48 overflow-y-auto">
                      {filteredProductDropdown.map((prod) => (
                        <button
                          key={prod.id}
                          type="button"
                          onClick={() => selectProductForAdd(prod)}
                          className="w-full text-right px-3 py-2 hover:bg-slate-50 dark:hover:bg-slate-700 text-[11px] block text-slate-700 dark:text-slate-300 font-sans"
                        >
                          <span className="font-bold block">{prod.commercialName}</span>
                          <span className="text-[9px] text-slate-400">{prod.scientificName}</span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* Buy price */}
                <div>
                  <label className="block text-slate-500 font-medium mb-1">سعر الشراء الجديد (للعينة):</label>
                  <input
                    type="number"
                    value={inboundBuyPrice === 0 ? "" : inboundBuyPrice}
                    onChange={(e) => setInboundBuyPrice(Math.max(0, parseInt(e.target.value) || 0))}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-mono"
                  />
                </div>

                {/* Inbound Qty */}
                <div>
                  <label className="block text-slate-500 font-medium mb-1">الكمية المقتناة (علبة):</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={inboundQty}
                      onChange={(e) => setInboundQty(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2 text-xs font-mono"
                    />
                    <button
                      type="button"
                      onClick={addProductToDocket}
                      disabled={!selectedProdForInbound}
                      className="px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
                    >
                      إضافة
                    </button>
                  </div>
                </div>
              </div>

              {selectedProdForInbound && (
                <div className="text-[10px] bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 p-2 rounded-lg flex items-center gap-1.5 font-sans">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>تم تحديد: <b>{selectedProdForInbound.commercialName}</b> (سعر الشراء الحالي بالدليل: {selectedProdForInbound.buyPrice.toLocaleString("ar-IQ")} د.ع)</span>
                </div>
              )}
            </div>

            {/* Added Items Docket list */}
            {purchaseItems.length > 0 ? (
              <div className="space-y-2 border-t border-slate-100 dark:border-slate-800 pt-3">
                <span className="font-bold text-slate-700 dark:text-slate-350 block mb-2 text-xs">مسودة الفاتورة الحالية:</span>
                <div className="divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl overflow-hidden bg-white dark:bg-slate-900">
                  {purchaseItems.map((item, idx) => (
                    <div key={idx} className="p-3 flex items-center justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <span className="font-bold text-slate-800 dark:text-slate-200 block truncate">{item.product.commercialName}</span>
                        <span className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {item.quantity} علبة × {item.buyPrice.toLocaleString("ar-IQ")} د.ع
                        </span>
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="font-mono font-bold text-slate-700 dark:text-slate-300">
                          {(item.buyPrice * item.quantity).toLocaleString("ar-IQ")} د.ع
                        </span>
                        <button
                          type="button"
                          onClick={() => removeProductFromDocket(idx)}
                          className="p-1 rounded-md text-rose-500 hover:bg-rose-50 cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex justify-between items-center bg-slate-50 dark:bg-slate-850 p-4 rounded-xl border font-bold">
                  <span>المجموع الإجمالي للفاتورة:</span>
                  <span className="text-sm text-emerald-600 font-mono">{subtotal.toLocaleString("ar-IQ")} {currency}</span>
                </div>

                {/* Notes and save */}
                <div className="space-y-3 pt-2">
                  <input
                    type="text"
                    placeholder="ملاحظات حول فاتورة التوريد (رقم الشحنة، شروط الدفع، إلخ)..."
                    value={invoiceNotes}
                    onChange={(e) => setInvoiceNotes(e.target.value)}
                    className="w-full py-2 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100"
                  />
                  <button
                    type="button"
                    onClick={handleSavePurchaseInvoice}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer"
                  >
                    حفظ فاتورة الشراء وتأدية السلع للرفوف
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-slate-400 bg-slate-50/50 dark:bg-slate-850 rounded-xl border border-dashed">
                لم يتم إضافة سلع إلى مسودة المشتريات بعد.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: Procurement Invoices Logs (Purchase History) */}
      <div className="w-full lg:w-[350px] bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-5 flex flex-col h-full max-h-[70vh] lg:max-h-none overflow-y-auto">
        <div className="flex items-center gap-2 border-b border-slate-150 dark:border-slate-800 pb-3 mb-4 shrink-0">
          <FileText className="w-5 h-5 text-emerald-500" />
          <h2 className="font-bold text-slate-800 dark:text-slate-100 text-sm">سجل فواتير التوريد</h2>
        </div>

        {sortedHistory.length === 0 ? (
          <div className="py-12 text-center text-slate-400">
            لا توجد فواتير شراء سابقة مسجلة.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 overflow-y-auto pr-1">
            {sortedHistory.map((inv) => (
              <div key={inv.id} className="py-3 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-slate-850 dark:text-slate-200 font-mono">{inv.invoiceNumber}</span>
                  <span className="text-[10px] text-slate-400">{new Date(inv.date).toLocaleDateString("ar-IQ")}</span>
                </div>
                <p className="text-slate-500 truncate mb-1">المورد: {getSupplierName(inv.supplierId)}</p>
                <div className="flex items-center justify-between font-semibold">
                  <span className="text-slate-400">{inv.items.length} أصناف مقتناة</span>
                  <span className="text-slate-800 dark:text-slate-200 font-mono">{inv.total.toLocaleString("ar-IQ")} د.ع</span>
                </div>
                <button
                  onClick={() => setViewInvoice(inv)}
                  className="mt-1.5 text-[10px] text-emerald-600 dark:text-emerald-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
                >
                  <Eye className="w-3 h-3" />
                  <span>تفاصيل الفاتورة</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* --- PURCHASE DETAIL VIEW MODAL --- */}
      <AnimatePresence>
        {viewInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-md shadow-2xl"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">تفاصيل فاتورة المشتريات</h3>
                <button onClick={() => setViewInvoice(null)} className="p-1 rounded-lg hover:bg-slate-100 text-slate-500">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="bg-slate-50 dark:bg-slate-800/50 p-3.5 rounded-xl border mb-4 text-xs space-y-1.5 font-sans">
                <p><span className="text-slate-400">رقم الفاتورة:</span> <b className="font-mono text-slate-800 dark:text-slate-200">{viewInvoice.invoiceNumber}</b></p>
                <p><span className="text-slate-400">التاريخ:</span> <span className="font-semibold text-slate-700 dark:text-slate-350">{new Date(viewInvoice.date).toLocaleString("ar-IQ")}</span></p>
                <p><span className="text-slate-400">المورد:</span> <span className="font-bold text-emerald-600">{getSupplierName(viewInvoice.supplierId)}</span></p>
              </div>

              <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1 text-xs">
                <span className="font-bold text-slate-600 dark:text-slate-400 block mb-1">السلع المستوردة:</span>
                {viewInvoice.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800">
                    <span className="font-bold text-slate-800 dark:text-slate-200">{item.commercialName}</span>
                    <span className="font-mono text-slate-500">
                      {item.quantity} علبة × {item.buyPrice.toLocaleString("ar-IQ")} د.ع
                    </span>
                  </div>
                ))}
              </div>

              <div className="border-t border-slate-100 dark:border-slate-800 pt-3 mt-4 text-sm font-bold flex justify-between">
                <span>المجموع الكلي للفاتورة:</span>
                <span className="text-emerald-600 font-mono">{viewInvoice.total.toLocaleString("ar-IQ")} د.ع</span>
              </div>

              <button
                onClick={() => setViewInvoice(null)}
                className="w-full mt-6 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
              >
                إغلاق
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-350"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
