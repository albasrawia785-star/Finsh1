/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Settings,
  Store,
  MapPin,
  Phone,
  Coins,
  Moon,
  Sun,
  CheckCircle,
  HelpCircle,
  Heart,
  Activity,
  ShieldAlert
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { PharmacySettings } from "../types";

interface SettingsViewProps {
  settings: PharmacySettings;
  onUpdateSettings: (newSettings: PharmacySettings) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export default function SettingsView({
  settings,
  onUpdateSettings,
  darkMode,
  onToggleDarkMode
}: SettingsViewProps) {
  // Local state
  const [pharmacyName, setPharmacyName] = useState(settings.pharmacyName);
  const [address, setAddress] = useState(settings.address);
  const [phone, setPhone] = useState(settings.phone);
  const [currency, setCurrency] = useState(settings.currency);

  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  // Database Reset States
  const [resetModalType, setResetModalType] = useState<"zero-stock" | "delete-medicines" | "factory-reset" | null>(null);
  const [confirmText, setConfirmText] = useState("");

  const showToast = (text: string) => {
    setToast(text);
    setTimeout(() => setToast(null), 3000);
  };

  const handleOpenResetModal = (type: "zero-stock" | "delete-medicines" | "factory-reset") => {
    setResetModalType(type);
    setConfirmText("");
  };

  const handleExecuteReset = async () => {
    if (confirmText !== "حذف" || !resetModalType) return;

    try {
      if (resetModalType === "zero-stock") {
        await IndexedDBService.resetAllStockToZero();
        showToast("تم تصفير كميات جميع الأدوية في المخزن بنجاح");
      } else if (resetModalType === "delete-medicines") {
        await IndexedDBService.deleteAllMedicines();
        showToast("تم حذف جميع الأدوية والمخازن بالكامل من الصيدلية");
      } else if (resetModalType === "factory-reset") {
        await IndexedDBService.factoryResetSystem();
        showToast("تمت إعادة تعيين النظام وحذف كافة البيانات بنجاح");
      }

      setResetModalType(null);
      setConfirmText("");

      // Reload window after short delay so the toast is read
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ غير متوقع أثناء تنفيذ عملية إعادة التعيين");
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const updated: PharmacySettings = {
        ...settings,
        pharmacyName,
        address,
        phone,
        currency
      };

      // Store in DB
      await IndexedDBService.saveSettings(updated);
      onUpdateSettings(updated);
      showToast("تم حفظ إعدادات الصيدلية وبطاقات العمل بنجاح");
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ غير متوقع أثناء الحفظ");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 text-xs font-sans">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">الضبط وإعدادات النظام</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">تخصيص هوية صيدليتك، تعديل العملة، تبديل وضع الرؤية الليلية وتعيين الهيدر للفواتير.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Core settings form */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <Store className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">معلومات الهوية والاسم التجاري</h2>
          </div>

          <form onSubmit={handleSaveSettings} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1.5">اسم الصيدلية الرسمي:</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={pharmacyName}
                    onChange={(e) => setPharmacyName(e.target.value)}
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-850 dark:text-slate-100 focus:outline-none focus:border-emerald-500 font-bold"
                  />
                  <Store className="absolute right-3 top-3 w-4 h-4 text-slate-450" />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1.5">رقم تواصل وتلفون الصيدلية:</label>
                <div className="relative">
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-850 dark:text-slate-100 focus:outline-none font-mono text-left"
                  />
                  <Phone className="absolute right-3 top-3 w-4 h-4 text-slate-450" />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1.5">العنوان الجغرافي للصيدلية:</label>
                <div className="relative">
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-850 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                  />
                  <MapPin className="absolute right-3 top-3 w-4 h-4 text-slate-450" />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 font-bold mb-1.5">رمز العملة الافتراضي بالنظام:</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-850 dark:text-slate-100 focus:outline-none"
                  />
                  <Coins className="absolute right-3 top-3 w-4 h-4 text-slate-450" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold cursor-pointer text-xs transition-colors shadow-md shadow-emerald-600/10"
            >
              {saving ? "جاري الحفظ والتدوين..." : "حفظ تفضيلات الهوية"}
            </button>
          </form>
        </div>

        {/* UI / Display Preferences */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <Sun className="w-5 h-5 text-amber-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">واجهة الرؤية والسمات</h2>
          </div>

          <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
            قم بالتبديل بين السمة الفاتحة العادية للعمل الصباحي، والسمة الداكنة المريحة للعين في نوبات الخفارة والعمل المسائي الطويل في الصيدلية.
          </p>

          <button
            onClick={onToggleDarkMode}
            className="w-full py-3 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-850 flex items-center justify-center gap-2 text-xs font-bold cursor-pointer transition-colors"
          >
            {darkMode ? (
              <>
                <Sun className="w-4 h-4 text-amber-500" />
                <span>تبديل للسمة المضيئة (صباحي)</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-500" />
                <span>تبديل للسمة الليلية (مسائي)</span>
              </>
            )}
          </button>

          <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 text-indigo-700 dark:text-indigo-400 rounded-xl border border-indigo-100 dark:border-indigo-900/40 text-[10px] flex gap-2 leading-relaxed">
            <Activity className="w-4 h-4 shrink-0 text-indigo-600 mt-0.5" />
            <span>يدعم صيدلي برو الضبط المستمر، مما يعني أنه سيتم تذكر تفضيل السمة تلقائياً على هذا الجهاز عند العودة مرة أخرى.</span>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-red-200 dark:border-red-950/40 space-y-4">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
          <ShieldAlert className="w-5 h-5 text-red-500 animate-pulse" />
          <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs text-red-600 dark:text-red-400">إدارة قاعدة البيانات ومنطقة الخطر</h2>
        </div>

        <div className="text-xs text-slate-500 dark:text-slate-400 space-y-2 text-right">
          <p className="font-semibold text-slate-700 dark:text-slate-300">هنا تتوفر خيارات تصفير وحذف مخزون وبيانات الصيدلية بالكامل. يرجى الحذر الشديد قبل التنفيذ:</p>
          <ul className="list-disc pr-4 space-y-1 text-[11px]">
            <li>تصفير الكميات يبقي على أسماء الأدوية والمعلومات ولكنه يعيد كمية المخزون لجميع الأدوية إلى (0 علبة).</li>
            <li>حذف الأدوية والمخازن يحذف جميع سجلات الأدوية نهائياً من الرفوف والمخازن.</li>
            <li>إعادة تعيين المصنع تقوم بمسح شامل لكافة فئات الأدوية، الفواتير الصادرة والواردة، والعملاء والموردين.</li>
          </ul>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <button
            type="button"
            onClick={() => handleOpenResetModal("zero-stock")}
            className="py-2.5 px-4 rounded-xl border border-amber-200 dark:border-amber-950/40 hover:bg-amber-50 dark:hover:bg-amber-955/10 text-amber-600 dark:text-amber-400 font-bold transition-colors cursor-pointer text-center text-xs"
          >
            🔄 تصفير كميات المخزون بالكامل
          </button>
          <button
            type="button"
            onClick={() => handleOpenResetModal("delete-medicines")}
            className="py-2.5 px-4 rounded-xl border border-red-200 dark:border-red-950/40 hover:bg-red-50 dark:hover:bg-red-955/10 text-red-600 dark:text-red-400 font-bold transition-colors cursor-pointer text-center text-xs"
          >
            🗑️ حذف كافة الأدوية والمخازن
          </button>
          <button
            type="button"
            onClick={() => handleOpenResetModal("factory-reset")}
            className="py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold transition-colors cursor-pointer text-center text-xs shadow-md shadow-red-600/10"
          >
            ⚠️ إعادة تعيين المصنع (تصفير وحذف الكل)
          </button>
        </div>
      </div>

      {/* Confirmation Reset Modal */}
      <AnimatePresence>
        {resetModalType && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-red-100 dark:border-red-950 p-6 w-full max-w-md shadow-2xl text-right font-sans space-y-4"
            >
              <div className="w-12 h-12 rounded-full bg-red-50 dark:bg-red-950/40 flex items-center justify-center mx-auto text-red-600">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>

              <div className="text-center">
                <h3 className="font-bold text-slate-850 dark:text-slate-100 text-sm mb-2">
                  {resetModalType === "zero-stock" && "تأكيد تصفير كميات المخزون بالكامل"}
                  {resetModalType === "delete-medicines" && "تأكيد حذف كافة الأدوية والمخازن"}
                  {resetModalType === "factory-reset" && "تأكيد إعادة تعيين المصنع وحذف جميع البيانات"}
                </h3>
                <p className="text-slate-500 dark:text-slate-400 text-[11px] leading-relaxed text-center">
                  {resetModalType === "zero-stock" && "سيؤدي هذا الإجراء إلى تصفير كميات كل الأدوية والمستلزمات في الصيدلية إلى 0 علبة. هذا الإجراء نهائي ولا يمكن التراجع عنه."}
                  {resetModalType === "delete-medicines" && "سيؤدي هذا إلى حذف كل سجلات الأدوية والمخازن تماماً من النظام. ستحتاج لإدخال الأدوية من جديد."}
                  {resetModalType === "factory-reset" && "تنبيه نهائي! سيقوم هذا بمسح شامل وحذف كافة الأدوية، الفئات، الفواتير، المبيعات والمشتريات، الموردين والعملاء. سيعود النظام فارغاً تماماً كما لو تم تثبيته لأول مرة."}
                </p>
              </div>

              <div className="bg-red-50 dark:bg-red-950/20 p-3 rounded-xl border border-red-100 dark:border-red-900/30 text-center">
                <p className="text-[11px] font-bold text-red-700 dark:text-red-400">
                  يرجى كتابة كلمة <span className="underline font-black text-rose-600 bg-white dark:bg-slate-950 px-1.5 py-0.5 rounded mx-1 select-none">حذف</span> في المربع أدناه لتأكيد رغبتك في التنفيذ:
                </p>
                <input
                  type="text"
                  placeholder="اكتب كلمة 'حذف' هنا..."
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value)}
                  className="w-full mt-2 text-center py-2 px-3 rounded-xl border border-red-200 dark:border-red-900 bg-white dark:bg-slate-950 text-red-650 font-bold focus:outline-none"
                />
              </div>

              <div className="flex items-center gap-3 justify-center pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setResetModalType(null);
                    setConfirmText("");
                  }}
                  className="flex-1 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 font-bold hover:bg-slate-50 text-xs cursor-pointer"
                >
                  إلغاء الأمر
                </button>
                <button
                  type="button"
                  disabled={confirmText !== "حذف"}
                  onClick={handleExecuteReset}
                  className="flex-1 py-2 rounded-xl bg-red-600 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-red-500 text-white font-bold text-xs cursor-pointer"
                >
                  نعم، نفذ الأمر الآن
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast Alert */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-6 right-6 z-50 px-5 py-3.5 bg-emerald-50 border border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350 rounded-2xl shadow-xl flex items-center gap-2 text-xs font-bold font-sans"
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span>{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
