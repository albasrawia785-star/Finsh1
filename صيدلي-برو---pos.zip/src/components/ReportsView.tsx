/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import {
  BarChart3,
  TrendingUp,
  DollarSign,
  Award,
  PackageOpen,
  FileSpreadsheet,
  Download,
  Calendar,
  AlertTriangle,
  FileText
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, SaleInvoice, Category } from "../types";

interface ReportsViewProps {
  currency: string;
}

type PeriodType = "daily" | "weekly" | "monthly" | "annual";

export default function ReportsView({ currency }: ReportsViewProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter Period
  const [period, setPeriod] = useState<PeriodType>("monthly");

  const loadData = async () => {
    setLoading(true);
    try {
      const prods = await IndexedDBService.getAll<Product>("products");
      const sls = await IndexedDBService.getAll<SaleInvoice>("sales");
      const cats = await IndexedDBService.getAll<Category>("categories");
      setProducts(prods);
      setSales(sls);
      setCategories(cats);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Helpers for filtering sales based on period
  const getFilteredSales = () => {
    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());

    return sales.filter((sale) => {
      const saleDate = new Date(sale.date);
      
      if (period === "daily") {
        return saleDate >= startOfToday;
      }
      
      if (period === "weekly") {
        const oneWeekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        return saleDate >= oneWeekAgo;
      }
      
      if (period === "monthly") {
        const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        return saleDate >= startOfMonth;
      }
      
      if (period === "annual") {
        const startOfYear = new Date(today.getFullYear(), 0, 1);
        return saleDate >= startOfYear;
      }

      return true;
    });
  };

  const filteredSales = getFilteredSales();

  // 1. Core Financial Calculations for the active period
  let totalRevenue = 0;
  let totalCost = 0;

  // Build buying prices map for fast lookup
  const buyPricesMap = new Map<string, number>();
  products.forEach((p) => buyPricesMap.set(p.id, p.buyPrice));

  filteredSales.forEach((sale) => {
    totalRevenue += sale.total;
    sale.items.forEach((item) => {
      const rawBuyPrice = buyPricesMap.get(item.productId) || 0;
      totalCost += rawBuyPrice * item.quantity;
    });
  });

  const netProfit = totalRevenue - totalCost;

  // 2. Best Selling Products (الأكثر مبيعاً)
  const productSalesMap = new Map<string, { name: string; sci: string; qty: number; revenue: number }>();
  filteredSales.forEach((sale) => {
    sale.items.forEach((item) => {
      const current = productSalesMap.get(item.productId) || { name: item.commercialName, sci: item.scientificName, qty: 0, revenue: 0 };
      current.qty += item.quantity;
      current.revenue += item.total;
      productSalesMap.set(item.productId, current);
    });
  });

  const bestSellers = Array.from(productSalesMap.values())
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5); // top 5

  // 3. Inventory Health calculations
  const outOfStockCount = products.filter((p) => p.quantity === 0).length;
  const lowStockCount = products.filter((p) => p.quantity > 0 && p.quantity <= p.minStock).length;
  const healthStockCount = products.filter((p) => p.quantity > p.minStock).length;

  // 4. Export to Excel (CSV with Arabic UTF-8 BOM)
  const handleExportExcel = () => {
    const todayStr = new Date().toISOString().split("T")[0];
    let csvContent = "";
    
    // Add UTF-8 BOM so Excel opens Arabic correctly
    csvContent += "\uFEFF";

    // Header metadata
    csvContent += `تقرير مبيعات وأرباح صيدلي برو,,تاريخ التقرير: ${todayStr}\n`;
    csvContent += `الفترة المحددة: ${period.toUpperCase()},,\n\n`;

    // Section 1: KPI
    csvContent += `المؤشر المالي,المبلغ بالدينار العراقي\n`;
    csvContent += `إجمالي الإيرادات (المبيعات),${totalRevenue}\n`;
    csvContent += `إجمالي تكلفة المشتريات,${totalCost}\n`;
    csvContent += `صافي الأرباح,${netProfit}\n\n`;

    // Section 2: Best sellers
    csvContent += `الأدوية الأكثر مبيعاً,الكمية المبيعة (علبة),إجمالي المبيعات (دينار)\n`;
    bestSellers.forEach((item) => {
      csvContent += `"${item.name} (${item.sci})",${item.qty},${item.revenue}\n`;
    });

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Pharmacy_Report_${period}_${todayStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 5. Export to PDF (triggers printable layout)
  const handleExportPDF = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-500">جاري احتساب التقارير المالية والأرباح...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6 print:p-0">
      {/* Header (hidden on print) */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">التقارير المالية والأرباح</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">تدقيق شامل للمبيعات، الهوامش الربحية، ومعدل دوران أصناف المخزن.</p>
        </div>

        {/* Export buttons */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleExportExcel}
            className="flex items-center justify-center gap-1.5 px-3 py-2 border border-emerald-200 hover:bg-emerald-50 text-emerald-700 dark:border-emerald-900 dark:text-emerald-450 dark:hover:bg-emerald-950/20 text-xs font-bold rounded-xl cursor-pointer transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>تصدير Excel (CSV)</span>
          </button>
          <button
            onClick={handleExportPDF}
            className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-xl cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>طباعة وحفظ PDF</span>
          </button>
        </div>
      </div>

      {/* Period Select tabs (hidden on print) */}
      <div className="flex items-center gap-1.5 bg-white dark:bg-slate-900 p-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-x-auto scrollbar-none print:hidden">
        <span className="text-xs font-bold text-slate-500 dark:text-slate-400 shrink-0 ml-2">تحديد النطاق الزمني:</span>
        {(["daily", "weekly", "monthly", "annual"] as PeriodType[]).map((p) => {
          const labels = { daily: "مبيعات اليوم", weekly: "آخر 7 أيام", monthly: "الشهر الجاري", annual: "العام الحالي" };
          return (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                period === p
                  ? "bg-emerald-600 text-white"
                  : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
              }`}
            >
              {labels[p]}
            </button>
          );
        })}
      </div>

      {/* Clinical report banner specifically shown only on print */}
      <div className="hidden print:block text-center border-b pb-6 mb-8 text-slate-800">
        <h1 className="text-3xl font-bold">صيدلي برو - تقرير المبيعات المالي</h1>
        <p className="text-sm text-slate-500 mt-1">توليد آلي بالكامل • أوفلاين 100%</p>
        <div className="grid grid-cols-2 text-xs text-right mt-6 max-w-md mx-auto bg-slate-50 p-4 rounded-xl border leading-relaxed">
          <p><b>نطاق التقرير:</b> {period === "daily" ? "اليوم" : period === "weekly" ? "الأسبوع" : period === "monthly" ? "الشهر" : "السنة"}</p>
          <p><b>التاريخ:</b> {new Date().toLocaleDateString("ar-IQ")}</p>
        </div>
      </div>

      {/* KPI stats section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans">
        {/* Total revenue */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-medium">إجمالي المبيعات (الإيرادات)</span>
            <p className="text-xl font-bold font-mono text-slate-800 dark:text-slate-100">{totalRevenue.toLocaleString("ar-IQ")} {currency}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/35 text-emerald-600">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        {/* Total raw cost */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs text-slate-400 font-medium">تكلفة الأدوية الكلية (المشتريات)</span>
            <p className="text-xl font-bold font-mono text-slate-850 dark:text-slate-100">{totalCost.toLocaleString("ar-IQ")} {currency}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/35 text-indigo-600">
            <BarChart3 className="w-6 h-6" />
          </div>
        </div>

        {/* Net Profit */}
        <div className="p-5 rounded-2xl border border-emerald-250 dark:border-emerald-900 bg-emerald-50/20 dark:bg-emerald-950/10 flex items-center justify-between shadow-xs shadow-emerald-500/5">
          <div className="space-y-1">
            <span className="text-xs text-emerald-700 dark:text-emerald-450 font-bold">صافي أرباح الصيدلية الكلية</span>
            <p className="text-xl font-black font-mono text-emerald-650 dark:text-emerald-400">{netProfit.toLocaleString("ar-IQ")} {currency}</p>
          </div>
          <div className="p-3.5 rounded-xl bg-emerald-500 text-white shadow-md shadow-emerald-500/20">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Best Sellers and Inventory Health Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Best Sellers */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <Award className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">الأدوية الأكثر مبيعاً ورواجاً (Top 5)</h2>
          </div>

          {bestSellers.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              لا توجد مبيعات مسجلة في هذا النطاق الزمني حالياً.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {bestSellers.map((item, idx) => (
                <div key={idx} className="py-3 flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-450 font-bold font-mono text-[10px] flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <div>
                      <p className="font-bold text-slate-800 dark:text-slate-200 leading-tight">{item.name}</p>
                      <span className="text-[10px] text-slate-450 italic">{item.sci}</span>
                    </div>
                  </div>
                  <div className="text-left leading-relaxed">
                    <p className="font-bold font-mono">{item.qty} علبة</p>
                    <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">{item.revenue.toLocaleString("ar-IQ")} د.ع</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Inventory Status Summary */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
            <PackageOpen className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">تقرير توازن وحالة سلامة المخزون</h2>
          </div>

          <div className="space-y-4 text-xs font-sans">
            {/* Visual breakdown bar */}
            <div className="space-y-1.5">
              <span className="text-slate-500 font-semibold text-[11px] block">توزيع كفاية الرفوف:</span>
              <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-slate-800 flex overflow-hidden">
                <div
                  style={{ width: `${(healthStockCount / (products.length || 1)) * 100}%` }}
                  className="bg-emerald-500 h-full"
                  title="متوفر بكمية جيدة"
                />
                <div
                  style={{ width: `${(lowStockCount / (products.length || 1)) * 100}%` }}
                  className="bg-amber-400 h-full"
                  title="كمية منخفضة"
                />
                <div
                  style={{ width: `${(outOfStockCount / (products.length || 1)) * 100}%` }}
                  className="bg-rose-500 h-full"
                  title="نفذ بالكامل"
                />
              </div>
            </div>

            {/* Counts details */}
            <div className="space-y-3 pt-2">
              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                  <span className="text-slate-600 dark:text-slate-400">أدوية متوفرة بكمية وافرة:</span>
                </div>
                <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{healthStockCount} صنف</span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-450" />
                  <span className="text-slate-600 dark:text-slate-400">أدوية تحت مستوى الطلب (قليلة):</span>
                </div>
                <span className="font-bold font-mono text-slate-800 dark:text-slate-200">{lowStockCount} صنف</span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <span className="text-slate-600 dark:text-slate-400">أدوية منتهية أو نافدة كلياً:</span>
                </div>
                <span className="font-bold font-mono text-slate-850 dark:text-slate-200">{outOfStockCount} صنف</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
