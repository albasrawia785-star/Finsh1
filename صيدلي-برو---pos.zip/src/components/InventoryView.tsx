/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import {
  Package,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  PackageX,
  CalendarDays,
  FileSpreadsheet,
  Search,
  MapPin,
  RefreshCw,
  Info
} from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { Product, SaleInvoice, PurchaseInvoice } from "../types";

interface InventoryViewProps {
  currency: string;
}

type TabType = "all" | "out_of_stock" | "low_stock" | "near_expired" | "expired";

export default function InventoryView({ currency }: InventoryViewProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<SaleInvoice[]>([]);
  const [purchases, setPurchases] = useState<PurchaseInvoice[]>([]);
  const [loading, setLoading] = useState(true);

  // Filter Tab State
  const [activeTab, setActiveTab] = useState<TabType>("all");
  const [searchQuery, setSearchQuery] = useState("");

  const loadData = async () => {
    setLoading(true);
    try {
      const prods = await IndexedDBService.getAll<Product>("products");
      const sls = await IndexedDBService.getAll<SaleInvoice>("sales");
      const purc = await IndexedDBService.getAll<PurchaseInvoice>("purchases");
      setProducts(prods);
      setSales(sls);
      setPurchases(purc);
    } catch (err) {
      console.error("Error loading inventory stats:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Today string
  const todayStr = new Date().toISOString().split("T")[0];
  const threeMonthsLater = new Date();
  threeMonthsLater.setMonth(threeMonthsLater.getMonth() + 3);
  const threeMonthsLaterStr = threeMonthsLater.toISOString().split("T")[0];

  // Debounced search query
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 300);
    return () => clearTimeout(handler);
  }, [searchQuery]);

  // Pagination / Lazy rendering state
  const [visibleCount, setVisibleCount] = useState(25);

  // 1. Calculations - Memoized for absolute performance
  const totalStockUnits = React.useMemo(() => products.reduce((acc, p) => acc + p.quantity, 0), [products]);

  const totalOutboundUnits = React.useMemo(() => sales.reduce((acc, sale) => {
    return acc + sale.items.reduce((sum, item) => sum + item.quantity, 0);
  }, 0), [sales]);

  const totalInboundUnits = React.useMemo(() => purchases.reduce((acc, pur) => {
    return acc + pur.items.reduce((sum, item) => sum + item.quantity, 0);
  }, 0), [purchases]);

  // Lists categories - Memoized
  const outOfStockList = React.useMemo(() => products.filter((p) => p.quantity === 0), [products]);
  const lowStockList = React.useMemo(() => products.filter((p) => p.quantity > 0 && p.quantity <= p.minStock), [products]);
  const nearExpiredList = React.useMemo(() => products.filter((p) => p.expirationDate > todayStr && p.expirationDate <= threeMonthsLaterStr), [products, todayStr, threeMonthsLaterStr]);
  const expiredList = React.useMemo(() => products.filter((p) => p.expirationDate <= todayStr), [products, todayStr]);

  const displayList = React.useMemo(() => {
    let list = products;
    if (activeTab === "out_of_stock") list = outOfStockList;
    else if (activeTab === "low_stock") list = lowStockList;
    else if (activeTab === "near_expired") list = nearExpiredList;
    else if (activeTab === "expired") list = expiredList;

    if (debouncedSearchQuery.trim()) {
      const q = debouncedSearchQuery.toLowerCase();
      list = list.filter((p) => 
        (p.commercialName || "").toLowerCase().includes(q) || 
        (p.scientificName || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [activeTab, debouncedSearchQuery, products, outOfStockList, lowStockList, nearExpiredList, expiredList]);

  // Reset page size on filter/search change
  useEffect(() => {
    setVisibleCount(25);
  }, [activeTab, debouncedSearchQuery]);

  // Infinite Scroll Observer using requestAnimationFrame
  useEffect(() => {
    if (visibleCount >= displayList.length) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          requestAnimationFrame(() => {
            setVisibleCount((prev) => Math.min(prev + 25, displayList.length));
          });
        }
      },
      { rootMargin: "150px" }
    );

    const trigger = document.getElementById("inventory-load-more");
    if (trigger) {
      observer.observe(trigger);
    }

    return () => {
      observer.disconnect();
    };
  }, [visibleCount, displayList.length]);

  const statBoxes = [
    {
      title: "الكمية المتاحة بالرفوف حالياً",
      value: `${totalStockUnits} علبة`,
      icon: Package,
      color: "bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400 border-emerald-100 dark:border-emerald-900/50"
    },
    {
      title: "الوارد (إجمالي المشتريات)",
      value: `${totalInboundUnits} علبة`,
      icon: TrendingUp,
      color: "bg-blue-50 text-blue-700 dark:bg-blue-950/20 dark:text-blue-400 border-blue-100 dark:border-blue-900/50"
    },
    {
      title: "الصادر (إجمالي المبيعات)",
      value: `${totalOutboundUnits} علبة`,
      icon: TrendingDown,
      color: "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-400 border-indigo-100 dark:border-indigo-900/50"
    },
    {
      title: "الأدوية منتهية الصلاحية",
      value: `${expiredList.length} دواء`,
      icon: CalendarDays,
      color: "bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400 border-rose-100 dark:border-rose-900/50"
    }
  ];

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4" />
        <p className="text-sm text-slate-500">جاري تحميل بيانات جرد المخزن والرفوف...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">تفتيش وجرد المخزن</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">إحصائيات فورية لكميات الأدوية الواردة والصادرة ومراقبة الصلاحيات.</p>
        </div>
        <button
          onClick={loadData}
          className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-350 cursor-pointer flex items-center gap-1.5 transition-colors"
        >
          <RefreshCw className="w-4 h-4 text-emerald-500" />
          <span className="text-xs font-semibold">تحديث الجرد</span>
        </button>
      </div>

      {/* Grid boxes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statBoxes.map((box, i) => {
          const Icon = box.icon;
          return (
            <div key={i} className={`p-5 rounded-2xl border flex items-center justify-between shadow-xs ${box.color}`}>
              <div className="space-y-1">
                <span className="text-xs font-medium opacity-80">{box.title}</span>
                <p className="text-xl font-bold tracking-tight">{box.value}</p>
              </div>
              <div className="p-3 rounded-xl bg-white/60 dark:bg-slate-900/60 shadow-xs">
                <Icon className="w-5 h-5 shrink-0" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Main filter list */}
      <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-4">
        {/* Navigation Tab controls */}
        <div className="flex items-center gap-1.5 overflow-x-auto border-b border-slate-100 dark:border-slate-800 pb-3 scrollbar-thin">
          <button
            onClick={() => setActiveTab("all")}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
              activeTab === "all"
                ? "bg-emerald-600 text-white"
                : "bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-350 hover:bg-slate-100"
            }`}
          >
            الكل ({products.length})
          </button>
          <button
            onClick={() => setActiveTab("out_of_stock")}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
              activeTab === "out_of_stock"
                ? "bg-rose-600 text-white"
                : "bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400 hover:bg-rose-100"
            }`}
          >
            النافدة بالكامل ({outOfStockList.length})
          </button>
          <button
            onClick={() => setActiveTab("low_stock")}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
              activeTab === "low_stock"
                ? "bg-amber-500 text-white"
                : "bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-450 hover:bg-amber-100"
            }`}
          >
            قليلة الكمية ({lowStockList.length})
          </button>
          <button
            onClick={() => setActiveTab("near_expired")}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
              activeTab === "near_expired"
                ? "bg-indigo-600 text-white"
                : "bg-indigo-50 text-indigo-700 dark:bg-indigo-950/20 dark:text-indigo-450 hover:bg-indigo-100"
            }`}
          >
            قريبة من الانتهاء ({nearExpiredList.length})
          </button>
          <button
            onClick={() => setActiveTab("expired")}
            className={`px-4 py-2 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
              activeTab === "expired"
                ? "bg-red-650 text-white"
                : "bg-red-50 text-red-700 dark:bg-red-950/20 dark:text-red-400 hover:bg-red-100"
            }`}
          >
            المنتهية الصلاحية ({expiredList.length})
          </button>
        </div>

        {/* Filter search bar */}
        <div className="relative max-w-sm">
          <input
            type="text"
            placeholder="تصفية الجدول بالاسم التجاري أو العلمي..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <Search className="absolute right-3 top-2.5 w-4 h-4 text-slate-400" />
        </div>

        {/* Results table */}
        <div className="overflow-x-auto rounded-xl border border-slate-100 dark:border-slate-800">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 text-xs font-bold text-slate-500 dark:text-slate-400 border-b border-slate-150 dark:border-slate-800">
                <th className="p-3.5">الدواء</th>
                <th className="p-3.5">رقم التشغيلة</th>
                <th className="p-3.5">تاريخ الانتهاء</th>
                <th className="p-3.5 font-mono">الكمية المتبقية</th>
                <th className="p-3.5">الحد الأدنى للرف</th>
                <th className="p-3.5">موقع الرف</th>
                <th className="p-3.5">حالة التفتيش</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs font-sans">
              {displayList.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-10 text-center text-slate-400">
                    لا توجد أدوية مطابقة للشروط المحددة حالياً.
                  </td>
                </tr>
              ) : (
                <>
                  {displayList.slice(0, visibleCount).map((prod) => {
                    const isOutOfStock = prod.quantity === 0;
                    const isLow = prod.quantity > 0 && prod.quantity <= prod.minStock;
                    const isExpired = prod.expirationDate <= todayStr;
                    const isNearExp = prod.expirationDate > todayStr && prod.expirationDate <= threeMonthsLaterStr;

                    return (
                      <tr key={prod.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                        <td className="p-3.5">
                          <span className="font-bold text-slate-850 dark:text-slate-150 block">{prod.commercialName}</span>
                          <span className="text-[10px] text-slate-400 italic block mt-0.5">{prod.scientificName}</span>
                        </td>
                        <td className="p-3.5 font-mono text-slate-500">{prod.batchNumber}</td>
                        <td className="p-3.5 font-mono font-semibold text-slate-700 dark:text-slate-350">{prod.expirationDate}</td>
                        <td className="p-3.5 font-mono font-bold text-slate-800 dark:text-slate-100">{prod.quantity} علبة</td>
                        <td className="p-3.5 font-mono text-slate-400">{prod.minStock} علبة</td>
                        <td className="p-3.5">
                          <div className="flex items-center gap-1.5 text-slate-500">
                            <MapPin className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{prod.location}</span>
                          </div>
                        </td>
                        <td className="p-3.5">
                          {isExpired ? (
                            <span className="px-2 py-0.5 rounded-md bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 font-bold text-[10px]">
                              منتهي ومرفوض
                            </span>
                          ) : isNearExp ? (
                            <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-bold text-[10px]">
                              قريب انتهاء!
                            </span>
                          ) : isOutOfStock ? (
                            <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-350 font-bold text-[10px]">
                              نافد كلياً
                            </span>
                          ) : isLow ? (
                            <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold text-[10px]">
                              طلب تعويض
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold text-[10px]">
                              سليم ومتاح
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                  {displayList.length > visibleCount && (
                    <tr id="inventory-load-more">
                      <td colSpan={7} className="p-4 text-center bg-slate-50/50 dark:bg-slate-850/20">
                        <div className="flex items-center justify-center gap-2 text-slate-400 font-bold text-xs">
                          <div className="w-4 h-4 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                          <span>جاري تحميل المزيد من الأدوية... (يتم عرض {visibleCount} من {displayList.length})</span>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
