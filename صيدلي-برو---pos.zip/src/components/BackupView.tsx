/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  FileArchive,
  Download,
  Upload,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  FileCode,
  Share2,
  Copy,
  Check,
  Smartphone,
  ShieldCheck,
  FileJson,
  FolderHeart,
  BookOpen
} from "lucide-react";
import JSZip from "jszip";
import { IndexedDBService } from "../db/indexedDB";

export default function BackupView() {
  const [loading, setLoading] = useState(false);
  const [progressMsg, setProgressMsg] = useState("");
  const [progressPct, setProgressPct] = useState(0);
  
  // Drag and drop state
  const [dragActive, setDragActive] = useState(false);
  const [zipBackupInfo, setZipBackupInfo] = useState<{
    fileName: string;
    productsCount: number;
    categoriesCount: number;
    salesCount: number;
    imagesCount: number;
    exportDate: string;
    rawJSON: any;
    rawImages: { productId: string; dataUrl: string }[];
  } | null>(null);

  // Text representation for fail-safe WebView copy/paste
  const [generatedBase64, setGeneratedBase64] = useState<string>("");
  const [pastedBase64, setPastedBase64] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [showTextRestore, setShowTextRestore] = useState(false);

  // Active Android Developer Tab
  const [activeGuideTab, setActiveGuideTab] = useState<"kotlin" | "java" | "xml">("kotlin");
  const [copiedCode, setCopiedCode] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Helper to copy text
  const copyTextToClipboard = (text: string, successMsg: string) => {
    navigator.clipboard.writeText(text).then(() => {
      showToast(successMsg);
    }).catch(() => {
      const textarea = document.createElement("textarea");
      textarea.value = text;
      textarea.style.position = "fixed";
      document.body.appendChild(textarea);
      textarea.focus();
      textarea.select();
      try {
        document.execCommand("copy");
        showToast(successMsg);
      } catch (err) {
        showToast("فشل النسخ التلقائي، يرجى تحديد النص ونسخه يدوياً", "error");
      }
      document.body.removeChild(textarea);
    });
  };

  // --- 1. Export entire DB to a single .zip file using JSZip ---
  const handleExportBackupZip = async (asBase64Text = false) => {
    setLoading(true);
    setProgressPct(5);
    setProgressMsg("جاري قراءة قواعد البيانات المحلية...");

    try {
      const stores = ["categories", "products", "sales", "purchases", "customers", "suppliers", "settings"];
      const backupData: any = {
        exportVersion: "2.0-zip",
        exportDate: new Date().toISOString(),
        system: "صيدلي برو"
      };

      // 1. Fetch text databases
      for (let i = 0; i < stores.length; i++) {
        const storeName = stores[i];
        backupData[storeName] = await IndexedDBService.getAll(storeName);
        setProgressPct(5 + Math.round((i / stores.length) * 40));
        setProgressMsg(`جاري تحميل سجلات ${storeName}...`);
      }

      // 2. Fetch images
      setProgressMsg("جاري تحميل ومعالجة صور الأدوية...");
      setProgressPct(50);
      const images = await IndexedDBService.getAll<{ productId: string; dataUrl: string }>("product_images");

      // Initialize JSZip
      const zip = new JSZip();

      // Write text database JSON file inside ZIP
      setProgressMsg("جاري كتابة ملف البيانات النصية products_data.json...");
      setProgressPct(65);
      zip.file("products_data.json", JSON.stringify(backupData, null, 2));

      // Create product_images directory inside ZIP and add image files
      setProgressMsg("جاري حزم وضغط صور الأدوية...");
      setProgressPct(80);
      const imagesFolder = zip.folder("product_images");

      if (imagesFolder) {
        for (const img of images) {
          // Extract base64 part
          const match = img.dataUrl.match(/^data:(image\/[a-zA-Z+.-]+);base64,(.+)$/);
          if (match) {
            const mimeType = match[1];
            const base64Data = match[2];
            const extension = mimeType.split("/")[1] || "png";
            // Write base64 string directly to zip file
            imagesFolder.file(`${img.productId}.${extension}`, base64Data, { base64: true });
          }
        }
      }

      setProgressMsg("جاري إنتاج الملف المضغوط (.zip)...");
      setProgressPct(90);

      const zipBlob = await zip.generateAsync({ type: "blob" });
      setProgressPct(100);

      const formattedDate = new Date().toISOString().split("T")[0];
      const filename = `backup_pharmapro_${formattedDate}.zip`;

      if (asBase64Text) {
        // Generate Base64 text representation of the zip file itself for direct copy/paste
        setProgressMsg("جاري تحويل الملف إلى كود نصي لسهولة النقل...");
        const zipBase64 = await zip.generateAsync({ type: "base64" });
        setGeneratedBase64(zipBase64);
        showToast("تم توليد الرمز النصي للملف المضغوط بنجاح!");
      } else {
        // Trigger download
        const url = URL.createObjectURL(zipBlob);
        const link = document.createElement("a");
        link.href = url;
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
        showToast("تم تصدير وتنزيل ملف النسخة الاحتياطية المضغوطة (.zip) بنجاح!");
      }
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء تصدير ملف النسخة الاحتياطية", "error");
    } finally {
      setTimeout(() => {
        setLoading(false);
        setProgressPct(0);
        setProgressMsg("");
      }, 500);
    }
  };

  // --- 2. Export and Share ZIP natively via system share ---
  const handleShareBackupZip = async () => {
    setLoading(true);
    setProgressPct(10);
    setProgressMsg("جاري استخلاص السجلات للحقيبة المضغوطة...");

    try {
      const stores = ["categories", "products", "sales", "purchases", "customers", "suppliers", "settings"];
      const backupData: any = {
        exportVersion: "2.0-zip",
        exportDate: new Date().toISOString(),
        system: "صيدلي برو"
      };

      for (let i = 0; i < stores.length; i++) {
        backupData[stores[i]] = await IndexedDBService.getAll(stores[i]);
      }

      setProgressPct(50);
      setProgressMsg("جاري تجميع صور المنتجات والمرفقات...");
      const images = await IndexedDBService.getAll<{ productId: string; dataUrl: string }>("product_images");

      const zip = new JSZip();
      zip.file("products_data.json", JSON.stringify(backupData, null, 2));

      const imagesFolder = zip.folder("product_images");
      if (imagesFolder) {
        for (const img of images) {
          const match = img.dataUrl.match(/^data:(image\/[a-zA-Z+.-]+);base64,(.+)$/);
          if (match) {
            imagesFolder.file(`${img.productId}.${match[1].split("/")[1] || "png"}`, match[2], { base64: true });
          }
        }
      }

      setProgressPct(80);
      setProgressMsg("جاري إنشاء ملف ZIP مشفر للمشاركة...");
      const zipBlob = await zip.generateAsync({ type: "blob" });
      const formattedDate = new Date().toISOString().split("T")[0];
      const filename = `backup_pharmapro_${formattedDate}.zip`;

      const file = new File([zipBlob], filename, { type: "application/zip" });

      if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
        setProgressPct(95);
        setProgressMsg("جاري فتح نافذة المشاركة...");
        await navigator.share({
          files: [file],
          title: "النسخة الاحتياطية الشاملة - صيدلي برو",
          text: `أرشيف مضغوط متكامل يحتوي على كافة سجلات الصيدلية وصور الأدوية حتى تاريخ اليوم.`
        });
        showToast("تمت مشاركة النسخة الاحتياطية بنجاح!");
      } else {
        showToast("ميزة المشاركة المباشرة غير مدعومة في متصفحك. جاري تنزيل الملف كبديل...", "error");
        await handleExportBackupZip(false);
      }
    } catch (err: any) {
      console.error(err);
      if (err.name === "AbortError") {
        showToast("تم إلغاء عملية المشاركة", "error");
      } else {
        showToast("فشلت مشاركة الملف أو تم رفض الصلاحية. جاري تنزيل الملف مباشرة كبديل...", "error");
        await handleExportBackupZip(false);
      }
    } finally {
      setLoading(false);
      setProgressPct(0);
      setProgressMsg("");
    }
  };

  // --- 3. Validate and Parse chosen .zip backup ---
  const validateAndParseZipFile = async (file: File | Blob, name: string) => {
    setLoading(true);
    setProgressPct(10);
    setProgressMsg("جاري فك ضغط وتحليل الأرشيف المختار...");

    try {
      let data: any = null;
      let imagesList: { productId: string; dataUrl: string }[] = [];

      try {
        const zip = await JSZip.loadAsync(file);
        setProgressPct(40);
        setProgressMsg("جاري البحث عن ملف البيانات الرئيسي products_data.json...");

        const dataJsonFile = zip.file("products_data.json");
        if (!dataJsonFile) {
          throw new Error("تنسيق الأرشيف غير صالح. ملف products_data.json مفقود!");
        }

        const jsonText = await dataJsonFile.async("string");
        data = JSON.parse(jsonText);

        setProgressPct(70);
        setProgressMsg("جاري جلب وفك تشفير صور الأدوية...");

        // Reconstruct image dataUrls
        const imagesFolder = zip.folder("product_images");

        if (imagesFolder) {
          const imageFiles: { relativePath: string; file: JSZip.JSZipObject }[] = [];
          imagesFolder.forEach((relativePath, fileObj) => {
            if (!fileObj.dir) {
              imageFiles.push({ relativePath, file: fileObj });
            }
          });

          for (const imgFile of imageFiles) {
            const productId = imgFile.relativePath.substring(0, imgFile.relativePath.lastIndexOf(".")) || imgFile.relativePath;
            const ext = imgFile.relativePath.substring(imgFile.relativePath.lastIndexOf(".") + 1) || "png";
            const mimeType = ext === "jpg" || ext === "jpeg" ? "image/jpeg" : "image/png";
            const base64Str = await imgFile.file.async("base64");
            
            imagesList.push({
              productId,
              dataUrl: `data:${mimeType};base64,${base64Str}`
            });
          }
        }
      } catch (zipError: any) {
        // Fallback: Check if it's a raw JSON file!
        setProgressMsg("فشل تحليل ملف الـ ZIP، محاولة قراءة الملف كـ JSON مباشر...");
        try {
          const text = await new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve(e.target?.result as string);
            reader.onerror = (e) => reject(e);
            reader.readAsText(file);
          });
          data = JSON.parse(text);
          // Check if images are inside this json under product_images or similar
          if (data && data.product_images && Array.isArray(data.product_images)) {
            imagesList = data.product_images;
          }
        } catch (jsonError) {
          // If both fail, throw a clear error
          throw new Error("الملف المرفق ليس ملف ZIP مضغوطاً صالحاً، ولم نتمكن من قراءته كملف JSON مباشر أيضاً. تأكد من صحة الملف.");
        }
      }

      // Simple integrity checks
      if (!data || !data.products || !Array.isArray(data.products) || !data.categories || !Array.isArray(data.categories)) {
        throw new Error("ملف البيانات الرئيسي لا يحتوي على سجلات أدوية أو تصنيفات صالحة.");
      }

      setProgressPct(100);
      setProgressMsg("تم التحقق من سلامة الأرشيف بنجاح!");

      setZipBackupInfo({
        fileName: name,
        productsCount: data.products.length,
        categoriesCount: data.categories.length,
        salesCount: data.sales ? data.sales.length : 0,
        imagesCount: imagesList.length,
        exportDate: data.exportDate ? new Date(data.exportDate).toLocaleString("ar-IQ") : "غير معروف",
        rawJSON: data,
        rawImages: imagesList
      });

      showToast("تم فحص هيكلة الملف والتحقق من سلامته بنجاح!");
    } catch (err: any) {
      console.error(err);
      showToast(`الملف غير صالح: ${err.message || "تلف هيكلي"}`, "error");
      setZipBackupInfo(null);
    } finally {
      setLoading(false);
      setProgressPct(0);
      setProgressMsg("");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndParseZipFile(e.target.files[0], e.target.files[0].name);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndParseZipFile(e.dataTransfer.files[0], e.dataTransfer.files[0].name);
    }
  };

  // --- 4. Confirm restore and overwrite Local IndexedDB ---
  const handleConfirmRestoreZip = async () => {
    if (!zipBackupInfo) return;

    setLoading(true);
    setProgressPct(5);
    setProgressMsg("جاري تهيئة قواعد البيانات وتصفير السجلات الحالية...");

    try {
      // Build unified object for restore
      const fullRestoreData = {
        ...zipBackupInfo.rawJSON,
        product_images: zipBackupInfo.rawImages
      };

      await IndexedDBService.bulkRestore(fullRestoreData, (pct) => {
        setProgressPct(pct);
        setProgressMsg(`جاري مسح السجلات القديمة واستيراد البيانات والصور المرفقة (${pct}%)...`);
      });

      showToast("تمت استعادة كافة البيانات والصور بنجاح تام!");
      setZipBackupInfo(null);
      setTimeout(() => {
        window.location.reload();
      }, 1500);
    } catch (err) {
      console.error(err);
      showToast("فشلت عملية استيراد واستعادة النسخة الاحتياطية الموحدة", "error");
    } finally {
      setLoading(false);
      setProgressPct(0);
      setProgressMsg("");
    }
  };

  // --- 5. Import ZIP from Base64 paste block ---
  const handleImportTextBase64Zip = async () => {
    const trimmed = pastedBase64.trim();
    if (!trimmed) {
      showToast("الرجاء لصق الكود النصي أولاً!", "error");
      return;
    }

    setLoading(true);
    setProgressPct(10);
    setProgressMsg("جاري فك تشفير الكود النصي وإعادة بناء الملف المضغوط...");

    try {
      // Decode Base64 back into binary array buffer
      const binaryString = atob(trimmed);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const zipBlob = new Blob([bytes], { type: "application/zip" });
      await validateAndParseZipFile(zipBlob, "pasted_text_backup.zip");
      setShowTextRestore(false);
      setPastedBase64("");
    } catch (err: any) {
      console.error(err);
      showToast(`الرمز المدخل غير صالح أو غير مكتمل: ${err.message || ""}`, "error");
    } finally {
      setLoading(false);
    }
  };

  // Developer Guides Code Snippets
  const androidKotlinCode = `package com.example.pharmapro

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null

    // Register file chooser contract
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data: Intent? = result.data
            val results = WebChromeClient.FileChooserParams.parseResult(result.resultCode, data)
            fileUploadCallback?.onReceiveValue(results)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        webView = WebView(this)
        setContentView(webView)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true

        // 1. Enable download listener to save ZIP backups
        webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
            try {
                if (url.startsWith("blob:")) {
                    // Trigger download for blob url via JS injection (best for offline apps)
                    webView.evaluateJavascript(
                        "var a = document.createElement('a'); a.href='\$url'; a.download='backup.zip'; document.body.appendChild(a); a.click(); document.body.removeChild(a);",
                        null
                    )
                    Toast.makeText(this, "جاري تنزيل الملف الاحتياطي...", Toast.LENGTH_SHORT).show()
                } else {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.data = Uri.parse(url)
                    startActivity(intent)
                }
            } catch (e: Exception) {
                Toast.makeText(this, "خطأ أثناء التنزيل: \${e.message}", Toast.LENGTH_LONG).show()
            }
        }

        // 2. Handle file inputs (Uploading .zip backup file)
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = fileChooserParams?.createIntent()
                try {
                    fileChooserLauncher.launch(intent)
                } catch (e: Exception) {
                    fileUploadCallback?.onReceiveValue(null)
                    fileUploadCallback = null
                    Toast.makeText(applicationContext, "فشل فتح مستعرض الملفات", Toast.LENGTH_SHORT).show()
                    return false
                }
                return true
            }
        }

        // Load your local index.html or remote dev url
        webView.loadUrl("https://ais-dev-mukkorbhclz4nam5e3wlcc-29072718233.europe-west2.run.app")
    }
}`;

  const androidJavaCode = `package com.example.pharmapro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private ValueCallback<Uri[]> fileUploadCallback;

    private final ActivityResultLauncher<Intent> fileChooserLauncher = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(),
        result -> {
            if (result.getResultCode() == Activity.RESULT_OK) {
                Intent data = result.getData();
                Uri[] results = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), data);
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(results);
                }
            } else {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
            }
            fileUploadCallback = null;
        }
    );

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        // Download Listener
        webView.setDownloadListener((url, userAgent, contentDisposition, mimetype, contentLength) -> {
            try {
                if (url.startsWith("blob:")) {
                    webView.evaluateJavascript(
                        "var a = document.createElement('a'); a.href='" + url + "'; a.download='backup.zip'; document.body.appendChild(a); a.click(); document.body.removeChild(a);",
                        null
                    );
                    Toast.makeText(this, "جاري تصدير الملف...", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setData(Uri.parse(url));
                    startActivity(intent);
                }
            } catch (Exception e) {
                Toast.makeText(this, "فشل التنزيل: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        // WebChromeClient for File selection
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileUploadCallback != null) {
                    fileUploadCallback.onReceiveValue(null);
                }
                fileUploadCallback = filePathCallback;

                Intent intent = fileChooserParams.createIntent();
                try {
                    fileChooserLauncher.launch(intent);
                } catch (Exception e) {
                    fileUploadCallback.onReceiveValue(null);
                    fileUploadCallback = null;
                    Toast.makeText(getApplicationContext(), "فشل فتح مستعرض الملفات", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("https://ais-dev-mukkorbhclz4nam5e3wlcc-29072718233.europe-west2.run.app");
    }
}`;

  const androidXmlCode = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.pharmapro">

    <!-- Permissions required for internet and storage access in WebView -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="صيدلي برو"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.AppCompat.Light.NoActionBar">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
        
    </application>

</manifest>`;

  return (
    <div className="space-y-6 font-sans text-xs">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">
          إدارة الأرشفة والنسخ الاحتياطي الكلي (ZIP)
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">
          تصدير ملف مضغوط واحد يحتوي على كافة الجداول والصور، واستعادته بمرونة مع دعم كامل للمتصفحات والـ WebView.
        </p>
      </div>

      {/* Main Grid: Export and Import Options */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* RIGHT COLUMN: Backup Actions */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <FileArchive className="w-5 h-5 text-emerald-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">حزم وتصدير النسخة الاحتياطية (.zip)</h2>
          </div>

          <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
            يقوم محرك الأرشفة بجمع كافة البيانات النصية (الأدوية، المبيعات، العملاء، الموردين، والإعدادات) في ملف <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono">products_data.json</code>، ثم يستخرج جميع صور الأدوية ويضغطها داخل مجلد فرعي <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono">product_images</code>، لينتج ملفاً واحداً مضغوطاً بصيغة <code className="text-emerald-600 font-bold">.zip</code>.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            {/* Download File */}
            <button
              onClick={() => handleExportBackupZip(false)}
              disabled={loading}
              className="flex items-center justify-center gap-2 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer disabled:opacity-50 transition-colors"
              id="btn-export-zip-file"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل الملف المضغوط (.zip)</span>
            </button>

            {/* Share Native File */}
            <button
              onClick={handleShareBackupZip}
              disabled={loading}
              className="flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-md cursor-pointer disabled:opacity-50 transition-colors"
              id="btn-share-zip"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة ملف ZIP للنظام</span>
            </button>
          </div>

          {/* Fallback to text copy-paste for APK WebViews where file system downloads fail */}
          <div className="border-t border-slate-100 dark:border-slate-800/60 pt-4 mt-2">
            <div className="flex items-center justify-between mb-2">
              <span className="font-semibold text-slate-700 dark:text-slate-300">أداة الطوارئ للـ WebView المحدود:</span>
              <button
                onClick={() => handleExportBackupZip(true)}
                disabled={loading}
                className="text-indigo-600 hover:text-indigo-500 font-bold flex items-center gap-1"
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>توليد كود الـ ZIP النصي</span>
              </button>
            </div>
            <p className="text-[10px] text-slate-400">
              في حال تعذر التحميل المباشر على الأندرويد، اضغط على الخيار أعلاه لإنتاج رمز نصي مشفر يمثل الأرشيف المضغوط بالكامل، لتتمكن من نسخه يدوياً ونقله كرسالة نصية.
            </p>

            {generatedBase64 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-500">رمز الطوارئ للأرشيف المضغوط:</span>
                  <button
                    onClick={() => {
                      copyTextToClipboard(generatedBase64, "تم نسخ الرمز النصي الاحتياطي بنجاح!");
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                    className="flex items-center gap-1 text-emerald-600 hover:text-emerald-500 font-bold"
                  >
                    {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "تم النسخ!" : "نسخ الكود"}</span>
                  </button>
                </div>
                <textarea
                  readOnly
                  value={generatedBase64}
                  onClick={(e) => (e.target as HTMLTextAreaElement).select()}
                  className="w-full h-24 p-2 font-mono text-[9px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none resize-none break-all text-slate-500"
                />
              </motion.div>
            )}
          </div>
        </div>

        {/* LEFT COLUMN: Import Actions */}
        <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
          <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
            <Upload className="w-5 h-5 text-indigo-500" />
            <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs">استيراد واستعادة الأرشيف المضغوط (.zip)</h2>
          </div>

          <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
            اختر ملف الـ <code className="text-emerald-600 font-bold">.zip</code> الذي قمت بتصديره سابقاً، وسيقوم النظام فوراً بتحليل السجلات وفك حزمة الصور وحقنها تلقائياً داخل قاعدة بيانات الهاتف مع المحافظة على توافقية الـ WebView.
          </p>

          {/* Drag & Drop Upload Block */}
          <div
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer ${
              dragActive 
                ? "border-emerald-500 bg-emerald-50/10" 
                : "border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-750"
            }`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
          >
            <input
              type="file"
              id="zip-file-upload"
              accept=".zip"
              className="hidden"
              onChange={handleFileChange}
            />
            <label htmlFor="zip-file-upload" className="cursor-pointer flex flex-col items-center gap-2">
              <FileArchive className="w-9 h-9 text-slate-400" />
              <span className="font-semibold text-slate-600 dark:text-slate-400 text-xs">اسحب وأسقط ملف الأرشيف (.zip) هنا</span>
              <span className="text-[10px] text-slate-400">أو انقر لتصفح واختيار ملف النسخة من هاتفك أو حاسوبك</span>
            </label>
          </div>

          {/* Toggle Paste text backup alternative */}
          <div className="flex items-center justify-between border-t border-slate-100 dark:border-slate-800/60 pt-4">
            <span className="text-[10px] text-slate-400">إذا كنت تواجه مشكلة في تصفح ملفات APK WebView:</span>
            <button
              onClick={() => setShowTextRestore(!showTextRestore)}
              className="text-indigo-600 hover:text-indigo-500 font-bold flex items-center gap-1 text-[11px]"
            >
              <span>{showTextRestore ? "إخفاء لوحة اللصق" : "الاستيراد عبر الكود النصي"}</span>
            </button>
          </div>

          {showTextRestore && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="p-3 bg-amber-50/20 dark:bg-amber-950/10 rounded-xl border border-amber-200/50 dark:border-amber-900/40 space-y-2.5"
            >
              <span className="font-semibold text-amber-800 dark:text-amber-400 block text-[11px]">استعادة البيانات من كود ZIP النصي:</span>
              <textarea
                value={pastedBase64}
                onChange={(e) => setPastedBase64(e.target.value)}
                placeholder="ألصق الرمز النصي المشفر هنا..."
                className="w-full h-24 p-2.5 font-mono text-[9px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-lg focus:ring-1 focus:ring-emerald-500 focus:outline-none"
              />
              <button
                onClick={handleImportTextBase64Zip}
                disabled={!pastedBase64.trim()}
                className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg cursor-pointer transition-colors text-xs disabled:opacity-50"
              >
                تأكيد وتحليل الرمز البرمجي الآن
              </button>
            </motion.div>
          )}

          {/* Validation Metadata Panel if ZIP is Parsed */}
          <AnimatePresence>
            {zipBackupInfo && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-xl border border-emerald-100 dark:border-emerald-900/50 space-y-3.5"
              >
                <div className="flex items-center justify-between text-emerald-800 dark:text-emerald-300">
                  <span className="font-bold flex items-center gap-1.5 text-xs">
                    <CheckCircle className="w-4 h-4 text-emerald-500" />
                    تم التحقق من سلامة الأرشيف بنجاح!
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-600 dark:text-slate-400 border-b border-emerald-100/30 pb-2.5 leading-relaxed">
                  <div className="flex items-center gap-1">
                    <FileJson className="w-3.5 h-3.5 text-indigo-500" />
                    <span>اسم الملف: <strong className="text-slate-800 dark:text-slate-200">{zipBackupInfo.fileName}</strong></span>
                  </div>
                  <div>تاريخ التصدير: <strong className="text-slate-800 dark:text-slate-200">{zipBackupInfo.exportDate}</strong></div>
                  <div>عدد السجلات النصية: <strong className="text-slate-850 dark:text-slate-200">{zipBackupInfo.productsCount} دواء</strong></div>
                  <div className="flex items-center gap-1">
                    <FolderHeart className="w-3.5 h-3.5 text-rose-500" />
                    <span>صور الأدوية المرفقة: <strong className="text-slate-850 dark:text-slate-200">{zipBackupInfo.imagesCount} صورة</strong></span>
                  </div>
                  <div className="col-span-2">التصنيفات والتقارير: <strong className="text-slate-850 dark:text-slate-200">{zipBackupInfo.categoriesCount} فئات | {zipBackupInfo.salesCount} فواتير بيع</strong></div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={handleConfirmRestoreZip}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-sm cursor-pointer transition-colors"
                  >
                    بدء استيراد واستعادة البيانات والصور الآن
                  </button>
                  <button
                    onClick={() => setZipBackupInfo(null)}
                    className="px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>

                <p className="text-[9px] text-rose-500 font-semibold leading-relaxed">
                  * تحذير: الاستعادة ستقوم بمسح السجلات والصور الحالية كلياً واستبدالها بما هو في الأرشيف المختار!
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* WEBVIEW COMPATIBILITY & DEVELOPER GUIDE CARD */}
      <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-5 shadow-sm">
        <div className="flex items-center gap-2 border-b border-slate-100 dark:border-slate-800 pb-3 mb-2">
          <Smartphone className="w-5 h-5 text-indigo-500" />
          <h2 className="font-bold text-slate-850 dark:text-slate-150 text-xs flex items-center gap-1.5">
            <span>دليل مطوري الأندرويد: لتفعيل رفع وتنزيل الملفات في WebView (APK)</span>
            <span className="px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 text-[9px] font-mono font-medium">MainActivity Integration</span>
          </h2>
        </div>

        <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-xs">
          بشكل افتراضي، لا يقوم الـ WebView التابع للأندرويد بالسماح بتنزيل الملفات (مثل ملفات ZIP المولدة تلقائياً) أو رفعها لرفع النسخة الاحتياطية. لتجنب ظهور المشاكل وجعل تطبيقك يعمل كأنه تطبيق محلي native، يرجى تهيئة ملف <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono">MainActivity</code> الخاص بـ Android Studio كما يلي:
        </p>

        {/* Guide Tabs */}
        <div className="border-b border-slate-100 dark:border-slate-800 flex gap-2">
          <button
            onClick={() => setActiveGuideTab("kotlin")}
            className={`pb-2.5 px-4 font-bold border-b-2 text-xs transition-colors cursor-pointer ${
              activeGuideTab === "kotlin"
                ? "border-emerald-500 text-emerald-600 dark:text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            Kotlin (MainActivity.kt)
          </button>
          <button
            onClick={() => setActiveGuideTab("java")}
            className={`pb-2.5 px-4 font-bold border-b-2 text-xs transition-colors cursor-pointer ${
              activeGuideTab === "java"
                ? "border-emerald-500 text-emerald-600 dark:text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            Java (MainActivity.java)
          </button>
          <button
            onClick={() => setActiveGuideTab("xml")}
            className={`pb-2.5 px-4 font-bold border-b-2 text-xs transition-colors cursor-pointer ${
              activeGuideTab === "xml"
                ? "border-emerald-500 text-emerald-600 dark:text-emerald-400"
                : "border-transparent text-slate-400 hover:text-slate-600"
            }`}
          >
            AndroidManifest.xml
          </button>
        </div>

        {/* Code Output with copy button */}
        <div className="relative bg-slate-900 text-slate-200 p-4 rounded-xl font-mono text-[10px] leading-relaxed overflow-x-auto max-h-96">
          <button
            onClick={() => {
              const textToCopy =
                activeGuideTab === "kotlin"
                  ? androidKotlinCode
                  : activeGuideTab === "java"
                  ? androidJavaCode
                  : androidXmlCode;
              copyTextToClipboard(textToCopy, "تم نسخ الكود البرمجي للملف المختار!");
              setCopiedCode(true);
              setTimeout(() => setCopiedCode(false), 2000);
            }}
            className="absolute top-3 left-3 bg-slate-800 hover:bg-slate-700 text-white px-2.5 py-1.5 rounded-md flex items-center gap-1 cursor-pointer font-sans transition-colors"
          >
            {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copiedCode ? "تم النسخ!" : "نسخ الملف"}</span>
          </button>
          <pre className="text-left" dir="ltr">
            {activeGuideTab === "kotlin" && androidKotlinCode}
            {activeGuideTab === "java" && androidJavaCode}
            {activeGuideTab === "xml" && androidXmlCode}
          </pre>
        </div>

        {/* Extra Notes */}
        <div className="p-4 bg-indigo-50/30 dark:bg-indigo-950/10 rounded-xl border border-indigo-100/50 dark:border-indigo-950/40 space-y-2">
          <span className="font-bold text-indigo-900 dark:text-indigo-400 flex items-center gap-1.5 text-xs">
            <BookOpen className="w-4 h-4 text-indigo-500" />
            توجيهات فنية هامة:
          </span>
          <ul className="list-disc list-inside space-y-1.5 text-slate-600 dark:text-slate-400 text-[11px] leading-relaxed">
            <li>قم بتغيير الرابط المذكور في السطر الأخير من دالة <code className="font-mono">loadUrl</code> إلى رابط الخادم الفعلي الخاص بصيدليتك بعد رفعه.</li>
            <li>تفعيل <code className="font-mono">settings.allowFileAccess = true</code> يمنح موقع الويب القدرة على قراءة ملفات النسخة الاحتياطية التي تختارها بشكل محلي وآمن.</li>
            <li>في الكود المرفق، قمنا بتضمين كاشف التنزيل <code className="font-mono">setDownloadListener</code> الذي يتعامل مع مسار الروابط النصية وروابط الـ Blob بنجاح لإجبار الهاتف على فتح شاشة التخزين وتنزيل الـ ZIP بدون أخطاء.</li>
          </ul>
        </div>
      </div>

      {/* Loading Overlay */}
      <AnimatePresence>
        {loading && (
          <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 text-center">
            <div className="p-6 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 max-w-sm w-full space-y-4 shadow-2xl">
              <div className="w-14 h-14 relative flex items-center justify-center mx-auto">
                <div className="absolute inset-0 border-4 border-slate-100 dark:border-slate-800 rounded-full" />
                <div className="absolute inset-0 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                {progressPct > 0 && (
                  <span className="font-mono font-bold text-[10px] text-slate-700 dark:text-slate-300">{progressPct}%</span>
                )}
              </div>
              
              <div className="space-y-2">
                <p className="text-xs font-bold text-slate-850 dark:text-slate-100">{progressMsg || "جاري التحضير..."}</p>
                {progressPct > 0 && (
                  <div className="w-full bg-slate-100 dark:bg-slate-800/60 rounded-full h-1.5 overflow-hidden">
                    <motion.div 
                      className="bg-emerald-500 h-1.5 rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${progressPct}%` }}
                      transition={{ duration: 0.1 }}
                    />
                  </div>
                )}
              </div>
              
              <p className="text-[10px] text-slate-400 leading-relaxed">يرجى الانتظار وعدم إغلاق التطبيق ريثما تكتمل العملية لضمان الحفاظ على سلامة البيانات وصور الأدوية.</p>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast notifications */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-355"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-355"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
