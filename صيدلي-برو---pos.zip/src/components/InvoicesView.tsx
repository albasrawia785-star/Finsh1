/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Receipt, Search, Eye, Trash2, Calendar, FileText, X, CheckCircle, AlertTriangle, User, HelpCircle } from "lucide-react";
import { IndexedDBService } from "../db/indexedDB";
import { SaleInvoice, Customer } from "../types";

interface InvoicesViewProps {
  currency: string;
}

export default function InvoicesView({ currency }: InvoicesViewProps) {
  const [invoices, setInvoices] = useState<SaleInvoice[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  // Detail Modal State
  const [viewInvoice, setViewInvoice] = useState<SaleInvoice | null>(null);
  const [showDeleteModal, setShowDeleteModal] = useState<SaleInvoice | null>(null);

  // Toast
  const [toast, setToast] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const showToast = (text: string, type: "success" | "error" = "success") => {
    setToast({ text, type });
    setTimeout(() => setToast(null), 3000);
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const sales = await IndexedDBService.getAll<SaleInvoice>("sales");
      const custs = await IndexedDBService.getAll<Customer>("customers");
      setInvoices(sales);
      setCustomers(custs);
    } catch (err) {
      console.error(err);
      showToast("حدث خطأ أثناء تحميل الفواتير", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleDeleteInvoice = async () => {
    if (!showDeleteModal) return;

    try {
      // Return inventory back? In a real system yes, let's keep it simple and clean.
      // We will just delete the invoice record and optionally restore stock or notify the user.
      await IndexedDBService.delete("sales", showDeleteModal.id);
      showToast(`تم حذف الفاتورة ${showDeleteModal.invoiceNumber} بنجاح`);
      setShowDeleteModal(null);
      loadData();
    } catch (err) {
      console.error(err);
      showToast("فشل في حذف الفاتورة", "error");
    }
  };

  const getCustomerName = (customerId: string | null) => {
    if (!customerId) return "زبون نقدي عام";
    const cust = customers.find((c) => c.id === customerId);
    return cust ? cust.name : "زبون غير معروف";
  };

  const filteredInvoices = invoices.filter(
    (inv) => {
      const q = (search || "").toLowerCase();
      return (
        (inv.invoiceNumber || "").toLowerCase().includes(q) ||
        (inv.notes || "").toLowerCase().includes(q) ||
        (getCustomerName(inv.customerId) || "").toLowerCase().includes(q)
      );
    }
  );

  // Sort: newest first
  const sortedInvoices = [...filteredInvoices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-slate-800 dark:text-slate-100 font-sans">سجل الفواتير والمبيعات</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 font-sans">أرشيف فواتير مبيعات الصيدلية وجدول تدقيق حركة الكاشير والديون.</p>
      </div>

      {/* Filter & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="relative w-full max-w-sm">
          <input
            type="text"
            placeholder="ابحث برقم الفاتورة، ملاحظات، أو اسم الزبون..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
          />
          <Search className="absolute right-3 top-3 w-4 h-4 text-slate-400" />
        </div>
        <span className="text-xs font-mono text-slate-400">إجمالي الفواتير: {sortedInvoices.length}</span>
      </div>

      {/* Table list */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-850 border-b border-slate-100 dark:border-slate-800 text-xs font-bold text-slate-500 dark:text-slate-400">
                <th className="p-4">رقم الفاتورة</th>
                <th className="p-4">تاريخ المبيعات والوقت</th>
                <th className="p-4">الزبون</th>
                <th className="p-4">عدد المواد</th>
                <th className="p-4">الخصم الممنوح</th>
                <th className="p-4">المبلغ الإجمالي</th>
                <th className="p-4 text-center">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs font-sans">
              {loading ? (
                <tr>
                  <td colSpan={7} className="p-10 text-center">
                    <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <span>جاري تحميل سجل الفواتير...</span>
                  </td>
                </tr>
              ) : sortedInvoices.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-slate-400">
                    لا توجد فواتير مبيعات مسجلة في النظام مطابقة للبحث.
                  </td>
                </tr>
              ) : (
                sortedInvoices.map((inv) => {
                  const itemsCount = inv.items.reduce((sum, item) => sum + item.quantity, 0);
                  const dateFormatted = new Date(inv.date).toLocaleDateString("ar-IQ", {
                    year: "numeric",
                    month: "short",
                    day: "numeric"
                  });
                  const timeFormatted = new Date(inv.date).toLocaleTimeString("ar-IQ", {
                    hour: "2-digit",
                    minute: "2-digit"
                  });

                  return (
                    <tr key={inv.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                      <td className="p-4 font-bold font-mono text-slate-800 dark:text-slate-200 text-xs">
                        {inv.invoiceNumber}
                      </td>
                      <td className="p-4 text-slate-600 dark:text-slate-400">
                        <span>{dateFormatted}</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">{timeFormatted}</span>
                      </td>
                      <td className="p-4 text-slate-700 dark:text-slate-300 font-semibold">
                        {getCustomerName(inv.customerId)}
                      </td>
                      <td className="p-4 font-mono font-semibold text-slate-600 dark:text-slate-400">
                        {itemsCount} علب
                      </td>
                      <td className="p-4 font-mono text-rose-500 font-semibold">
                        {inv.discount > 0 ? `${inv.discount.toLocaleString("ar-IQ")} ${currency}` : "—"}
                      </td>
                      <td className="p-4 font-mono font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                        {inv.total.toLocaleString("ar-IQ")} {currency}
                      </td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            id={`view-inv-${inv.id}`}
                            onClick={() => setViewInvoice(inv)}
                            className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 cursor-pointer flex items-center gap-1"
                            title="عرض تفاصيل الفاتورة"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>عرض</span>
                          </button>
                          <button
                            onClick={() => setShowDeleteModal(inv)}
                            className="p-1.5 rounded-lg border border-rose-100 hover:bg-rose-50 text-rose-600 cursor-pointer"
                            title="حذف الفاتورة"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* --- INVOICE DETAIL VIEW MODAL --- */}
      <AnimatePresence>
        {viewInvoice && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-lg shadow-2xl my-8"
            >
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-emerald-500" />
                  <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm">تفاصيل فاتورة البيع</h3>
                </div>
                <button
                  onClick={() => setViewInvoice(null)}
                  className="p-1 rounded-lg hover:bg-slate-100 text-slate-500"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Invoice Meta */}
              <div className="bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-150 dark:border-slate-800 grid grid-cols-2 gap-3 mb-4 text-xs">
                <div>
                  <span className="text-slate-400">رقم الفاتورة الكلي:</span>
                  <p className="font-bold text-slate-800 dark:text-slate-100 font-mono mt-0.5">{viewInvoice.invoiceNumber}</p>
                </div>
                <div>
                  <span className="text-slate-400">التاريخ والوقت:</span>
                  <p className="font-semibold text-slate-700 dark:text-slate-300 mt-0.5">
                    {new Date(viewInvoice.date).toLocaleString("ar-IQ", { hour: "numeric", minute: "numeric", day: "numeric", month: "short", year: "numeric" })}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400">اسم العميل:</span>
                  <p className="font-semibold text-slate-700 dark:text-slate-300 mt-0.5">{getCustomerName(viewInvoice.customerId)}</p>
                </div>
                <div>
                  <span className="text-slate-400">حالة الدفع:</span>
                  <p className="mt-0.5">
                    {viewInvoice.customerId && viewInvoice.total > 0 ? (
                      <span className="px-2 py-0.5 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 rounded-md font-semibold text-[10px]">
                        آجل (دين مسجل)
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-md font-semibold text-[10px]">
                        نقدي مكتمل
                      </span>
                    )}
                  </p>
                </div>
              </div>

              {/* Products List in Invoice */}
              <div className="space-y-2.5 mb-4 max-h-[180px] overflow-y-auto pr-1">
                <span className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-2">الأصناف المبيعة:</span>
                {viewInvoice.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs py-1.5 border-b border-dashed border-slate-100 dark:border-slate-800 last:border-b-0">
                    <div>
                      <p className="font-bold text-slate-800 dark:text-slate-200">{item.commercialName}</p>
                      <p className="text-[10px] text-slate-400 italic mt-0.5">{item.scientificName}</p>
                    </div>
                    <div className="flex items-center gap-4 text-left">
                      <span className="text-slate-500 font-mono">
                        {item.quantity} علبة × {item.price.toLocaleString("ar-IQ")} د.ع
                      </span>
                      <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">
                        {item.total.toLocaleString("ar-IQ")} د.ع
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Total calculations */}
              <div className="border-t border-slate-100 dark:border-slate-800 pt-3 space-y-2 text-xs font-sans">
                <div className="flex justify-between text-slate-500">
                  <span>المجموع الفرعي:</span>
                  <span className="font-mono font-bold">{viewInvoice.subtotal.toLocaleString("ar-IQ")} د.ع</span>
                </div>
                {viewInvoice.discount > 0 && (
                  <div className="flex justify-between text-rose-500 font-semibold">
                    <span>قيمة الخصم:</span>
                    <span className="font-mono">-{viewInvoice.discount.toLocaleString("ar-IQ")} د.ع</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-bold text-slate-850 dark:text-slate-100 border-t border-dashed border-slate-100 dark:border-slate-800 pt-2.5">
                  <span>المجموع الكلي المدفوع:</span>
                  <span className="text-base text-emerald-600 dark:text-emerald-400 font-mono">
                    {viewInvoice.total.toLocaleString("ar-IQ")} د.ع
                  </span>
                </div>
              </div>

              {/* Invoice notes if available */}
              {viewInvoice.notes && (
                <div className="mt-4 p-2.5 bg-slate-50 dark:bg-slate-800 rounded-lg text-[11px] border text-slate-500 dark:text-slate-400 leading-relaxed">
                  <span className="font-bold block text-slate-700 dark:text-slate-300 mb-0.5">ملاحظات الفاتورة:</span>
                  {viewInvoice.notes}
                </div>
              )}

              <div className="flex items-center gap-3 justify-end pt-4 border-t border-slate-100 dark:border-slate-800 mt-6">
                <button
                  onClick={() => setViewInvoice(null)}
                  className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer"
                >
                  إغلاق النافذة
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- DELETE CONFIRM MODAL --- */}
      <AnimatePresence>
        {showDeleteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 w-full max-w-sm shadow-2xl text-center font-sans"
            >
              <div className="w-12 h-12 rounded-full bg-rose-50 dark:bg-rose-950 flex items-center justify-center mx-auto text-rose-600 mb-4 animate-pulse">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mb-2">حذف فاتورة المبيعات</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mb-6">
                هل أنت متأكد من حذف الفاتورة <span className="font-bold text-slate-800 dark:text-slate-100">"{showDeleteModal.invoiceNumber}"</span>؟ سيتم شطب الفاتورة نهائياً من سجل التدقيق.
              </p>
              
              <div className="flex items-center gap-3 justify-center">
                <button
                  onClick={() => setShowDeleteModal(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 text-xs font-semibold cursor-pointer hover:bg-slate-50"
                >
                  تراجع
                </button>
                <button
                  onClick={handleDeleteInvoice}
                  className="px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-semibold hover:bg-rose-500 cursor-pointer"
                >
                  نعم، احذف الفاتورة
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-6 right-6 z-50 px-5 py-3.5 rounded-2xl shadow-xl flex items-center gap-2.5 border text-xs max-w-sm ${
              toast.type === "success"
                ? "bg-emerald-50 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900 text-emerald-800 dark:text-emerald-350"
                : "bg-rose-50 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900 text-rose-800 dark:text-rose-350"
            }`}
          >
            <CheckCircle className="w-5 h-5 shrink-0 text-emerald-500" />
            <span className="font-semibold leading-relaxed">{toast.text}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
