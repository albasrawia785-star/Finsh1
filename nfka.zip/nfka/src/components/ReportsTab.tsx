import React, { useState, useMemo, useRef, useEffect } from 'react';
import { AppSettings, Debtor, DebtorTransaction, DebtStats, User, InstallmentRecord } from '../types';
import { formatNumber, formatDateDigits } from '../utils/formatters';
import { getUserBranchDisplayName, getUserDisplayName } from '../utils/userUtils';
import { getLocalDebtorHistory } from '../services/turso';
import { InstallmentsReport } from './InstallmentsReport';
import { useI18n } from '../i18n/index.tsx';

export type ReportMode = 'debts' | 'installments';
export type ReportFilterPeriod = 'today' | 'week' | 'month' | 'last_month' | 'custom' | 'all';
export type TxTypeFilter = 'all' | 'add' | 'pay';

interface EnrichedTransaction extends DebtorTransaction {
  debtorId: number;
  debtorName: string;
  debtorPhone?: string;
}

interface DebtorGroupSummary {
  debtorId: number;
  debtorName: string;
  debtorPhone?: string;
  currentTotalDebt: number;
  periodAdded: number;
  periodPaid: number;
  periodNet: number;
  addsCount: number;
  paysCount: number;
  transactions: EnrichedTransaction[];
}

interface ReportsTabProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  stats: DebtStats;
  settings?: AppSettings;
  mode?: ReportMode;
  isActive?: boolean;
  onUpdateStats?: (newStats: DebtStats) => void;
  onResetStats?: () => void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const ReportsTab: React.FC<ReportsTabProps> = React.memo(({
  currentUser,
  debtors,
  installments = [],
  stats,
  mode,
  isActive = true,
  onResetStats,
  onShowToast,
}) => {
  const { t, numberFormat, currency } = useI18n();

  // ----------------------------------------------------
  // State: Report Mode (Debts vs Installments)
  // ----------------------------------------------------
  const canSwitchModules =
    currentUser.role === 'admin' ||
    !currentUser.allowedModules ||
    currentUser.allowedModules === 'both';

  const initialMode: ReportMode =
    currentUser.allowedModules === 'installments'
      ? 'installments'
      : currentUser.allowedModules === 'debts'
      ? 'debts'
      : mode || 'debts';

  const [reportMode, setReportMode] = useState<ReportMode>(initialMode);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync mode with prop or user permission if provided
  useEffect(() => {
    if (currentUser.allowedModules === 'installments') {
      setReportMode('installments');
    } else if (currentUser.allowedModules === 'debts') {
      setReportMode('debts');
    } else if (mode) {
      setReportMode(mode);
    }
  }, [mode, currentUser.allowedModules]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  // ----------------------------------------------------
  // State: Filter period, custom dates, expanded cards, and search/type
  // ----------------------------------------------------
  const [filterPeriod, setFilterPeriod] = useState<ReportFilterPeriod>('all');
  
  // Custom date picker state
  const todayIso = new Date().toISOString().split('T')[0];
  const [customStartDate, setCustomStartDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(1); // 1st of current month
    return d.toISOString().split('T')[0];
  });
  const [customEndDate, setCustomEndDate] = useState<string>(todayIso);

  // Table filters & search
  const [txSearchTerm, setTxSearchTerm] = useState('');
  const [txTypeFilter, setTxTypeFilter] = useState<TxTypeFilter>('all');
  const [copiedReport, setCopiedReport] = useState(false);

  // Expanded Accordion State (Debtor IDs that are open)
  const [expandedDebtorIds, setExpandedDebtorIds] = useState<Set<number>>(new Set());
  const [visibleGroupsLimit, setVisibleGroupsLimit] = useState(30);

  useEffect(() => {
    setVisibleGroupsLimit(30);
  }, [filterPeriod, txTypeFilter, txSearchTerm]);

  const toggleDebtorExpanded = (debtorId: number) => {
    setExpandedDebtorIds((prev) => {
      const next = new Set(prev);
      if (next.has(debtorId)) {
        next.delete(debtorId);
      } else {
        next.add(debtorId);
      }
      return next;
    });
  };

  const expandAllDebtors = (ids: number[]) => {
    setExpandedDebtorIds(new Set(ids));
  };

  const collapseAllDebtors = () => {
    setExpandedDebtorIds(new Set());
  };

  // ----------------------------------------------------
  // Aggregate all transactions from debtors & localStorage
  // ----------------------------------------------------
  const allTransactions = useMemo<EnrichedTransaction[]>(() => {
    if (!currentUser || !isActive) return [];
    const historyMap = getLocalDebtorHistory(currentUser.id);
    const list: EnrichedTransaction[] = [];
    const seenKeys = new Set<string>();

    const maxDebtorsToCheck = Math.min(debtors.length, 1000);
    for (let i = 0; i < maxDebtorsToCheck; i++) {
      const debtor = debtors[i];
      if (!debtor) continue;
      const isDemo = debtor.isDemo || (typeof debtor.id === 'number' && debtor.id < 0);

      // 1. Transactions from debtor.history array or local storage history map (skip map for demo)
      const debtorHist: DebtorTransaction[] = debtor.history || (!isDemo ? historyMap[debtor.id] : undefined) || [];

      for (let j = 0; j < debtorHist.length; j++) {
        const tx = debtorHist[j];
        const key = `${debtor.id}_${tx.id || tx.date}_${tx.amount}_${tx.type}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          list.push({
            ...tx,
            debtorId: debtor.id,
            debtorName: debtor.name,
            debtorPhone: debtor.phone,
          });
        }
      }

      // 2. Fallback: If debtor was created with initial debt and has no history entries (only for real debtors)
      if (!isDemo && debtorHist.length === 0 && (Number(debtor.amount) || 0) > 0) {
        const key = `${debtor.id}_initial_${debtor.amount}`;
        if (!seenKeys.has(key)) {
          seenKeys.add(key);
          list.push({
            id: `initial_${debtor.id}`,
            type: 'add',
            amount: Number(debtor.amount) || 0,
            balanceAfter: Number(debtor.amount) || 0,
            date: debtor.createdAt || new Date().toISOString(),
            description: debtor.notes || t('reports.initialBalance', 'رصيد افتتاحي / دين سابق'),
            notes: debtor.notes,
            debtorId: debtor.id,
            debtorName: debtor.name,
            debtorPhone: debtor.phone,
          });
        }
      }
    }

    // Sort descending by date (newest first)
    return list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [debtors, currentUser, t, isActive]);

  // ----------------------------------------------------
  // Calculate Date Boundaries for Selected Filter
  // ----------------------------------------------------
  const { periodLabel, isDateInRange } = useMemo(() => {
    const now = new Date();
    
    // Start and end of today
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

    // Start and end of this week (last 7 days)
    const startOfWeek = new Date(startOfToday);
    startOfWeek.setDate(startOfWeek.getDate() - 6);

    // Start and end of this month
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

    // Start and end of previous month
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);

    let label = t('reports.allPeriods', 'الإجمالي العام لكافة الفترات');
    let checkFn = (_date: Date) => true;

    if (filterPeriod === 'today') {
      label = `${t('reports.today', 'اليوم')} (${formatDateDigits(now.toISOString().split('T')[0], numberFormat)})`;
      checkFn = (d: Date) => d >= startOfToday && d <= endOfToday;
    } else if (filterPeriod === 'week') {
      label = t('reports.thisWeek', 'هذا الأسبوع (آخر 7 أيام)');
      checkFn = (d: Date) => d >= startOfWeek && d <= endOfToday;
    } else if (filterPeriod === 'month') {
      label = `${t('reports.thisMonth', 'هذا الشهر')} (${formatDateDigits(`${now.getFullYear()}-${now.getMonth() + 1}`, numberFormat)})`;
      checkFn = (d: Date) => d >= startOfMonth && d <= endOfMonth;
    } else if (filterPeriod === 'last_month') {
      const prevMonthIdx = (now.getMonth() + 11) % 12;
      const prevMonthYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear();
      label = `${t('reports.lastMonth', 'الشهر السابق')} (${formatDateDigits(`${prevMonthYear}-${prevMonthIdx + 1}`, numberFormat)})`;
      checkFn = (d: Date) => d >= startOfLastMonth && d <= endOfLastMonth;
    } else if (filterPeriod === 'custom') {
      const start = customStartDate ? new Date(`${customStartDate}T00:00:00`) : new Date(0);
      const end = customEndDate ? new Date(`${customEndDate}T23:59:59.999`) : new Date();
      label = `${t('reports.customPeriod', 'فترة مخصصة')} (${formatDateDigits(customStartDate || '', numberFormat)} - ${formatDateDigits(customEndDate || '', numberFormat)})`;
      checkFn = (d: Date) => d >= start && d <= end;
    }

    return {
      periodLabel: label,
      isDateInRange: checkFn,
    };
  }, [filterPeriod, customStartDate, customEndDate, t, numberFormat]);

  // ----------------------------------------------------
  // Filtered Transactions for the Selected Period
  // ----------------------------------------------------
  const periodTransactions = useMemo(() => {
    return allTransactions.filter((tx) => {
      const d = new Date(tx.date);
      if (isNaN(d.getTime())) return filterPeriod === 'all';
      return isDateInRange(d);
    });
  }, [allTransactions, isDateInRange, filterPeriod]);

  // ----------------------------------------------------
  // Grouping by Debtor
  // ----------------------------------------------------
  const debtorGroups = useMemo<DebtorGroupSummary[]>(() => {
    const debtorMap = new Map<number, DebtorGroupSummary>();

    // Index debtors involved in transactions
    for (let i = 0; i < periodTransactions.length; i++) {
      const tx = periodTransactions[i];
      if (!tx) continue;
      let group = debtorMap.get(tx.debtorId);
      if (!group) {
        group = {
          debtorId: tx.debtorId,
          debtorName: tx.debtorName || '',
          debtorPhone: tx.debtorPhone || '',
          currentTotalDebt: 0,
          periodAdded: 0,
          periodPaid: 0,
          periodNet: 0,
          addsCount: 0,
          paysCount: 0,
          transactions: [],
        };
        debtorMap.set(tx.debtorId, group);
      }

      group.transactions.push(tx);
      if (tx.type === 'add') {
        group.periodAdded += tx.amount || 0;
        group.addsCount += 1;
      } else if (tx.type === 'pay') {
        group.periodPaid += tx.amount || 0;
        group.paysCount += 1;
      }
      group.periodNet = group.periodPaid - group.periodAdded;
    }

    // Convert map to array and sort debtors
    const list = Array.from(debtorMap.values());
    return list.sort((a, b) => {
      if (b.transactions.length !== a.transactions.length) {
        return b.transactions.length - a.transactions.length;
      }
      const nameA = a?.debtorName || '';
      const nameB = b?.debtorName || '';
      return nameA < nameB ? -1 : nameA > nameB ? 1 : 0;
    });
  }, [periodTransactions]);

  // ----------------------------------------------------
  // Dynamic Period Aggregates
  // ----------------------------------------------------
  const {
    periodAdded,
    periodPaid,
    periodNetMovement,
    periodDebtorsInvolved,
    periodAddsCount,
    periodPaysCount,
  } = useMemo(() => {
    let added = 0;
    let paid = 0;
    let addsCount = 0;
    let paysCount = 0;
    const debtorIdSet = new Set<number>();

    if (filterPeriod === 'all' && stats) {
      const sumTxAdded = periodTransactions.filter((t) => t.type === 'add').reduce((s, t) => s + t.amount, 0);
      const sumTxPaid = periodTransactions.filter((t) => t.type === 'pay').reduce((s, t) => s + t.amount, 0);
      
      let currentActiveDebts = 0;
      const len = debtors.length;
      for (let i = 0; i < len; i++) {
        currentActiveDebts += Number(debtors[i]?.amount) || 0;
      }

      paid = Math.max(stats.totalPaid || 0, sumTxPaid);
      added = Math.max(stats.totalAdded || 0, currentActiveDebts + paid, sumTxAdded);
      
      addsCount = periodTransactions.filter((t) => t.type === 'add').length;
      paysCount = periodTransactions.filter((t) => t.type === 'pay').length;
    } else {
      periodTransactions.forEach((tx) => {
        debtorIdSet.add(tx.debtorId);
        if (tx.type === 'add') {
          added += tx.amount;
          addsCount++;
        } else if (tx.type === 'pay') {
          paid += tx.amount;
          paysCount++;
        }
      });
    }

    const net = paid - added;

    return {
      periodAdded: added,
      periodPaid: paid,
      periodNetMovement: net,
      periodDebtorsInvolved: filterPeriod === 'all' ? debtors.length : debtorIdSet.size,
      periodAddsCount: addsCount,
      periodPaysCount: paysCount,
    };
  }, [periodTransactions, filterPeriod, stats, debtors]);

  const currentTotalDebts = useMemo(() => {
    if (debtors.length === 0) return 0;
    let sum = 0;
    const len = debtors.length;
    for (let i = 0; i < len; i++) {
      sum += Number(debtors[i]?.amount) || 0;
    }
    return sum;
  }, [debtors]);

  const collectionRate = periodAdded > 0 ? (periodPaid / periodAdded) * 100 : 0;
  const collectionRateFormatted = formatNumber(Math.round(collectionRate), numberFormat);

  // ----------------------------------------------------
  // Filtered Debtor Groups
  // ----------------------------------------------------
  const displayedDebtorGroups = useMemo(() => {
    return debtorGroups
      .map((group) => {
        let filteredTxs = group.transactions;
        if (txTypeFilter !== 'all') {
          filteredTxs = filteredTxs.filter((t) => t.type === txTypeFilter);
        }

        if (txSearchTerm.trim()) {
          const query = txSearchTerm.trim().toLowerCase();
          const matchName = group.debtorName.toLowerCase().includes(query);
          const matchPhone = (group.debtorPhone || '').includes(query);
          const matchTxs = filteredTxs.filter((t) => {
            const noteMatch = (t.notes || t.description || '').toLowerCase().includes(query);
            const amtMatch = String(t.amount).includes(query);
            return noteMatch || amtMatch;
          });

          if (!matchName && !matchPhone && matchTxs.length === 0) {
            return null;
          }

          if (!matchName && !matchPhone) {
            filteredTxs = matchTxs;
          }
        }

        if (filteredTxs.length === 0 && txTypeFilter !== 'all') {
          return null;
        }

        if (filteredTxs.length === 0 && !txSearchTerm.trim() && filterPeriod !== 'all') {
          return null;
        }

        return {
          ...group,
          transactions: filteredTxs,
        };
      })
      .filter((g): g is DebtorGroupSummary => g !== null);
  }, [debtorGroups, txTypeFilter, txSearchTerm, filterPeriod]);

  // All visible debtor IDs for quick expand all
  const visibleDebtorIds = useMemo(
    () => displayedDebtorGroups.map((g) => g.debtorId),
    [displayedDebtorGroups]
  );

  // ----------------------------------------------------
  // Share & Copy Text Report
  // ----------------------------------------------------
  const generateReportText = () => {
    const branch = getUserBranchDisplayName(currentUser, t);

    let text = `*${t('reports.financialReport', 'تقرير الحركة المالية وسجل المدينين')}*\n`;
    text += `*${t('reports.branch', 'الفرع')}:* ${branch}\n`;
    text += `*${t('reports.user', 'المستخدم')}:* ${getUserDisplayName(currentUser, t)}\n`;
    text += `*${t('reports.period', 'الفترة')}:* ${periodLabel}\n`;
    text += `*${t('reports.exportDate', 'تاريخ الاستخراج')}:* ${formatDateDigits(new Date().toISOString().split('T')[0], numberFormat)}\n`;
    text += `------------------------------------\n`;
    text += `*${t('reports.totalDebtsAdded', 'إجمالي الديون المضافة للفترة')}:* ${formatNumber(periodAdded, numberFormat)} ${currency} (${formatNumber(periodAddsCount, numberFormat)} ${t('reports.operations', 'عملية')})\n`;
    text += `*${t('reports.totalAmountsPaid', 'إجمالي المبالغ المسددة للفترة')}:* ${formatNumber(periodPaid, numberFormat)} ${currency} (${formatNumber(periodPaysCount, numberFormat)} ${t('reports.operations', 'عملية')})\n`;
    
    if (periodNetMovement > 0) {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* +${formatNumber(periodNetMovement, numberFormat)} ${currency}\n`;
    } else if (periodNetMovement < 0) {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* ${formatNumber(periodNetMovement, numberFormat)} ${currency}\n`;
    } else {
      text += `*${t('reports.netMovement', 'صافي الحركة')}:* 0 ${currency}\n`;
    }

    text += `*${t('reports.currentActiveDebts', 'إجمالي الديون القائمة حالياً')}:* ${formatNumber(currentTotalDebts, numberFormat)} ${currency}\n`;
    text += `*${t('reports.activeDebtorsInPeriod', 'المدينين المتفاعلين في الفترة')}:* ${formatNumber(periodDebtorsInvolved, numberFormat)}\n`;
    text += `------------------------------------\n`;

    const activeGroups = displayedDebtorGroups.filter((g) => g.transactions.length > 0);
    if (activeGroups.length > 0) {
      text += `*${t('reports.detailsByDebtor', 'تفاصيل وسجل العمليات حسب المدينين')} (${formatNumber(activeGroups.length, numberFormat)}):*\n\n`;
      activeGroups.forEach((g, gIdx) => {
        text += `${formatNumber(gIdx + 1, numberFormat)}) *${g.debtorName}*`;
        if (g.debtorPhone) text += ` (${formatDateDigits(g.debtorPhone, numberFormat)})`;
        text += `\n`;
        text += `   • ${t('reports.outstandingBalance', 'الرصيد القائم')}: ${formatNumber(g.currentTotalDebt, numberFormat)} ${currency}\n`;
        text += `   • ${t('reports.debtsAdded', 'ديون أضيفت')}: +${formatNumber(g.periodAdded, numberFormat)} ${currency} (${formatNumber(g.addsCount, numberFormat)})\n`;
        text += `   • ${t('reports.debtsPaid', 'مسددات')}: -${formatNumber(g.periodPaid, numberFormat)} ${currency} (${formatNumber(g.paysCount, numberFormat)})\n`;
        
        if (g.transactions.length > 0) {
          text += `   • ${t('reports.transactionsLog', 'سجل الحركات')}:\n`;
          g.transactions.slice(0, 5).forEach((tx) => {
            const sym = tx.type === 'pay' ? `[${t('reports.payment', 'سداد')}]` : `[${t('reports.debt', 'دين')}]`;
            text += `     - ${sym}: ${formatNumber(tx.amount, numberFormat)} ${currency} (${formatDateDigits(tx.date, numberFormat)})\n`;
            if (tx.notes) text += `       ${t('reports.note', 'ملاحظة')}: ${tx.notes}\n`;
          });
          if (g.transactions.length > 5) {
            text += `     - ... ${t('reports.andMoreTransactions', 'وحركات أخرى')} (${formatNumber(g.transactions.length - 5, numberFormat)})\n`;
          }
        }
        text += `\n`;
      });
    } else {
      text += `${t('reports.noTransactionsInPeriod', 'لا توجد حركات مسجلة خلال هذه الفترة.')}\n`;
    }

    text += `------------------------------------\n`;
    text += `${t('common.appName', 'دفتر الديون')}`;
    return text;
  };

  const handleShareWhatsApp = () => {
    const reportText = generateReportText();
    const url = `https://wa.me/?text=${encodeURIComponent(reportText)}`;
    window.open(url, '_blank');
  };

  const handleCopyReport = async () => {
    try {
      const reportText = generateReportText();
      await navigator.clipboard.writeText(reportText);
      setCopiedReport(true);
      if (onShowToast) {
        onShowToast(t('reports.reportCopiedSuccess', 'تم نسخ التقرير المالي بنجاح'), 'success');
      }
      setTimeout(() => setCopiedReport(false), 2500);
    } catch {
      if (onShowToast) {
        onShowToast(t('reports.copyFailed', 'تعذر النسخ تلقائياً، يرجى المحاولة يدوياً'), 'error');
      }
    }
  };

  return (
    <div id="tab-reports" className="pb-40 space-y-3.5 animate-in fade-in duration-150">
      {/* ---------------------------------------------------- */}
      {/* 1. Header - Sticky */}
      {/* ---------------------------------------------------- */}
      <div className="sticky top-0 z-30 bg-slate-50 px-4 safe-top pb-2.5 border-b border-slate-200 gpu-layer">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {reportMode === 'debts' ? t('reports.debtsAndOpsReports', 'تقارير الديون والعمليات') : t('reports.installmentsReports', 'تقارير الأقساط الشهرية')}
              </h1>

              {/* DROPDOWN FILTER FOR REPORTS: الديون vs الأقساط (ONLY IF CAN SWITCH) */}
              {canSwitchModules && (
                <div className="relative" ref={dropdownRef}>
                  <button
                    type="button"
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="px-2.5 py-1 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 shadow-xs text-xs font-black text-slate-800 flex items-center gap-1.5 transition-all cursor-pointer"
                  >
                    <span className={`w-2 h-2 rounded-full ${
                      reportMode === 'debts' ? 'bg-blue-600' : 'bg-emerald-600'
                    }`}></span>
                    <span>{reportMode === 'debts' ? t('reports.debtBook', 'دفتر الديون') : t('reports.installmentsSystem', 'نظام الأقساط')}</span>
                    <i className="fa-solid fa-chevron-down text-[9px] text-slate-400"></i>
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute top-full start-0 mt-1 w-44 bg-white border border-slate-200 rounded-2xl shadow-xl p-1 z-50 animate-in fade-in zoom-in-95 duration-100 space-y-0.5">
                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('debts');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'debts' ? 'bg-blue-50 text-blue-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-users text-xs text-blue-600"></i>
                          <span>{t('reports.debtsReports', 'تقارير الديون')}</span>
                        </div>
                        {reportMode === 'debts' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setReportMode('installments');
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full px-3 py-1.5 rounded-xl text-xs font-bold flex items-center justify-between cursor-pointer ${
                          reportMode === 'installments' ? 'bg-emerald-50 text-emerald-700' : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="flex items-center gap-1.5">
                          <i className="fa-solid fa-clock-rotate-left text-xs text-emerald-600"></i>
                          <span>{t('reports.installmentsReports', 'تقارير الأقساط')}</span>
                        </div>
                        {reportMode === 'installments' && <i className="fa-solid fa-check text-[10px]"></i>}
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            <p className="text-xs font-medium text-slate-500 mt-0.5">
              {getUserBranchDisplayName(currentUser, t)} • {reportMode === 'debts' ? t('reports.debtorOperationsLog', 'سجل العمليات المنسدل لكل مدين') : t('reports.collectionTrackingContracts', 'تحصيل ومتابعة عقود الأقساط')}
            </p>
          </div>

          {/* Quick Actions (Copy / Share WhatsApp) */}
          {reportMode === 'debts' && (
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleCopyReport}
                className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 shadow-xs text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                title={t('reports.copyReportTitle', 'نسخ التقرير إلى الحافظة')}
              >
                <i className={`fa-solid ${copiedReport ? 'fa-check text-emerald-600' : 'fa-copy'}`}></i>
                <span className="hidden sm:inline">{copiedReport ? t('reports.copied', 'تم النسخ') : t('reports.copyReport', 'نسخ التقرير')}</span>
              </button>

              <button
                type="button"
                onClick={handleShareWhatsApp}
                className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer"
                title={t('reports.shareWhatsAppTitle', 'مشاركة التقرير عبر واتساب')}
              >
                <i className="fa-brands fa-whatsapp text-sm"></i>
                <span className="hidden sm:inline">{t('reports.shareWhatsApp', 'مشاركة واتساب')}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="px-4 space-y-3.5">
        {/* Render Installments Report if mode === 'installments' */}
        {reportMode === 'installments' ? (
          <InstallmentsReport
            installments={installments}
            onShowToast={onShowToast}
          />
        ) : (
          <>
        {/* ---------------------------------------------------- */}
        {/* 2. شريط خيارات الفلترة السريعة */}
        {/* ---------------------------------------------------- */}
        <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold">
                <i className="fa-solid fa-calendar-check"></i>
              </div>
              <span className="text-xs font-bold text-slate-900">{t('reports.selectTimePeriod', 'تحديد الفترة الزمنية للتقرير:')}</span>
            </div>

            {/* Clear Filter / Back to All */}
            {filterPeriod !== 'all' && (
              <button
                type="button"
                onClick={() => setFilterPeriod('all')}
                className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <i className="fa-solid fa-rotate-left text-[10px]"></i>
                <span>{t('reports.viewAll', 'عرض الكل')}</span>
              </button>
            )}
          </div>

          {/* Quick Filter Buttons Grid */}
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5 sm:gap-2">
            {[
              { id: 'today', label: t('reports.today', 'اليوم'), icon: 'fa-calendar-day' },
              { id: 'week', label: t('reports.thisWeek', 'هذا الأسبوع'), icon: 'fa-calendar-week' },
              { id: 'month', label: t('reports.thisMonth', 'هذا الشهر'), icon: 'fa-calendar' },
              { id: 'last_month', label: t('reports.lastMonth', 'الشهر السابق'), icon: 'fa-clock-rotate-left' },
              { id: 'custom', label: t('reports.customPeriod', 'فترة مخصصة'), icon: 'fa-calendar-days' },
              { id: 'all', label: t('reports.allPeriods', 'الكل (العام)'), icon: 'fa-layer-group' },
            ].map((tab) => {
              const isActive = filterPeriod === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setFilterPeriod(tab.id as ReportFilterPeriod)}
                  className={`py-2 px-1.5 sm:px-2.5 rounded-2xl text-xs font-bold flex flex-col sm:flex-row items-center justify-center gap-1 sm:gap-1.5 transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-blue-600 text-white border-blue-600 shadow-sm shadow-blue-500/20'
                      : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200/80 active:bg-slate-200'
                  }`}
                >
                  <i className={`fa-solid ${tab.icon} text-[11px]`}></i>
                  <span className="text-[11px] sm:text-xs truncate">{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Custom Date Range Selectors */}
          {filterPeriod === 'custom' && (
            <div className="pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-2.5 animate-in fade-in duration-200">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {t('reports.fromDateStart', 'من تاريخ (بداية الفترة)')}
                </label>
                <input
                  type="date"
                  value={customStartDate}
                  onChange={(e) => setCustomStartDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  {t('reports.toDateEnd', 'إلى تاريخ (نهاية الفترة)')}
                </label>
                <input
                  type="date"
                  value={customEndDate}
                  onChange={(e) => setCustomEndDate(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 outline-none focus:border-blue-600 focus:bg-white"
                />
              </div>
            </div>
          )}
        </div>

        {/* ---------------------------------------------------- */}
        {/* 3. بطاقات الإحصائيات المالية المحدثة للفترة */}
        {/* ---------------------------------------------------- */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {/* 1. Added Debts in Period */}
          <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-500">{t('reports.addedDebts', 'الديون المضافة')}</span>
              <div className="w-7 h-7 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-xs font-bold">
                <i className="fa-solid fa-arrow-up-right-dots"></i>
              </div>
            </div>
            <div className="font-mono text-base sm:text-xl font-black text-rose-600 tracking-tight">
              {formatNumber(periodAdded, numberFormat)} <span className="text-xs font-bold text-rose-500">{currency}</span>
            </div>
            <div className="text-[10.5px] font-medium text-slate-400 mt-1 flex items-center gap-1">
              <span>{formatNumber(periodAddsCount, numberFormat)} {t('reports.newAdditionOperations', 'عملية إضافة جديدة')}</span>
            </div>
          </div>

          {/* 2. Paid Debts in Period */}
          <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-500">{t('reports.paidAmounts', 'المبالغ المسددة')}</span>
              <div className="w-7 h-7 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xs font-bold">
                <i className="fa-solid fa-arrow-down-left-dots"></i>
              </div>
            </div>
            <div className="font-mono text-base sm:text-xl font-black text-emerald-600 tracking-tight">
              {formatNumber(periodPaid, numberFormat)} <span className="text-xs font-bold text-emerald-500">{currency}</span>
            </div>
            <div className="text-[10.5px] font-medium text-slate-400 mt-1 flex items-center gap-1">
              <span>{formatNumber(periodPaysCount, numberFormat)} {t('reports.collectionPayments', 'دفعة تحصيل')}</span>
            </div>
          </div>

          {/* 3. Net Financial Movement in Period */}
          <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-500">{t('reports.periodNetMovement', 'صافي حركة الفترة')}</span>
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold ${
                  periodNetMovement > 0
                    ? 'bg-emerald-50 text-emerald-600'
                    : periodNetMovement < 0
                    ? 'bg-rose-50 text-rose-600'
                    : 'bg-slate-100 text-slate-600'
                }`}
              >
                <i
                  className={`fa-solid ${
                    periodNetMovement > 0
                      ? 'fa-scale-unbalanced-flip'
                      : periodNetMovement < 0
                      ? 'fa-scale-unbalanced'
                      : 'fa-scale-balanced'
                  }`}
                ></i>
              </div>
            </div>
            <div
              className={`font-mono text-base sm:text-xl font-black tracking-tight ${
                periodNetMovement > 0
                  ? 'text-emerald-600'
                  : periodNetMovement < 0
                  ? 'text-rose-600'
                  : 'text-slate-800'
              }`}
            >
              {periodNetMovement > 0 ? '+' : ''}
              {formatNumber(periodNetMovement, numberFormat)}{' '}
              <span className="text-xs font-bold">{currency}</span>
            </div>
            <div className="text-[10.5px] font-medium text-slate-400 mt-1">
              {periodNetMovement > 0
                ? t('reports.positiveSurplus', 'فائض تحصيل نقدي إيجابي')
                : periodNetMovement < 0
                ? t('reports.debtIncrease', 'زيادة في حجم الديون')
                : t('reports.balancedMovement', 'حركة مالية متوازنة')}
            </div>
          </div>

          {/* 4. Total Active Debts / Interactive Debtors */}
          <div className="bg-white rounded-3xl p-3.5 sm:p-4 border border-slate-200/80 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-500">{t('reports.currentActiveDebts', 'الديون القائمة حالياً')}</span>
              <div className="w-7 h-7 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-xs font-bold">
                <i className="fa-solid fa-wallet"></i>
              </div>
            </div>
            <div className="font-mono text-base sm:text-xl font-black text-slate-900 tracking-tight">
              {formatNumber(currentTotalDebts, numberFormat)} <span className="text-xs font-bold text-slate-500">{currency}</span>
            </div>
            <div className="text-[10.5px] font-medium text-slate-400 mt-1 flex items-center justify-between">
              <span>{t('reports.interactionDebtorsCount', 'تفاعل')} {formatNumber(periodDebtorsInvolved, numberFormat)} {t('reports.debtorSingular', 'مدين')}</span>
              <span>{t('reports.collectionRatio', 'نسبة التحصيل')}: {collectionRateFormatted}%</span>
            </div>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* 4. سجل العمليات المجمع حسب كل مدين (قائمة منسدلة لكل اسم) */}
        {/* ---------------------------------------------------- */}
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
          {/* Header & Controls */}
          <div className="p-4 border-b border-slate-100 space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-xs font-bold">
                  <i className="fa-solid fa-users-viewfinder"></i>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    {t('reports.transactionsLogByDebtors', 'سجل العمليات حسب المدينين')} ({formatNumber(displayedDebtorGroups.length, numberFormat)} {t('reports.debtorSingular', 'مدين')})
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {t('reports.clickDebtorToExpand', 'اضغط على اسم أي مدين لفتح القائمة المنسدلة وعرض تفاصيل كافة عملياته')}
                  </p>
                </div>
              </div>

              {/* Type Filter Pills (All / Add / Pay) & Expand/Collapse All */}
              <div className="flex items-center gap-2 flex-wrap">
                {displayedDebtorGroups.length > 0 && (
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => expandAllDebtors(visibleDebtorIds)}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1"
                      title={t('reports.expandAllTitle', 'فتح كافة القوائم المنسدلة')}
                    >
                      <i className="fa-solid fa-chevron-down text-[9px]"></i>
                      <span>{t('reports.expandAll', 'توسيع الكل')}</span>
                    </button>

                    <button
                      type="button"
                      onClick={collapseAllDebtors}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px] font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1"
                      title={t('reports.collapseAllTitle', 'طي كافة القوائم المنسدلة')}
                    >
                      <i className="fa-solid fa-chevron-up text-[9px]"></i>
                      <span>{t('reports.collapseAll', 'طي الكل')}</span>
                    </button>
                  </div>
                )}

                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setTxTypeFilter('all')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      txTypeFilter === 'all'
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {t('reports.allFilter', 'الكل')}
                  </button>
                  <button
                    type="button"
                    onClick={() => setTxTypeFilter('pay')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      txTypeFilter === 'pay'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-emerald-700 hover:bg-emerald-50'
                    }`}
                  >
                    {t('reports.settlements', 'تسديدات')} ({formatNumber(periodPaysCount, numberFormat)})
                  </button>
                  <button
                    type="button"
                    onClick={() => setTxTypeFilter('add')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      txTypeFilter === 'add'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-rose-700 hover:bg-rose-50'
                    }`}
                  >
                    {t('reports.debts', 'ديون')} ({formatNumber(periodAddsCount, numberFormat)})
                  </button>
                </div>
              </div>
            </div>

            {/* Search Input */}
            <div className="relative">
              <input
                type="text"
                value={txSearchTerm}
                onChange={(e) => setTxSearchTerm(e.target.value)}
                placeholder={t('reports.searchPlaceholder', 'البحث باسم المدين أو الملاحظة أو المبلغ...')}
                className="w-full px-9 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-purple-600 focus:bg-white text-slate-800 transition-all font-medium"
              />
              <div className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none">
                <i className="fa-solid fa-magnifying-glass"></i>
              </div>
              {txSearchTerm && (
                <button
                  type="button"
                  onClick={() => setTxSearchTerm('')}
                  className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs p-1 cursor-pointer"
                >
                  <i className="fa-solid fa-xmark"></i>
                </button>
              )}
            </div>
          </div>

          {/* Debtor Accordion List (كل اسم يظهر مرة واحدة وتنسدل تحته كافة العمليات) */}
          {displayedDebtorGroups.length === 0 ? (
            <div className="text-center py-12 px-4 space-y-2">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-base">
                <i className="fa-solid fa-users-slash"></i>
              </div>
              <div className="text-xs font-bold text-slate-700">
                {t('reports.noMatchingTransactions', 'لا توجد حركات مطابقة في هذه الفترة')}
              </div>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                {txSearchTerm
                  ? t('reports.tryAnotherSearch', 'جرب البحث بكلمة أخرى أو اختيار فترة زمنية مختلفة')
                  : t('reports.noOpsRecordedInPeriod', 'لم تسجل أي عمليات دين أو تسديد في النطاق الزمني المحدد')}
              </p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {displayedDebtorGroups.slice(0, visibleGroupsLimit).map((group) => {
                const isExpanded = expandedDebtorIds.has(group.debtorId);
                const hasTransactions = group.transactions.length > 0;

                return (
                  <div key={group.debtorId} className="transition-colors">
                    {/* Debtor Header Row (Clickable Accordion Trigger) */}
                    <div
                      onClick={() => toggleDebtorExpanded(group.debtorId)}
                      className={`p-3.5 sm:p-4 flex items-center justify-between gap-3 cursor-pointer select-none transition-all ${
                        isExpanded
                          ? 'bg-purple-50/60 hover:bg-purple-50'
                          : 'hover:bg-slate-50/80 active:bg-slate-100'
                      }`}
                    >
                      {/* Debtor Avatar + Name + Phone + Badge */}
                      <div className="flex items-center gap-3 min-w-0">
                        <div
                          className={`w-10 h-10 rounded-2xl flex items-center justify-center text-sm font-black shrink-0 transition-transform ${
                            isExpanded
                              ? 'bg-purple-600 text-white shadow-xs scale-105'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {group.debtorName.charAt(0)}
                        </div>

                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                              {group.debtorName}
                            </span>

                            {/* Badge: Number of Transactions in Period */}
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                hasTransactions
                                  ? 'bg-purple-100 text-purple-800 border border-purple-200/60'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {hasTransactions
                                ? `${formatNumber(group.transactions.length, numberFormat)} ${t('reports.registeredOperations', 'حركات مسجلة')}`
                                : t('reports.noPeriodOperations', 'لا حركات بالفترة')}
                            </span>
                          </div>

                          <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5 flex-wrap">
                            {group.debtorPhone && (
                              <span className="font-mono text-slate-400">
                                {formatDateDigits(group.debtorPhone, numberFormat)}
                              </span>
                            )}
                            <span className="text-slate-400">•</span>
                            <span>
                              {t('reports.outstandingBalance', 'الرصيد القائم')}:{' '}
                              <strong className="text-slate-800 font-mono">
                                {formatNumber(group.currentTotalDebt, numberFormat)} {currency}
                              </strong>
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Summary of Period (Added / Paid) + Accordion Toggle Icon */}
                      <div className="flex items-center gap-3 shrink-0 text-end">
                        {/* Period financial summary for this debtor */}
                        <div className="hidden sm:flex flex-col items-end text-xs font-mono">
                          {group.periodAdded > 0 && (
                            <span className="text-rose-600 font-bold">
                              +{formatNumber(group.periodAdded, numberFormat)} {currency}
                            </span>
                          )}
                          {group.periodPaid > 0 && (
                            <span className="text-emerald-600 font-bold">
                              -{formatNumber(group.periodPaid, numberFormat)} {currency}
                            </span>
                          )}
                          {group.periodAdded === 0 && group.periodPaid === 0 && (
                            <span className="text-slate-400 text-[11px]">0 {currency}</span>
                          )}
                        </div>

                        {/* Chevron Down / Up Indicator */}
                        <div
                          className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all ${
                            isExpanded
                              ? 'bg-purple-200/80 text-purple-800 rotate-180'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          <i className="fa-solid fa-chevron-down text-xs"></i>
                        </div>
                      </div>
                    </div>

                    {/* Dropdown Content: Transactions List for this Debtor */}
                    {isExpanded && (
                      <div className="bg-slate-50/70 border-t border-purple-100/80 px-3 py-2.5 sm:px-6 sm:py-3 space-y-2 animate-in fade-in duration-150">
                        {/* Debtor Quick Mini Summary Bar inside dropdown */}
                        <div className="grid grid-cols-3 gap-2 p-2 bg-white rounded-2xl border border-slate-200/70 text-center">
                          <div className="p-1">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.totalAdditions', 'إجمالي الإضافات')}</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-rose-600">
                              +{formatNumber(group.periodAdded, numberFormat)} {currency}
                            </span>
                          </div>
                          <div className="p-1 border-x border-slate-100">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.totalSettlements', 'إجمالي المسددات')}</span>
                            <span className="text-xs sm:text-sm font-black font-mono text-emerald-600">
                              -{formatNumber(group.periodPaid, numberFormat)} {currency}
                            </span>
                          </div>
                          <div className="p-1">
                            <span className="text-[10px] font-bold text-slate-400 block">{t('reports.debtorNetMovement', 'صافي حركة المدين')}</span>
                            <span
                              className={`text-xs sm:text-sm font-black font-mono ${
                                group.periodNet > 0
                                  ? 'text-emerald-600'
                                  : group.periodNet < 0
                                  ? 'text-rose-600'
                                  : 'text-slate-700'
                              }`}
                            >
                              {group.periodNet > 0 ? '+' : ''}{formatNumber(group.periodNet, numberFormat)} {currency}
                            </span>
                          </div>
                        </div>

                        {/* List of operations */}
                        {group.transactions.length === 0 ? (
                          <div className="p-4 text-center text-xs text-slate-400 bg-white rounded-2xl border border-slate-100">
                            {t('reports.noOpsRecordedForDebtorInPeriod', 'لا توجد عمليات مسجلة لهذا المدين خلال فترة')} ({periodLabel})
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            <div className="text-[11px] font-bold text-slate-500 px-1 pt-1 flex items-center justify-between">
                              <span>{t('reports.opsAndPaymentsList', 'قائمة العمليات والتسديدات')} ({formatNumber(group.transactions.length, numberFormat)}):</span>
                              <span className="text-[10px] text-slate-400">{t('reports.sortedNewestFirst', 'مرتبة من الأحدث إلى الأقدم')}</span>
                            </div>

                            <div className="divide-y divide-slate-100 bg-white rounded-2xl border border-slate-200/80 overflow-hidden">
                              {group.transactions.map((tx, txIdx) => {
                                const isPay = tx.type === 'pay';
                                return (
                                  <div
                                    key={tx.id || `${group.debtorId}_${txIdx}`}
                                    className="p-3 hover:bg-slate-50 transition-colors flex items-center justify-between gap-2"
                                  >
                                    {/* Operation Type Icon & Details */}
                                    <div className="flex items-center gap-2.5 min-w-0">
                                      <div
                                        className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold shrink-0 ${
                                          isPay
                                            ? 'bg-emerald-50 text-emerald-600'
                                            : 'bg-rose-50 text-rose-600'
                                        }`}
                                      >
                                        <i className={`fa-solid ${isPay ? 'fa-arrow-down' : 'fa-arrow-up'}`}></i>
                                      </div>

                                      <div className="min-w-0">
                                        <div className="flex items-center gap-1.5 flex-wrap">
                                          <span
                                            className={`text-[10.5px] font-bold px-1.5 py-0.5 rounded-md ${
                                              isPay
                                                ? 'bg-emerald-50 text-emerald-700'
                                                : 'bg-rose-50 text-rose-700'
                                            }`}
                                          >
                                            {isPay ? t('reports.paySettlement', 'تسديد دفعة') : t('reports.addDebt', 'إضافة دين')}
                                          </span>
                                          <span className="text-[10.5px] text-slate-400 font-mono">
                                            {formatDateDigits(tx.date, numberFormat)}
                                          </span>
                                        </div>

                                        {/* Notes if present */}
                                        {(tx.notes || (tx.description && tx.description !== 'إضافة دين جديد' && tx.description !== 'تسديد دفعة نقدية')) && (
                                          <div className="text-[10.5px] text-slate-600 mt-1 flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-200/50 w-fit">
                                            <i className="fa-solid fa-note-sticky text-amber-500 text-[10px]"></i>
                                            <span className="truncate max-w-[220px] sm:max-w-md">{tx.notes || tx.description}</span>
                                          </div>
                                        )}
                                      </div>
                                    </div>

                                    {/* Amount & Balance After */}
                                    <div className="text-end shrink-0 font-mono">
                                      <div
                                        className={`text-xs sm:text-sm font-black ${
                                          isPay ? 'text-emerald-600' : 'text-rose-600'
                                        }`}
                                      >
                                        {isPay ? '-' : '+'}{formatNumber(tx.amount, numberFormat)}{' '}
                                        <span className="text-[10px] font-bold">{currency}</span>
                                      </div>
                                      <div className="text-[10px] text-slate-400">
                                        {t('reports.balanceAfter', 'الرصيد بعد')}: {formatNumber(tx.balanceAfter, numberFormat)} {currency}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Load More Button if more items exist */}
          {displayedDebtorGroups.length > visibleGroupsLimit && (
            <div className="p-3 bg-slate-50 border-t border-slate-100 text-center">
              <button
                type="button"
                onClick={() => setVisibleGroupsLimit((prev) => prev + 30)}
                className="w-full py-3 bg-white hover:bg-purple-50 text-purple-800 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-2 border border-purple-300 shadow-sm active:scale-[0.98]"
              >
                <i className="fa-solid fa-angles-down text-purple-600 text-xs"></i>
                <span>عرض المزيد من المدينين (+30)</span>
                <span className="text-[10.5px] font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-lg font-mono">
                  متبقي {displayedDebtorGroups.length - visibleGroupsLimit}
                </span>
              </button>
            </div>
          )}

          {/* Table Footer with Summary Count */}
          <div className="p-3 bg-slate-50 border-t border-slate-100 text-xs text-slate-500 flex items-center justify-between">
            <span>{t('reports.totalDisplayedDebtors', 'إجمالي المدينين المعروضين')}: {formatNumber(displayedDebtorGroups.length, numberFormat)}</span>
            <span className="font-mono font-bold text-slate-700">{periodLabel}</span>
          </div>
        </div>

        {/* ---------------------------------------------------- */}
        {/* 5. زر تصفير السجل التراكمي إذا رغب المستخدم */}
        {/* ---------------------------------------------------- */}
        {onResetStats && (
          <div className="pt-2">
            <button
              type="button"
              onClick={onResetStats}
              className="w-full bg-slate-100 hover:bg-slate-200 active:scale-[0.99] text-slate-600 py-3 rounded-2xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer border border-slate-200/80"
            >
              <i className="fa-solid fa-arrows-rotate text-xs text-slate-500"></i>
              <span>{t('reports.resetCumulativeStats', 'تصفير سجل التقارير والإحصائيات التراكمية')}</span>
            </button>
          </div>
        )}
        </>
        )}
      </div>
    </div>
  );
});

ReportsTab.displayName = 'ReportsTab';

