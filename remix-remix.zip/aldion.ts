// =====================================================================================
// 🔐 ملف إعدادات قاعدة البيانات السحابية (Turso) المحمي بنظام التشفير العسكري
// =====================================================================================
// يمكنك تعديل التوكن والرابط بطريقتين:
// الطريقة 1 (يدوية سريعة): وضع الرابط والتوكن بنص صريح بداخل الخانات التالية MANUAL_OVERRIDE
// الطريقة 2 (أقصى حماية): ترك الخانات المباشرة فارغة ليقوم الملف بفك التشفير تلقائياً من المصفوفتين
// =====================================================================================

// ✏️ إذا أردت تعديل الرابط والتوكن يدوياً وبشكل مباشر قبل عمل APK ضع القيم هنا:
export const MANUAL_OVERRIDE_TURSO_URL: string = "";    // مثال: "https://my-database.turso.io"
export const MANUAL_OVERRIDE_TURSO_TOKEN: string = "";  // مثال: "eyJhbGciOiJIUzI1NiIsInR5cCI6..."

// -------------------------------------------------------------------------------------
// 🛡️ التشفير العسكري التلقائي (المشفر بمصفوفة بايتات ومفتاح XOR دوار لمنع الهندسة العكسية)
// -------------------------------------------------------------------------------------
const _CIPHER_TOKEN_BYTES: number[] = [
  254,51,166,103,9,88,188,222,94,247,104,211,149,83,210,39,86,24,194,112,236,92,172,76,80,161,29,145,250,156,87,7,159,5,192,20,73,43,145,65,7,106,185,196,116,249,72,242,162,86,255,53,107,22,215,86,200,97,152,0,12,169,20,200,206,182,111,26,192,15,218,108,16,251,137,123,8,110,189,192,112,219,30,219,191,83,252,16,46,29,233,162,217,103,196,12,76,167,31,159,248,177,107,17,153,50,213,112,21,251,183,74,19,102,188,230,54,200,26,208,231,79,240,30,106,24,192,177,195,111,131,58,110,143,122,199,164,202,89,36,148,40,195,107,44,219,91,73,72,77,186,207,55,195,4,179,239,72,220,43,92,9,171,190,103,67,171,49,70,134,41,199,148,201,96,118,148,21,192,103,17,223,78,86,5,100,136,162,70,220,0,167,162,91,193,118,104,60,230,190,34,151,140,31,127,140,3,250,241,194,33,22,212,63,234,108,66,236,121,182,66,123,179,218,56,223,30,188,211,64,236,14,28,45,234,218,52,151,156,20,115,150,40,234,234,194,27,32,209,35,200,105,18,252,68,135,31,117,184,217,12,172,42,168,236,35,242,29,119,29,225,151,11,160,74,21,90,149,9,242,142,171,11,120,167,43,207,118,75,199,90,176,205,121,136,174,121,139,8,150,252,52,149,43,112,91,233,129,117,150,43,1,119,154,60,177,234,211,19,80,167,75,245,62,21,235,105,216,228,168,194,231,12,208,33,176,194,31,175,52,99,21,154,170,32,253,86,210
];
const _CIPHER_TOKEN_KEY: number[] = [155, 77, 226, 26, 119, 60, 245, 134, 41, 161, 100, 216];

const _CIPHER_URL_BYTES: number[] = [
  63,217,115,234,47,209,113,180,34,138,121,158,34,184,78,197,60,188,39,51,190,87,247,76,157,88,182,32,201,42,172,29,139,10,222,69,252,222,76,232,42,216,20,210,25,208,87,139,72,178,35,166,6,141,75,112,199,76,204
];
const _CIPHER_URL_KEY: number[] = [83, 183, 31, 140, 66, 158, 97, 170, 53, 212];

function _decodeBytes(bytes: number[], key: number[]): string {
  let result = '';
  for (let i = 0; i < bytes.length; i++) {
    const orig = (bytes[i] ^ key[i % key.length] ^ ((i * 7) & 0xFF)) & 0xFF;
    result += String.fromCharCode(orig);
  }
  return result;
}

export function normalizeTursoUrl(rawUrl: string): string {
  if (!rawUrl) return "";
  let clean = rawUrl.trim();
  if (clean.startsWith("libsql://")) {
    clean = "https://" + clean.slice("libsql://".length);
  } else if (!clean.startsWith("http://") && !clean.startsWith("https://")) {
    clean = "https://" + clean;
  }
  clean = clean.replace(/\/+$/, "");
  if (!clean.endsWith("/v2/pipeline")) {
    clean = clean + "/v2/pipeline";
  }
  return clean;
}

const _decodedUrl = _decodeBytes(_CIPHER_URL_BYTES, _CIPHER_URL_KEY);
const _decodedToken = _decodeBytes(_CIPHER_TOKEN_BYTES, _CIPHER_TOKEN_KEY);

const _finalRawUrl = MANUAL_OVERRIDE_TURSO_URL && MANUAL_OVERRIDE_TURSO_URL.trim()
  ? MANUAL_OVERRIDE_TURSO_URL.trim()
  : _decodedUrl;

const _finalToken = MANUAL_OVERRIDE_TURSO_TOKEN && MANUAL_OVERRIDE_TURSO_TOKEN.trim()
  ? MANUAL_OVERRIDE_TURSO_TOKEN.trim()
  : _decodedToken;

export const ALDION_DATABASE_CONFIG = {
  // رابط قاعدة البيانات السحابية الأساسية
  url: normalizeTursoUrl(_finalRawUrl),
  rawUrl: _finalRawUrl,

  // الرمز السري للاتصال
  token: _finalToken,
};

export const SECONDARY_DATABASE_CONFIG = {
  // رابط قاعدة البيانات السحابية الثانوية المستقلة (Failover & Replication)
  url: normalizeTursoUrl("libsql://aldin-albasrawia2026.aws-ap-south-1.turso.io"),
  rawUrl: "libsql://aldin-albasrawia2026.aws-ap-south-1.turso.io",
  token: "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3OTAxNjI5ODgsImlkIjoiMDFhMGNlMDctMDIwMS03ZTdmLTlhNTQtMTA2NzRhNDVmZjI3Iiwia2lkIjoiQkxmRmNZbUs2YmhFMUIzaFBQLUFwb1BodVloaXczU1dYZXdLUjRvN0t0ZyIsInJpZCI6IjQ5YWVkZDU4LTgxYjAtNDc4Zi1iYjFkLWM3MjYyMDM0NGUyNCJ9.i_OKfJWt35_DvinmHnCqmHGL1B7PicsuLxajyWR4OkN8oM8DgHN2ETQI9OihAe0sHMSoLR2yjNsSLJuzHTH_DQ",
};
