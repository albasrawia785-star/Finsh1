import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react';
import arTranslations from '../locales/ar.json';
import enTranslations from '../locales/en.json';
import kuTranslations from '../locales/ku.json';
import { formatNumber, toArabicDigits, toEnglishDigits } from '../utils/formatters';

export type Language = 'ar' | 'ku';
export type Currency = 'IQD';
export type NumberFormat = 'english' | 'arabic';

const translations: Record<string, any> = {
  ar: arTranslations,
  en: enTranslations,
  ku: kuTranslations,
};

interface I18nContextType {
  language: Language;
  currency: Currency;
  numberFormat: NumberFormat;
  dir: 'rtl' | 'ltr';
  setLanguage: (lang: Language) => void;
  setCurrency: (curr: Currency) => void;
  setNumberFormat: (fmt: NumberFormat) => void;
  t: (keyPath: string, fallback?: string, params?: Record<string, string | number>) => string;
  formatMoney: (amount: number | string | null | undefined) => string;
  getCurrencySymbol: () => string;
}

const I18nContext = createContext<I18nContextType | null>(null);

const STORAGE_LANG_KEY = 'dftr_app_language';
const STORAGE_CURR_KEY = 'dftr_app_currency';
const STORAGE_NUMF_KEY = 'dftr_app_number_format';

export function getStoredLanguage(): Language {
  const stored = localStorage.getItem(STORAGE_LANG_KEY);
  if (stored === 'ku' || stored === 'ar') {
    return stored;
  }
  return 'ar';
}

export function getStoredCurrency(): Currency {
  return 'IQD';
}

export function getStoredNumberFormat(): NumberFormat {
  const stored = localStorage.getItem(STORAGE_NUMF_KEY);
  if (stored === 'arabic' || stored === 'english') {
    return stored;
  }
  return 'arabic';
}

export const I18nProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(getStoredLanguage);
  const [currency, setCurrencyState] = useState<Currency>(getStoredCurrency);
  const [numberFormat, setNumberFormatState] = useState<NumberFormat>(getStoredNumberFormat);

  const dir: 'rtl' | 'ltr' = 'rtl';

  useEffect(() => {
    document.documentElement.dir = dir;
    document.documentElement.lang = language;
    document.body.dir = dir;
  }, [language, dir]);

  const setLanguage = useCallback((newLang: Language) => {
    const validLang: Language = newLang === 'ku' ? 'ku' : 'ar';
    setLanguageState(validLang);
    localStorage.setItem(STORAGE_LANG_KEY, validLang);
  }, []);

  const setCurrency = useCallback((_newCurr: Currency) => {
    setCurrencyState('IQD');
    localStorage.setItem(STORAGE_CURR_KEY, 'IQD');
  }, []);

  const setNumberFormat = useCallback((newFmt: NumberFormat) => {
    setNumberFormatState(newFmt);
    localStorage.setItem(STORAGE_NUMF_KEY, newFmt);
  }, []);

  const t = useCallback(
    (keyPath: string, fallback?: string, params?: Record<string, string | number>): string => {
      const keys = keyPath.split('.');
      let current: any = translations[language];

      for (const k of keys) {
        if (current && typeof current === 'object' && k in current) {
          current = current[k];
        } else {
          current = undefined;
          break;
        }
      }

      // Fallback to Arabic if not found in current language
      if (current === undefined && language !== 'ar') {
        let arCurrent: any = translations['ar'];
        for (const k of keys) {
          if (arCurrent && typeof arCurrent === 'object' && k in arCurrent) {
            arCurrent = arCurrent[k];
          } else {
            arCurrent = undefined;
            break;
          }
        }
        current = arCurrent;
      }

      let result = current !== undefined ? String(current) : fallback || keyPath;

      if (params) {
        Object.entries(params).forEach(([paramKey, paramVal]) => {
          result = result.replace(new RegExp(`{${paramKey}}`, 'g'), String(paramVal));
        });
      }

      return result;
    },
    [language]
  );

  const getCurrencySymbol = useCallback((): string => {
    if (language === 'ku') {
      return 'دینار';
    }
    return 'د.ع';
  }, [language]);

  const formatMoney = useCallback(
    (amount: number | string | null | undefined): string => {
      const numFormatted = formatNumber(amount, numberFormat);
      const symbol = getCurrencySymbol();
      return `${numFormatted} ${symbol}`;
    },
    [numberFormat, getCurrencySymbol]
  );

  return (
    <I18nContext.Provider
      value={{
        language,
        currency,
        numberFormat,
        dir,
        setLanguage,
        setCurrency,
        setNumberFormat,
        t,
        formatMoney,
        getCurrencySymbol,
      }}
    >
      <div dir={dir} className={dir === 'rtl' ? 'font-sans' : 'font-sans'}>
        {children}
      </div>
    </I18nContext.Provider>
  );
};

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider');
  }
  return context;
}
