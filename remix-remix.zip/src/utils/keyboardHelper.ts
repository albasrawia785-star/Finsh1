import React, { useEffect } from 'react';

/**
 * Handles smooth auto-scrolling of focused input elements on mobile devices
 * when the soft keyboard expands, keeping the active field in the middle of the viewport.
 * Uses passive/RAF pattern to prevent blocking input keystrokes or UI thread lag.
 */
export const handleInputFocus = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
  const target = e.currentTarget;
  // Delay slightly to let the soft keyboard animation complete on iOS/Android
  setTimeout(() => {
    if (target && document.activeElement === target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, 220);
};

/**
 * React hook that listens to visualViewport resize events (triggered by soft keyboard)
 * and ensures active input fields remain visible above the keyboard with debounce/RAF.
 */
export const useModalKeyboardAdjust = (isOpen: boolean) => {
  useEffect(() => {
    if (!isOpen) return;

    let rafId: number | null = null;

    const handleViewportResize = () => {
      if (rafId !== null) cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(() => {
        const activeEl = document.activeElement;
        if (activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA')) {
          (activeEl as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    };

    const vv = window.visualViewport;
    if (vv) {
      vv.addEventListener('resize', handleViewportResize, { passive: true });
      return () => {
        if (rafId !== null) cancelAnimationFrame(rafId);
        vv.removeEventListener('resize', handleViewportResize);
      };
    }
  }, [isOpen]);
};
