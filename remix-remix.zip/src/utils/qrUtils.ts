import { getBackendBaseUrl } from '../services/turso';

export type PortalType = 'debtor' | 'installment';

export interface PortalParams {
  type: PortalType;
  id: number;
}

/**
 * Returns the permanent live portal URL for a debtor or installment
 */
export function getPortalUrl(type: PortalType, id: number): string {
  const TARGET_DOMAIN = 'https://aldion2-dafterappp.netlify.app';

  if (typeof window !== 'undefined') {
    if (window.location.origin && window.location.origin.startsWith('http') && !window.location.origin.includes('run.app')) {
      return `${window.location.origin.replace(/\/+$/, '')}/?portal=${type}&id=${id}`;
    }
  }

  return `${TARGET_DOMAIN}/?portal=${type}&id=${id}`;
}

/**
 * Parses query parameters or barcode scan strings to check if opened in Customer Portal mode.
 * Guarantees that links/barcodes containing `portal=debtor` or `portal=installment` bypass
 * the manager LoginOverlay and directly open the CustomerPortalView.
 */
export function parsePortalParams(search?: string): PortalParams | null {
  if (typeof window === 'undefined') return null;

  const rawInput = search || '';
  const searchStr = window.location.search || '';
  const hashStr = window.location.hash || '';
  const fullUrl = window.location.href || '';

  // Helper to parse from a query/search string or fragment
  const parseFromQuery = (str: string): PortalParams | null => {
    if (!str || typeof str !== 'string') return null;

    let cleanStr = str.trim();
    if (cleanStr.includes('?')) {
      cleanStr = cleanStr.substring(cleanStr.indexOf('?'));
    } else if (!cleanStr.startsWith('?')) {
      cleanStr = '?' + cleanStr;
    }

    let params: URLSearchParams;
    try {
      params = new URLSearchParams(cleanStr);
    } catch {
      return null;
    }

    const portalParam = params.get('portal');
    const qrParam = params.get('qr');
    const idParam = params.get('id') || params.get('debtor_id') || params.get('inst_id') || params.get('debtorId');

    // 1. Check for portal=debtor or portal=installment
    if (portalParam) {
      const lowerPortal = portalParam.toLowerCase();
      let portalType: PortalType | null = null;
      if (lowerPortal.includes('debtor')) portalType = 'debtor';
      else if (lowerPortal.includes('installment') || lowerPortal.includes('inst')) portalType = 'installment';

      if (portalType) {
        if (idParam) {
          const numId = parseInt(idParam, 10);
          if (!isNaN(numId) && numId > 0) {
            return { type: portalType, id: numId };
          }
        }
        // Check if ID is embedded inside portalParam e.g. portal=debtor_1789490781310
        const embeddedIdMatch = lowerPortal.match(/(\d+)/);
        if (embeddedIdMatch) {
          const numId = parseInt(embeddedIdMatch[1], 10);
          if (!isNaN(numId) && numId > 0) {
            return { type: portalType, id: numId };
          }
        }
        // Check if any number exists in the query string
        const matchAnyNum = cleanStr.match(/(\d{5,})/);
        if (matchAnyNum) {
          const numId = parseInt(matchAnyNum[1], 10);
          if (!isNaN(numId) && numId > 0) {
            return { type: portalType, id: numId };
          }
        }
        // If portal=debtor or portal=installment is present, return with id (or 0 fallback) to bypass LoginOverlay
        return { type: portalType, id: 0 };
      }
    }

    // 2. Check for qr=debtor_123 or qr=inst_123
    if (qrParam) {
      const lowerQr = qrParam.toLowerCase();
      if (lowerQr.includes('debtor')) {
        const numMatch = lowerQr.match(/(\d+)/);
        const numId = numMatch ? parseInt(numMatch[1], 10) : 0;
        return { type: 'debtor', id: isNaN(numId) ? 0 : numId };
      }
      if (lowerQr.includes('installment') || lowerQr.includes('inst')) {
        const numMatch = lowerQr.match(/(\d+)/);
        const numId = numMatch ? parseInt(numMatch[1], 10) : 0;
        return { type: 'installment', id: isNaN(numId) ? 0 : numId };
      }
    }

    return null;
  };

  // A. Try parsing explicitly passed search string
  if (rawInput) {
    const res = parseFromQuery(rawInput);
    if (res) return res;
  }

  // B. Try parsing window.location.search
  if (searchStr) {
    const res = parseFromQuery(searchStr);
    if (res) return res;
  }

  // C. Try parsing window.location.hash
  if (hashStr) {
    const res = parseFromQuery(hashStr);
    if (res) return res;
  }

  // D. Fallback regex checks on full URL and combined input
  const combinedUrl = `${fullUrl} ${rawInput}`;
  if (combinedUrl.includes('portal=debtor') || combinedUrl.includes('portal=installment')) {
    const isDebtor = combinedUrl.includes('portal=debtor');
    const type: PortalType = isDebtor ? 'debtor' : 'installment';
    const matchId = combinedUrl.match(/(?:id|debtor_id|inst_id)=(\d+)/) || combinedUrl.match(/(\d{5,})/);
    const numId = matchId ? parseInt(matchId[1], 10) : 0;
    return { type, id: numId };
  }

  if (combinedUrl.includes('debtor_')) {
    const match = combinedUrl.match(/debtor_(\d+)/);
    if (match) {
      const numId = parseInt(match[1], 10);
      return { type: 'debtor', id: isNaN(numId) ? 0 : numId };
    }
  }

  if (combinedUrl.includes('inst_') || combinedUrl.includes('installment_')) {
    const match = combinedUrl.match(/(?:inst_|installment_)(\d+)/);
    if (match) {
      const numId = parseInt(match[1], 10);
      return { type: 'installment', id: isNaN(numId) ? 0 : numId };
    }
  }

  return null;
}

/**
 * Generates formatted WhatsApp share message
 */
export function generateWhatsAppMessage(
  type: PortalType,
  name: string,
  totalAmount: number,
  remainingAmount: number,
  portalUrl: string,
  currency: string = 'د.ع'
): string {
  const isInst = type === 'installment';
  const typeTitle = isInst ? 'عقد القسط' : 'حساب الدين المباشر';
  
  const text = `مرحباً ${name} 👋\n` +
    `نود إعلامكم بتحديث كشف حسابكم الخاص بـ (${typeTitle}):\n\n` +
    `💰 إجمالي المبلغ: ${totalAmount.toLocaleString('ar-IQ')} ${currency}\n` +
    `🔴 الملاحظة/المتبقي حالياً: ${remainingAmount.toLocaleString('ar-IQ')} ${currency}\n\n` +
    `📱 يمكنك متابعة وتحديث كشف حسابك المباشر في أي وقت بالضغط على الرابط الثابت التالي:\n` +
    `${portalUrl}\n\n` +
    `شكراً لتعاملكم معنا 🙏`;
    
  return encodeURIComponent(text);
}
