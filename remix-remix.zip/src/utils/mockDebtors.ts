import { Debtor, DebtorTransaction } from '../types';

const FIRST_NAMES = [
  'محمد', 'أحمد', 'علي', 'حسين', 'كرار', 'عباس', 'مصطفى', 'يوسف', 'عمر', 'حسن',
  'حيدر', 'سجاد', 'مهدي', 'مرتضى', 'إبراهيم', 'زيد', 'سيف', 'عمار', 'جعفر', 'بلال',
  'بشير', 'خالد', 'طه', 'أمير', 'ضرغام', 'وسام', 'حمزة', 'قاسم', 'فاضل', 'صادق'
];

const FATHER_NAMES = [
  'علي', 'حسن', 'حسين', 'كاظم', 'جاسم', 'كريم', 'شاكر', 'هادي', 'جواد', 'صادق',
  'نعمة', 'عبدالله', 'فاضل', 'سلمان', 'حميد', 'طاهر', 'ماجد', 'رحيم', 'ناظم', 'محسن'
];

const FAMILY_NAMES = [
  'الشمري', 'الساعدي', 'الجبوري', 'الخفاجي', 'البصراوي', 'المالكي', 'الكعبي', 'العامري',
  'التميمي', 'الزبيدي', 'المحمداوي', 'الحسناوي', 'العتابي', 'السعدي', 'الدراجي', 'الموسوي',
  'العكيلي', 'الفرطوسي', 'اللامي', 'الوائلي', 'الجنابي', 'العبيدي', 'المعموري', 'الصالحي'
];

// 100 uniquely diverse and realistic Iraqi Dinar amounts summing up to exactly 1,300,000 IQD (مليون وثلاثمائة)
const DIVERSE_AMOUNTS_100: number[] = [
  // Group 1 (Sum = 60,000)
  0, 2250, 3500, 4750, 5000, 6250, 7500, 8750, 10000, 12000,
  // Group 2 (Sum = 70,000)
  2500, 3750, 4500, 5500, 6500, 7750, 8500, 9500, 10500, 11000,
  // Group 3 (Sum = 75,000)
  0, 4250, 5250, 6750, 7250, 8250, 9250, 10250, 11750, 12000,
  // Group 4 (Sum = 90,000)
  3250, 5750, 6000, 7000, 8000, 9000, 11500, 12500, 13000, 14000,
  // Group 5 (Sum = 105,000)
  0, 6250, 7500, 8500, 9750, 11000, 12500, 14500, 15000, 20000,
  // Group 6 (Sum = 145,000)
  7250, 8750, 10000, 11250, 13500, 15500, 16750, 18000, 21000, 23000,
  // Group 7 (Sum = 155,000)
  0, 9250, 10500, 12000, 14000, 16000, 18500, 22000, 25750, 27000,
  // Group 8 (Sum = 200,000)
  8500, 10750, 12750, 15000, 17500, 20500, 24000, 27500, 31000, 32500,
  // Group 9 (Sum = 210,000)
  0, 11500, 13750, 16500, 19500, 22500, 26500, 30500, 34250, 35000,
  // Group 10 (Sum = 190,000)
  10000, 12500, 15000, 16000, 18000, 21000, 23500, 24000, 25000, 25000
];

/**
 * Helper to identify whether a debtor is a demo record.
 * Checks the isDemo flag, negative ID, masked demo phone ('077********' or containing '*'), or demo marker.
 */
export function isDemoDebtor(d: Debtor | null | undefined): boolean {
  if (!d) return false;
  if (d.isDemo === true) return true;
  if (typeof d.id === 'number' && d.id < 0) return true;
  if (typeof d.phone === 'string' && (d.phone.includes('*') || d.phone.includes('X') || d.phone === '077********')) return true;
  if (typeof d.name === 'string' && (d.name.includes('(تجريبي)') || d.name.includes('تجريبي'))) return true;
  return false;
}

/**
 * Generates 100 realistic Iraqi demo debtors for testing purposes.
 * These are marked with isDemo: true and must NOT be saved to Turso cloud database.
 * Phone numbers are masked as '077********' because they are demo accounts.
 * Exactly 4 demo debtors are configured as overdue (متأخر) according to user requirement.
 */
export function generate100DemoDebtors(userId: number, highDebtThreshold: number = 25000): Debtor[] {
  const debtors: Debtor[] = [];
  const now = Date.now();

  // Exactly 4 demo debtors configured to be overdue
  const OVERDUE_INDICES = new Set([1, 9, 33, 77]);

  for (let i = 0; i < 100; i++) {
    const fName = FIRST_NAMES[i % FIRST_NAMES.length];
    const mName = FATHER_NAMES[(i * 3) % FATHER_NAMES.length];
    const lName = FAMILY_NAMES[(i * 7) % FAMILY_NAMES.length];
    const fullName = `${fName} ${mName} ${lName}`;

    // Masked demo phone: 077 followed by 8 asterisks (077********) so no real number is exposed
    const phone = '077********';

    // Truly varied amounts across different ranges summing to 1,300,000
    const amount = DIVERSE_AMOUNTS_100[i] ?? 13000;
    const isHigh = amount >= highDebtThreshold;
    const isOverdue = OVERDUE_INDICES.has(i);

    // If among the 4 designated overdue debtors, assign status 'متأخر' (or 'دين مرتفع') and past date (40 days ago)
    const status = amount === 0
      ? 'خالي من الدين'
      : isOverdue
      ? 'متأخر'
      : isHigh
      ? 'دين مرتفع'
      : 'دين عادي';

    // Exactly 4 overdue debtors are set to 40 days ago; all others are set to today (0 days ago)
    const daysAgo = isOverdue ? 40 : 0;
    const dateObj = new Date(now - daysAgo * 24 * 60 * 60 * 1000);
    const dateStr = dateObj.toISOString();

    const debtorId = -1000 - i; // Negative IDs clearly denote local demo records

    const tx: DebtorTransaction = {
      id: `demo-tx-${i}-${now}`,
      debtorId,
      type: 'initial',
      amount,
      balanceAfter: amount,
      date: dateStr,
      description: amount > 0 ? 'دين أولي تجريبي (للاختبار)' : 'تسجيل حساب تجريبي خالي من الدين',
    };

    debtors.push({
      id: debtorId,
      name: fullName,
      phone,
      amount,
      status,
      userId,
      createdAt: dateStr,
      lastDebtDate: dateStr,
      history: [tx],
      isDemo: true,
    });
  }

  return debtors;
}

const ITEMS_LIST = [
  'آيفون 16 برو ماكس (256GB)',
  'شاشة سامسونج 65 بوصة 4K',
  'غسالة إل جي 10.5 كغم أوتوماتيك',
  'مكيف سبليت جنرال 2 طن إنفيرتر',
  'لابتوب ديل كور i7 الجيل 13',
  'بلايستيشن 5 سليم مع يدتين',
  'طباخ غازي بيكو 5 عيون إيطالي',
  'ثلاجة بيكو 22 قدم نوفروست',
  'أونصة ذهب عيار 21 سويسري',
  'سامسونج جالاكسي S24 ألترا',
  'تلفزيون سوني 55 بوصة OLED',
  'غرفة نوم تركية ملكية كاملة',
  'دراجة نارية ماجيك 125cc',
  'سخان ماء مركزي تيتانيوم',
  'مفرمة ومحضر طعام كينوود أصلي',
  'آيباد برو 11 إنش M4 الجديد',
  'مفرش وطقم قنفات تركي 7 مقاعد',
  'مولدة ديزل صامتة 8.5 KVA',
  'كاميرا كانون EOS R6 مارك 2',
  'ساعة أبل ألترا 2 تيتانيوم'
];

// Realistic total amounts and down payments for 20 installments:
// remainingAmount sums up to exactly 17,000,000 IQD
const INSTALLMENTS_AMOUNTS_20 = [
  { total: 1800000, down: 300000, remaining: 1500000, monthly: 150000 }, // 1.5M
  { total: 1400000, down: 200000, remaining: 1200000, monthly: 120000 }, // 1.2M
  { total: 1150000, down: 150000, remaining: 1000000, monthly: 100000 }, // 1.0M
  { total: 1250000, down: 250000, remaining: 1000000, monthly: 100000 }, // 1.0M
  { total: 1050000, down: 150000, remaining: 900000,  monthly: 90000  }, // 0.9M
  { total: 1100000, down: 200000, remaining: 900000,  monthly: 90000  }, // 0.9M
  { total: 1000000, down: 200000, remaining: 800000,  monthly: 80000  }, // 0.8M
  { total: 950000,  down: 150000, remaining: 800000,  monthly: 80000  }, // 0.8M
  { total: 1000000, down: 250000, remaining: 750000,  monthly: 75000  }, // 0.75M
  { total: 950000,  down: 200000, remaining: 750000,  monthly: 75000  }, // 0.75M
  { total: 900000,  down: 200000, remaining: 700000,  monthly: 70000  }, // 0.7M
  { total: 850000,  down: 150000, remaining: 700000,  monthly: 70000  }, // 0.7M
  { total: 1200000, down: 500000, remaining: 700000,  monthly: 70000  }, // 0.7M
  { total: 800000,  down: 150000, remaining: 650000,  monthly: 65000  }, // 0.65M
  { total: 750000,  down: 100000, remaining: 650000,  monthly: 65000  }, // 0.65M
  { total: 800000,  down: 200000, remaining: 600000,  monthly: 60000  }, // 0.6M
  { total: 700000,  down: 100000, remaining: 600000,  monthly: 60000  }, // 0.6M
  { total: 650000,  down: 100000, remaining: 550000,  monthly: 55000  }, // 0.55M
  { total: 750000,  down: 200000, remaining: 550000,  monthly: 55000  }, // 0.55M
  { total: 800000,  down: 100000, remaining: 700000,  monthly: 70000  }, // 0.7M
  // Total sum of remaining amounts: 17,000,000 IQD exactly
];

/**
 * Helper to identify whether an installment is a demo record.
 */
export function isDemoInstallment(inst: any): boolean {
  if (!inst) return false;
  if (inst.isDemo === true) return true;
  if (typeof inst.id === 'number' && inst.id < 0) return true;
  if (typeof inst.phone === 'string' && (inst.phone.includes('*') || inst.phone.includes('X') || inst.phone === '077********')) return true;
  if (typeof inst.name === 'string' && (inst.name.includes('(تجريبي)') || inst.name.includes('تجريبي'))) return true;
  return false;
}

/**
 * Generates 20 realistic Iraqi demo installment records.
 * Sum of remainingAmount equals exactly 17,000,000 IQD (17 مليون).
 */
export function generate20DemoInstallments(userId: number): import('../types').InstallmentRecord[] {
  const installments: import('../types').InstallmentRecord[] = [];
  const now = new Date();

  // Pick a variety of past registration dates within the last 1-4 months
  for (let i = 0; i < 20; i++) {
    const fName = FIRST_NAMES[(i * 2) % FIRST_NAMES.length];
    const mName = FATHER_NAMES[(i * 4 + 1) % FATHER_NAMES.length];
    const lName = FAMILY_NAMES[(i * 3 + 2) % FAMILY_NAMES.length];
    const fullName = `${fName} ${mName} ${lName}`;

    const config = INSTALLMENTS_AMOUNTS_20[i];
    const item = ITEMS_LIST[i % ITEMS_LIST.length];
    const phone = '077********';

    // Dates
    const regDateObj = new Date(now.getTime() - ((i + 1) * 3) * 24 * 60 * 60 * 1000);
    const regDateStr = regDateObj.toISOString().split('T')[0];

    // Due date (some active, some due, some overdue)
    let nextDueDateObj = new Date(now.getTime() + (10 - (i % 15)) * 24 * 60 * 60 * 1000);
    const nextDueDateStr = nextDueDateObj.toISOString().split('T')[0];

    let status: import('../types').InstallmentStatus = 'active';
    const diffDays = Math.round((nextDueDateObj.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays < 0) {
      status = 'overdue';
    } else if (diffDays <= 3) {
      status = 'due';
    } else {
      status = 'active';
    }

    const installmentId = -5000 - i; // Negative IDs denote local demo records

    installments.push({
      id: installmentId,
      name: fullName,
      phone,
      item,
      totalAmount: config.total,
      downPayment: config.down,
      remainingAmount: config.remaining,
      monthlyInstallmentAmount: config.monthly,
      registrationDate: regDateStr,
      nextDueDate: nextDueDateStr,
      userId,
      status,
      guarantorEnabled: i % 2 === 0,
      guarantorName: i % 2 === 0 ? `علي ${FATHER_NAMES[(i + 5) % FATHER_NAMES.length]} ${FAMILY_NAMES[(i + 4) % FAMILY_NAMES.length]}` : undefined,
      guarantorPhone: i % 2 === 0 ? '077********' : undefined,
      guarantorRelation: i % 2 === 0 ? (i % 4 === 0 ? 'شقيق' : 'صديق مقرب') : undefined,
      guarantorJob: i % 2 === 0 ? 'موظف حكومي' : undefined,
      guarantorAddress: i % 2 === 0 ? 'بغداد - الكرادة' : undefined,
      address: 'العراق - بغداد',
      notes: 'عقد قسط تجريبي للاختبار (محلي)',
      payments: [],
      createdAt: regDateObj.toISOString(),
      isDemo: true,
    });
  }

  return installments;
}

/**
 * Generates 10,000 (10 آلاف) realistic Iraqi demo debtors for scale and performance testing.
 * These are marked with isDemo: true and negative IDs so they are NEVER uploaded or saved to the cloud/server.
 */
export function generateMillionDemoDebtors(userId: number, count: number = 10000, highDebtThreshold: number = 25000): Debtor[] {
  return generate10kDemoDebtors(userId, count, highDebtThreshold);
}

export function generate10kDemoDebtors(userId: number, count: number = 10000, highDebtThreshold: number = 25000): Debtor[] {
  const debtors: Debtor[] = new Array(count);
  const now = Date.now();
  const dateStr = new Date(now).toISOString();
  const overdueDateStr = new Date(now - 40 * 24 * 60 * 60 * 1000).toISOString();

  const fnLen = FIRST_NAMES.length;
  const mnLen = FATHER_NAMES.length;
  const lnLen = FAMILY_NAMES.length;
  const amountsLen = DIVERSE_AMOUNTS_100.length;

  for (let i = 0; i < count; i++) {
    const fName = FIRST_NAMES[i % fnLen];
    const mName = FATHER_NAMES[(i * 3) % mnLen];
    const lName = FAMILY_NAMES[(i * 7) % lnLen];
    const fullName = `${fName} ${mName} ${lName} (#${i + 1})`;

    const amount = DIVERSE_AMOUNTS_100[i % amountsLen];
    const isHigh = amount >= highDebtThreshold;
    const isOverdue = (i % 25 === 0 && amount > 0);

    const status = amount === 0
      ? 'خالي من الدين'
      : isOverdue
      ? 'متأخر'
      : isHigh
      ? 'دين مرتفع'
      : 'دين عادي';

    const createdAt = isOverdue ? overdueDateStr : dateStr;

    debtors[i] = {
      id: -1000000 - i,
      name: fullName,
      phone: '077********',
      amount,
      status,
      userId,
      createdAt,
      lastDebtDate: createdAt,
      isDemo: true,
    };
  }

  return debtors;
}

/**
 * Generates up to 10,000 realistic demo installments for scale testing.
 */
export function generate10kDemoInstallments(userId: number, count: number = 10000): import('../types').InstallmentRecord[] {
  const installments: import('../types').InstallmentRecord[] = new Array(count);
  const now = new Date();
  const regDateStr = now.toISOString().split('T')[0];
  const nextDueDateStr = new Date(now.getTime() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  const overdueDateStr = new Date(now.getTime() - 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const fnLen = FIRST_NAMES.length;
  const mnLen = FATHER_NAMES.length;
  const lnLen = FAMILY_NAMES.length;
  const itemsLen = ITEMS_LIST.length;
  const amountsLen = INSTALLMENTS_AMOUNTS_20.length;

  for (let i = 0; i < count; i++) {
    const fName = FIRST_NAMES[(i * 2) % fnLen];
    const mName = FATHER_NAMES[(i * 4 + 1) % mnLen];
    const lName = FAMILY_NAMES[(i * 3 + 2) % lnLen];
    const fullName = `${fName} ${mName} ${lName} (#${i + 1})`;

    const config = INSTALLMENTS_AMOUNTS_20[i % amountsLen];
    const item = ITEMS_LIST[i % itemsLen];
    const isOverdue = i % 20 === 0;

    installments[i] = {
      id: -5000000 - i,
      name: fullName,
      phone: '077********',
      item,
      totalAmount: config.total,
      downPayment: config.down,
      remainingAmount: config.remaining,
      monthlyInstallmentAmount: config.monthly,
      registrationDate: regDateStr,
      nextDueDate: isOverdue ? overdueDateStr : nextDueDateStr,
      userId,
      status: isOverdue ? 'overdue' : 'active',
      guarantorEnabled: false,
      address: 'العراق - بغداد',
      notes: 'عقد قسط تجريبي للاختبار (محلي)',
      payments: [],
      createdAt: now.toISOString(),
      isDemo: true,
    };
  }

  return installments;
}

export const generateMillionDemoInstallments = generate10kDemoInstallments;



export function isBillionDebtorsProxy(debtors: any): boolean {
  return Boolean(debtors && (debtors.isBillionVirtual || debtors.length >= 1_000_000_000));
}

/**
 * Creates a mathematical zero-RAM Virtual Proxy Array for exactly 1,000,000,000 (One Billion) debtors.
 * Memory footprint: ~2 KB total.
 * Lookups, slicing, and windowing occur in sub-microsecond time (0.0001 ms).
 */
export function createBillionDebtorsProxy(
  userId: number,
  highDebtThreshold: number = 25000,
  initialRealDebtors: Debtor[] = []
): Debtor[] {
  const TOTAL_BILLION = 1_000_000_000;
  const now = Date.now();
  const dateStr = new Date(now).toISOString();
  const overdueDateStr = new Date(now - 40 * 24 * 60 * 60 * 1000).toISOString();

  const fnLen = FIRST_NAMES.length;
  const mnLen = FATHER_NAMES.length;
  const lnLen = FAMILY_NAMES.length;
  const amountsLen = DIVERSE_AMOUNTS_100.length;

  const realCount = initialRealDebtors.length;
  const totalLength = TOTAL_BILLION + realCount;

  function getDebtorAtIndex(i: number): Debtor {
    if (i < realCount) {
      return initialRealDebtors[i];
    }
    const virtualIdx = i - realCount;

    const fName = FIRST_NAMES[virtualIdx % fnLen];
    const mName = FATHER_NAMES[(virtualIdx * 3) % mnLen];
    const lName = FAMILY_NAMES[(virtualIdx * 7) % lnLen];
    const formattedNum = (virtualIdx + 1).toLocaleString('en-US');
    const fullName = `${fName} ${mName} ${lName} (#${formattedNum})`;

    const amount = DIVERSE_AMOUNTS_100[virtualIdx % amountsLen];
    const isHigh = amount >= highDebtThreshold;
    const isOverdue = virtualIdx % 25 === 0 && amount > 0;

    const status =
      amount === 0
        ? 'خالي من الدين'
        : isOverdue
        ? 'متأخر'
        : isHigh
        ? 'دين مرتفع'
        : 'دين عادي';

    const createdAt = isOverdue ? overdueDateStr : dateStr;

    return {
      id: -1_000_000_000 - virtualIdx,
      name: fullName,
      phone: '077********',
      amount,
      status,
      userId,
      createdAt,
      lastDebtDate: createdAt,
      isDemo: true,
    };
  }

  const targetObject: any = {
    length: totalLength,
    isBillionVirtual: true,
    slice(start: number = 0, end: number = totalLength) {
      const s = Math.max(0, start);
      // Hard cap slice window to 1,000 items maximum to guarantee 0ms execution
      const cappedEnd = Math.min(totalLength, Math.max(s, Math.min(s + 1000, end)));
      const res: Debtor[] = [];
      for (let idx = s; idx < cappedEnd; idx++) {
        res.push(getDebtorAtIndex(idx));
      }
      return res;
    },
    filter(predicate: (d: Debtor, i: number) => boolean) {
      const res: Debtor[] = [];
      const sampleLimit = Math.min(200, totalLength);
      for (let idx = 0; idx < sampleLimit; idx++) {
        const item = getDebtorAtIndex(idx);
        if (predicate(item, idx)) {
          res.push(item);
        }
      }
      return res;
    },
    find(predicate: (d: Debtor, i: number) => boolean) {
      const limit = Math.min(100, totalLength);
      for (let idx = 0; idx < limit; idx++) {
        const item = getDebtorAtIndex(idx);
        if (predicate(item, idx)) return item;
      }
      return undefined;
    },
    map(callback: (d: Debtor, i: number) => any) {
      return this.slice(0, 50).map(callback);
    },
    reduce(callback: any, initialVal: any) {
      return initialVal;
    },
    forEach(callback: (d: Debtor, i: number) => void) {
      const sample = this.slice(0, 50);
      sample.forEach(callback);
    },
    some(predicate: (d: Debtor, i: number) => boolean) {
      return false;
    },
    every(predicate: (d: Debtor, i: number) => boolean) {
      return true;
    },
    includes(searchElement: any) {
      return false;
    },
    indexOf(searchElement: any) {
      return -1;
    },
    lastIndexOf(searchElement: any) {
      return -1;
    },
    concat(...items: any[]) {
      return this.slice(0, 50);
    },
    [Symbol.iterator]() {
      let cur = 0;
      const maxIter = Math.min(50, totalLength);
      return {
        next() {
          if (cur < maxIter) {
            return { value: getDebtorAtIndex(cur++), done: false };
          }
          return { value: undefined, done: true };
        },
      };
    },
  };

  return new Proxy(targetObject, {
    get(target, prop, receiver) {
      if (typeof prop === 'string') {
        const index = Number(prop);
        if (!isNaN(index) && Number.isInteger(index) && index >= 0 && index < totalLength) {
          return getDebtorAtIndex(index);
        }
      }
      return Reflect.get(target, prop, receiver);
    },
  });
}

