import { Debtor, InstallmentRecord } from '../types';

/**
 * Formats a phone number for WhatsApp URL.
 * Handles Iraqi phone numbers (07xxxxxxxxx -> 9647xxxxxxxxx)
 * and cleans up any spaces, dashes, or non-numeric characters.
 */
export function formatPhoneNumberForWhatsApp(phone: string): string {
  if (!phone) return '';
  let cleaned = phone.replace(/[^\d+]/g, '');

  // Handle + prefix
  if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }

  // Handle 00964...
  if (cleaned.startsWith('00964')) {
    cleaned = cleaned.substring(2);
  }

  // If starts with 07..., convert to 9647...
  if (cleaned.startsWith('07')) {
    cleaned = '964' + cleaned.substring(1);
  } else if (cleaned.length === 10 && cleaned.startsWith('7')) {
    cleaned = '964' + cleaned;
  }

  return cleaned;
}

/**
 * Generates the full WhatsApp API URL for sending a message
 */
export function getWhatsAppUrl(phone: string, message: string): string {
  const formattedPhone = formatPhoneNumberForWhatsApp(phone);
  const encodedText = encodeURIComponent(message);
  return `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedText}`;
}

/**
 * Directly opens WhatsApp without any intermediate UI
 */
export function openWhatsAppDirect(phone: string, message: string): boolean {
  try {
    const formattedPhone = formatPhoneNumberForWhatsApp(phone);
    if (!formattedPhone) return false;
    const url = getWhatsAppUrl(phone, message);

    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) {
        document.body.removeChild(a);
      }
    }, 200);
    return true;
  } catch (err) {
    console.warn('Could not open WhatsApp directly:', err);
    try {
      const url = getWhatsAppUrl(phone, message);
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    } catch {
      return false;
    }
  }
}

export interface WhatsAppNotificationData {
  customerName: string;
  phone: string;
  title: string;
  message: string;
  url: string;
}

/**
 * 1. عند إضافة عميل جديد (New Debtor)
 * القالب:
 * تم تسجيل دين
 * اسم الزبون :
 * المبلغ :
 * التاريخ :
 * الملاحظات : لا توجد ملاحظات
 * مبلغ الدين السابق :
 * مبلغ الدين الكلي :
 */
export function createNewDebtorWhatsAppNotice(
  debtor: Debtor,
  currencySymbol: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAmount = Number(debtor.amount || 0).toLocaleString('en-US');
  const dateStr = debtor.createdAt
    ? debtor.createdAt.split('T')[0]
    : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالشركة: ${dComp.trim()}`
    : '';

  const message = `إشعار تسجيل دين

السيد/ ${debtor.name}${companyLine}

تم تسجيل مبلغ مستحق في حسابكم لدينا، وفق التفاصيل التالية:

مبلغ الدين: ${formattedAmount} ${currencySymbol}
تاريخ تسجيل الدين: ${dateStr}
الدفعات المسددة: 0 ${currencySymbol}
الرصيد المتبقي: ${formattedAmount} ${currencySymbol}

تم تسجيل المبلغ أعلاه في حسابكم، ويُعد الرصيد المتبقي ذمة مستحقة عليكم.

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'تسجيل دين جديد',
    message,
    url,
  };
}

/**
 * 2. عند إضافة دين لعميل موجود (Add Debt)
 */
export function createAddDebtWhatsAppNotice(
  debtor: Debtor,
  addedAmount: number,
  newTotalAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedAdded = addedAmount.toLocaleString('en-US');
  const formattedTotal = newTotalAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالشركة: ${dComp.trim()}`
    : '';

  // Calculate total paid so far if history exists
  let totalPaid = 0;
  if (debtor.history && debtor.history.length > 0) {
    totalPaid = debtor.history
      .filter((h) => h.type === 'pay')
      .reduce((sum, h) => sum + (Number(h.amount) || 0), 0);
  }
  const formattedPaid = totalPaid.toLocaleString('en-US');

  const message = `إشعار تسجيل دين

السيد/ ${debtor.name}${companyLine}

تم تسجيل مبلغ مستحق في حسابكم لدينا، وفق التفاصيل التالية:

مبلغ الدين: ${formattedAdded} ${currencySymbol}
تاريخ تسجيل الدين: ${dateStr}
الدفعات المسددة: ${formattedPaid} ${currencySymbol}
الرصيد المتبقي: ${formattedTotal} ${currencySymbol}
${notes && notes.trim() ? `الملاحظات: ${notes.trim()}\n` : ''}
تم تسجيل المبلغ أعلاه في حسابكم، ويُعد الرصيد المتبقي ذمة مستحقة عليكم.

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إشعار إضافة دين',
    message,
    url,
  };
}

/**
 * 3. عند تسديد دين (Pay Debt)
 */
export function createPayDebtWhatsAppNotice(
  debtor: Debtor,
  paidAmount: number,
  remainingAmount: number,
  currencySymbol: string,
  txDate?: string,
  notes?: string,
  _storeName: string = 'دفتر الديون'
): WhatsAppNotificationData | null {
  if (!debtor.phone || !debtor.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = remainingAmount.toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const dComp = (debtor as { companyName?: string }).companyName;
  const companyLine = dComp && dComp.trim()
    ? `\nالشركة: ${dComp.trim()}`
    : '';

  const message = `إيصال تسديد دفعة

السيد/ ${debtor.name}${companyLine}

تم تسجيل تسديد دفعة في حسابكم لدينا، حسب التفاصيل التالية:

المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ الدفع: ${dateStr}
الرصيد المتبقي: ${formattedRemaining} ${currencySymbol}
${notes && notes.trim() ? `الملاحظات: ${notes.trim()}\n` : ''}
تم تسجيل الدفعة أعلاه في حسابكم، ويُعد الرصيد المتبقي ذمة مستحقة في حسابكم.

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(debtor.phone, message);
  return {
    customerName: debtor.name,
    phone: debtor.phone,
    title: 'إيصال تسديد دين',
    message,
    url,
  };
}

/**
 * 4. عند إضافة عقد قسط جديد (New Installment)
 */
export function createNewInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  currencySymbol: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedTotal = Number(inst.totalAmount || 0).toLocaleString('en-US');
  const formattedDown = Number(inst.downPayment || 0).toLocaleString('en-US');
  const formattedRemaining = Number(inst.remainingAmount || 0).toLocaleString('en-US');

  const message = `مرحباً ${inst.name}
تم تسجيل معاملة قسط جديدة لكم لدى (${storeName}):

السلعة: ${inst.item}
إجمالي قيمة الأقساط: ${formattedTotal} ${currencySymbol}
الدفعة المقدمة: ${formattedDown} ${currencySymbol}
المبلغ المتبقي: ${formattedRemaining} ${currencySymbol}
تاريخ القسط القادم: ${inst.nextDueDate}
${inst.notes ? `ملاحظات: ${inst.notes}\n` : ''}
شكراً لثقتكم بنا.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'تسجيل معاملة قسط جديدة',
    message,
    url,
  };
}

/**
 * 5. عند تسديد قسط (Pay Installment)
 */
export function createPayInstallmentWhatsAppNotice(
  inst: InstallmentRecord,
  paidAmount: number,
  newRemaining: number,
  nextDueDate: string,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  storeName: string = 'نظام الأقساط'
): WhatsAppNotificationData | null {
  if (!inst.phone || !inst.phone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemaining.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];

  const isCompleted = newRemaining <= 0;
  const statusLine = isCompleted
    ? 'تم تسديد كامل الأقساط بنجاح واكتمل العقد بالكامل.'
    : `المتبقي الكلي: ${formattedRemaining} ${currencySymbol}\nموعد القسط القادم: ${nextDueDate}`;

  const message = `مرحباً ${inst.name}
إيصال تسديد قسط لدى (${storeName}):

السلعة: ${inst.item}
المبلغ المسدد: ${formattedPaid} ${currencySymbol}
تاريخ الدفع: ${dateStr}
${statusLine}
${notes ? `ملاحظات: ${notes}\n` : ''}
شكراً لالتزامكم بالتسديد.`;

  const url = getWhatsAppUrl(inst.phone, message);
  return {
    customerName: inst.name,
    phone: inst.phone,
    title: 'إيصال تسديد قسط',
    message,
    url,
  };
}

/**
 * 6. عند تسجيل مورد جديد / بضاعة بالأجل من مورد (New Supplier)
 */
export function createNewSupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  notes?: string,
  itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const dateStr = new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالشركة: ${companyName.trim()}` : '';
  const itemLine = itemType && itemType.trim() ? `\nنوع البضاعة: ${itemType.trim()}` : '';

  const notesStr = notes && notes.trim() ? notes.trim() : 'لا توجد ملاحظات';

  const message = `إشعار تسجيل دين

السيد/ ${supplierName}${companyLine}

تم تسجيل مبلغ مستحق في حسابكم لدينا، وفق التفاصيل التالية:

مبلغ الدين: ${formattedAmount} ${currencySymbol}${itemLine}
تاريخ تسجيل الدين: ${dateStr}
الدفعات المسددة: 0 ${currencySymbol}
الرصيد المتبقي: ${formattedAmount} ${currencySymbol}
الملاحظات: ${notesStr}

تم تسجيل المبلغ أعلاه في حسابكم، ويُعد الرصيد المتبقي ذمة مستحقة.

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار دين مورد',
    message,
    url,
  };
}

/**
 * 6.b. عند إضافة شحنة / دين جديد للمورد (Add Debt to Supplier)
 */
export function createAddSupplierDebtWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  addedAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  notes?: string,
  itemType?: string,
  txDate?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAdded = Number(addedAmount || 0).toLocaleString('en-US');
  const formattedTotal = Number(newRemainingAmount || 0).toLocaleString('en-US');
  const dateStr = txDate ? txDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالشركة: ${companyName.trim()}` : '';
  const itemLine = itemType && itemType.trim() ? `\nنوع البضاعة: ${itemType.trim()}` : '';
  const notesStr = notes && notes.trim() ? notes.trim() : 'لا توجد ملاحظات';

  const message = `إشعار إضافة شحنة بضاعة جديدة

السيد/ ${supplierName}${companyLine}

تم تسجيل شحنة بضاعة جديدة في حسابكم لدينا، وفق التفاصيل التالية:

مبلغ الشحنة الجديدة: ${formattedAdded} ${currencySymbol}${itemLine}
تاريخ التسجيل: ${dateStr}
الرصيد الكلي المتبقي: ${formattedTotal} ${currencySymbol}
الملاحظات: ${notesStr}

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إشعار إضافة شحنة بضاعة',
    message,
    url,
  };
}

/**
 * 7. عند تسديد مبلغ للمورد (Pay Supplier)
 */
export function createPaySupplierWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  paidAmount: number,
  newRemainingAmount: number,
  currencySymbol: string,
  payDate?: string,
  notes?: string,
  itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedPaid = paidAmount.toLocaleString('en-US');
  const formattedRemaining = newRemainingAmount.toLocaleString('en-US');
  const dateStr = payDate ? payDate.split('T')[0] : new Date().toISOString().split('T')[0];
  const companyLine = companyName && companyName.trim() ? `\nالشركة: ${companyName.trim()}` : '';
  const itemLine = itemType && itemType.trim() ? `\nنوع البضاعة: ${itemType.trim()}` : '';

  const notesStr = notes && notes.trim() ? notes.trim() : 'لا توجد ملاحظات';

  const message = `إيصال تسديد دفعة

السيد/ ${supplierName}${companyLine}

تم تسجيل تسديد دفعة في حسابكم لدينا، حسب التفاصيل التالية:

المبلغ المسدد: ${formattedPaid} ${currencySymbol}${itemLine}
تاريخ الدفع: ${dateStr}
الرصيد المتبقي: ${formattedRemaining} ${currencySymbol}
الملاحظات: ${notesStr}

تم تسجيل الدفعة أعلاه في حسابكم، ويُعد الرصيد المتبقي ذمة مستحقة في حسابكم.

شكراً لتعاملكم معنا، ونسعد باستمرار التعاون بيننا.`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'إيصال تسديد للمورد',
    message,
    url,
  };
}

/**
 * 8. تذكير بحساب المورد (Supplier Reminder)
 */
export function createSupplierReminderWhatsAppNotice(
  supplierName: string,
  supplierPhone: string,
  companyName: string | undefined,
  amount: number,
  currencySymbol: string,
  itemType?: string
): WhatsAppNotificationData | null {
  if (!supplierPhone || !supplierPhone.trim()) return null;

  const formattedAmount = Number(amount || 0).toLocaleString('en-US');
  const companyLine = companyName && companyName.trim() ? ` (${companyName.trim()})` : '';
  const itemLine = itemType && itemType.trim() ? `\nنوع البضاعة: ${itemType.trim()}` : '';

  const message = `السلام عليكم السيد (${supplierName})${companyLine}
بخصوص حساب توريد البضاعة القائم بقيمة (${formattedAmount} ${currencySymbol}).${itemLine}
رسالة تذكير`;

  const url = getWhatsAppUrl(supplierPhone, message);
  return {
    customerName: supplierName,
    phone: supplierPhone,
    title: 'تذكير حساب المورد',
    message,
    url,
  };
}
