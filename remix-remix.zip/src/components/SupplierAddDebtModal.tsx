import React, { useState, useEffect } from 'react';
import { Supplier } from '../types';
import { formatNumber, formatAmountInput, parseFormattedNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface SupplierAddDebtModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onAddDebt: (supplierId: number, addedAmount: number, notes?: string, txDate?: string, itemType?: string) => void;
  currencySymbol?: string;
}

export const SupplierAddDebtModal: React.FC<SupplierAddDebtModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onAddDebt,
  currencySymbol = 'د.ع',
}) => {
  const { numberFormat } = useI18n();
  const [addAmount, setAddAmount] = useState('');
  const [itemType, setItemType] = useState('');
  const [notes, setNotes] = useState('');
  const [debtDate, setDebtDate] = useState(new Date().toISOString().split('T')[0]);

  // Always reset fields to empty when modal opens or supplier changes
  useEffect(() => {
    if (isOpen && supplier) {
      setItemType('');
      setNotes('');
      setAddAmount('');
      setDebtDate(new Date().toISOString().split('T')[0]);
    }
  }, [supplier, isOpen]);

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(addAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى كتابة مبلغ الدين المضاف بشكل صحيح.');
      return;
    }

    onAddDebt(
      supplier.id,
      numAmount,
      notes.trim() || undefined,
      debtDate,
      itemType.trim() || undefined
    );

    // Reset & Close
    setAddAmount('');
    setItemType('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-cart-plus text-amber-100"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">إضافة دين / شحنة جديدة للمورد</h3>
              <p className="text-[11px] text-amber-100/90 font-medium">تسجيل شحنة بضاعة بالأجل لحساب المورد</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Info Banner */}
        <div className="p-3.5 bg-amber-50/60 dark:bg-amber-950/20 border-b border-amber-200/80 dark:border-amber-800/40 text-start flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">اسم المورد / الشركة</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {supplier.name}{' '}
              {supplier.companyName && supplier.companyName.trim() ? `(${supplier.companyName.trim()})` : ''}
            </span>
          </div>
          <div className="text-left">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">الدين الحالي للمورد</span>
            <span className="text-sm font-black text-amber-600 dark:text-amber-400 font-mono">
              {formatNumber(currentAmount, numberFormat)} {currencySymbol}
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-start">
          {/* Debt Amount */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              مبلغ الدين / البضاعة الجديد <span className="text-rose-500">*</span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={addAmount}
                onChange={(e) => setAddAmount(formatAmountInput(e.target.value))}
                placeholder="أدخل المبلغ (مثال: 500,000)..."
                className="w-full p-3 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800/80 rounded-2xl text-base font-black text-amber-900 dark:text-amber-200 outline-none focus:border-amber-600 focus:ring-2 focus:ring-amber-500/30 transition-all"
              />
              <span className="absolute left-3 text-xs font-extrabold text-amber-700 dark:text-amber-400">
                {currencySymbol}
              </span>
            </div>
          </div>

          {/* Item Type (Goods Details for this shipment) */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              نوع وتفاصيل البضاعة / المواد للشحنة <span className="text-slate-400 font-normal">(مستقل)</span>
            </label>
            <textarea
              rows={2}
              value={itemType}
              onChange={(e) => setItemType(e.target.value)}
              placeholder="اكتب هنا بضاعة هذه الشحنة الجديدة (مثال: أجهزة كهربائية، مواد غذائية...)"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Date Picker */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">تاريخ تسجيل الدين</label>
            <input
              type="date"
              value={debtDate}
              onChange={(e) => setDebtDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
            />
          </div>

          {/* Notes / Invoice details */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              ملاحظات أو رقم الوصل/الفاتورة للشحنة <span className="text-slate-400 font-normal">(مستقل)</span>
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="اكتب أي ملاحظات أو رقم وصل خاص بهذه الشحنة..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-plus text-xs"></i>
              <span>حفظ وإضافة الدين الآن</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
