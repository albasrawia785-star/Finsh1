import React, { useState, useEffect, useRef } from 'react';
import { AppLayoutTheme, TabType } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';

interface BottomNavProps {
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenAddModal?: () => void;
  isAdmin?: boolean;
  overdueCount?: number;
  dueInstallmentsCount?: number;
  mode?: 'debts' | 'installments' | 'suppliers';
  layoutTheme?: AppLayoutTheme;
}

export const BottomNav: React.FC<BottomNavProps> = React.memo(({
  activeTab,
  onSelectTab,
  onOpenAddModal,
  overdueCount = 0,
  dueInstallmentsCount = 0,
  mode = 'debts',
  layoutTheme = 'fintech',
}) => {
  const { t, numberFormat } = useI18n();
  const isInstallments = mode === 'installments';
  const isSuppliers = mode === 'suppliers';
  const isFintech = layoutTheme === 'fintech';
  const activeOverdueBadgeCount = isInstallments ? dueInstallmentsCount : overdueCount;
  const [isKeyboardOpen, setIsKeyboardOpen] = useState(false);
  const isInputFocusedRef = useRef(false);

  useEffect(() => {
    let timeoutId: any = null;

    const checkKeyboard = () => {
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        const activeEl = document.activeElement;
        const isInputFocused =
          Boolean(activeEl &&
          (activeEl.tagName === 'INPUT' ||
            activeEl.tagName === 'TEXTAREA' ||
            (activeEl as HTMLElement).isContentEditable));

        isInputFocusedRef.current = isInputFocused;

        if (window.visualViewport) {
          const heightDiff = window.innerHeight - window.visualViewport.height;
          if (heightDiff > 100 || isInputFocused) {
            setIsKeyboardOpen(true);
            return;
          }
        } else if (isInputFocused) {
          setIsKeyboardOpen(true);
          return;
        }

        setIsKeyboardOpen(false);
      }, 50);
    };

    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        isInputFocusedRef.current = true;
        setIsKeyboardOpen(true);
      }
    };

    const handleFocusOut = () => {
      isInputFocusedRef.current = false;
      if (timeoutId) clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        checkKeyboard();
      }, 150);
    };

    const vv = window.visualViewport;
    if (vv) {
      vv.addEventListener('resize', checkKeyboard, { passive: true });
    }
    window.addEventListener('resize', checkKeyboard, { passive: true });
    document.addEventListener('focusin', handleFocusIn, { passive: true });
    document.addEventListener('focusout', handleFocusOut, { passive: true });

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      if (vv) {
        vv.removeEventListener('resize', checkKeyboard);
      }
      window.removeEventListener('resize', checkKeyboard);
      document.removeEventListener('focusin', handleFocusIn);
      document.removeEventListener('focusout', handleFocusOut);
    };
  }, []);

  return (
    <nav
      aria-label={t('nav.mainNav', 'التنقل الرئيسي')}
      className={`md:hidden select-none gpu-layer z-40 transition-all duration-200 ${
        isFintech
          ? 'fixed bottom-2.5 left-1/2 -translate-x-1/2 w-[calc(100%-20px)] max-w-[460px] bg-white/95 backdrop-blur-md rounded-2xl flex justify-between items-center px-2 py-1.5 border border-slate-200/90 shadow-[0_8px_30px_rgb(0,0,0,0.08)]'
          : 'fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[500px] bg-white flex justify-between items-center px-2 pt-1.5 nav-safe-bottom border-t border-slate-200 shadow-sm'
      } ${
        isKeyboardOpen
          ? 'translate-y-full opacity-0 pointer-events-none invisible'
          : 'translate-y-0 opacity-100 pointer-events-auto visible'
      }`}
    >
      {/* 1. Home (الرئيسية) */}
      <button
        type="button"
        onClick={() => onSelectTab('home')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'home'
              ? isSuppliers
                ? 'px-3 py-1 rounded-full bg-amber-50 text-amber-600 scale-105'
                : isInstallments
                ? 'px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 scale-105'
                : 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-house-chimney text-[14px]"></i>
        </div>
        <span
          className={`text-[10px] mt-0.5 transition-colors ${
            activeTab === 'home'
              ? isSuppliers
                ? 'text-amber-600 font-bold'
                : isInstallments
                ? 'text-emerald-600 font-bold'
                : 'text-blue-600 font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          {t('nav.home', 'الرئيسية')}
        </span>
      </button>

      {/* 2. Overdue (المتأخرون) */}
      <button
        type="button"
        onClick={() => onSelectTab('overdue')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all relative focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all relative ${
            activeTab === 'overdue'
              ? isSuppliers
                ? 'px-3 py-1 rounded-full bg-amber-50 text-amber-600 scale-105'
                : isInstallments
                ? 'px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 scale-105'
                : 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-hourglass-half text-[14px]"></i>
          {activeOverdueBadgeCount > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[17px] h-[17px] bg-rose-500 text-white font-mono text-[9.5px] font-extrabold rounded-full flex items-center justify-center px-1 shadow-sm border-2 border-white animate-pulse">
              {formatNumber(activeOverdueBadgeCount, numberFormat)}
            </span>
          )}
        </div>
        <span
          className={`text-[10px] mt-0.5 transition-colors ${
            activeTab === 'overdue'
              ? isSuppliers
                ? 'text-amber-600 font-bold'
                : isInstallments
                ? 'text-emerald-600 font-bold'
                : 'text-blue-600 font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          {isSuppliers ? 'المستحقة' : t('nav.overdue', 'المتأخرون')}
        </span>
      </button>

      {/* 3. EXACT CENTER ADD BUTTON */}
      <button
        id="btnAddDebtorBottom"
        type="button"
        onClick={onOpenAddModal}
        className="flex flex-col items-center justify-center -translate-y-2.5 group cursor-pointer focus:outline-none shrink-0 px-2"
        title={isSuppliers ? 'إضافة مورد جديد' : isInstallments ? t('installments.addInstallment', 'إضافة قسط جديد') : t('debtors.addDebtor', 'إضافة مدين جديد')}
      >
        <div className={`w-[46px] h-[46px] rounded-full text-white flex items-center justify-center transition-all border-[3px] border-white active:scale-90 ${
          isSuppliers
            ? 'bg-gradient-to-tr from-amber-500 via-orange-500 to-amber-600 hover:from-amber-600 hover:to-orange-600 shadow-[0_10px_25px_-5px_rgba(245,158,11,0.5)]'
            : isInstallments
            ? 'bg-gradient-to-tr from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 shadow-[0_10px_25px_-5px_rgba(16,185,129,0.45)]'
            : 'bg-gradient-to-tr from-blue-600 via-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-[0_10px_25px_-5px_rgba(37,99,235,0.45)]'
        }`}>
          <i className="fa-solid fa-plus text-base"></i>
        </div>
        <span className={`text-[10px] font-extrabold mt-0.5 tracking-tight ${
          isSuppliers ? 'text-amber-600' : isInstallments ? 'text-emerald-600' : 'text-blue-600'
        }`}>
          {t('nav.add', 'إضافة')}
        </span>
      </button>

      {/* 4. Reports (التقارير) */}
      <button
        type="button"
        onClick={() => onSelectTab('reports')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'reports'
              ? isSuppliers
                ? 'px-3 py-1 rounded-full bg-amber-50 text-amber-600 scale-105'
                : isInstallments
                ? 'px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 scale-105'
                : 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-chart-simple text-[14px]"></i>
        </div>
        <span
          className={`text-[10px] mt-0.5 transition-colors ${
            activeTab === 'reports'
              ? isSuppliers
                ? 'text-amber-600 font-bold'
                : isInstallments
                ? 'text-emerald-600 font-bold'
                : 'text-blue-600 font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          {t('nav.reports', 'التقارير')}
        </span>
      </button>

      {/* 5. Settings (الإعدادات) */}
      <button
        type="button"
        onClick={() => onSelectTab('settings')}
        className="flex flex-col items-center flex-1 py-0.5 group cursor-pointer transition-all focus:outline-none"
      >
        <div
          className={`flex items-center justify-center transition-all ${
            activeTab === 'settings'
              ? isSuppliers
                ? 'px-3 py-1 rounded-full bg-amber-50 text-amber-600 scale-105'
                : isInstallments
                ? 'px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 scale-105'
                : 'px-3 py-1 rounded-full bg-blue-50 text-blue-600 scale-105'
              : 'px-3 py-1 text-slate-400 group-hover:text-slate-600'
          }`}
        >
          <i className="fa-solid fa-gear text-[14px]"></i>
        </div>
        <span
          className={`text-[10px] mt-0.5 transition-colors ${
            activeTab === 'settings'
              ? isSuppliers
                ? 'text-amber-600 font-bold'
                : isInstallments
                ? 'text-emerald-600 font-bold'
                : 'text-blue-600 font-bold'
              : 'text-slate-400 font-medium'
          }`}
        >
          {t('nav.settings', 'الإعدادات')}
        </span>
      </button>
    </nav>
  );
});

BottomNav.displayName = 'BottomNav';
