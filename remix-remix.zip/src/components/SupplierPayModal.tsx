import React, { useState } from 'react';
import { Supplier } from '../types';
import { formatNumber, formatAmountInput, parseFormattedNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface SupplierPayModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onPaySupplier: (supplierId: number, amount: number, notes?: string, payDate?: string) => void;
  currencySymbol?: string;
}

export const SupplierPayModal: React.FC<SupplierPayModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onPaySupplier,
  currencySymbol = 'د.ع',
}) => {
  const { numberFormat } = useI18n();
  const [payAmount, setPayAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [payDate, setPayDate] = useState(new Date().toISOString().split('T')[0]);

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(payAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى أدخال مبلغ التسديد بشكل صحيح.');
      return;
    }

    if (numAmount > currentAmount) {
      if (!confirm(`المبلغ المدخل (${formatNumber(numAmount, numberFormat)}) أكبر من الدين القائم عليك للمورد (${formatNumber(currentAmount, numberFormat)}). هل تريد الاستمرار؟`)) {
        return;
      }
    }

    onPaySupplier(supplier.id, numAmount, notes.trim() || undefined, payDate);

    // Reset & Close
    setPayAmount('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-cyan-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-hand-holding-dollar text-emerald-100"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">تسديد المورد / الشركة</h3>
              <p className="text-[11px] text-emerald-100/90 font-medium">تسديد دفعة مالية من الدين المطلوب منك</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Info Banner */}
        <div className="p-3.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700/80 text-start flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">اسم المورد / الشركة</span>
            <span className="text-xs font-black text-slate-900 dark:text-white">
              {typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '')}{' '}
              {typeof supplier.companyName === 'string' && supplier.companyName.trim()
                ? `(${supplier.companyName.trim()})`
                : ''}
            </span>
          </div>
          <div className="text-left">
            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-bold block">الدين المتبقي له عليك</span>
            <span className="text-sm font-black text-amber-600 dark:text-amber-400 font-mono">
              {formatNumber(currentAmount, numberFormat)} {currencySymbol}
            </span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 text-start">
          {/* Pay Amount */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              المبلغ المسدد للمورد <span className="text-rose-500">*</span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={payAmount}
                onChange={(e) => setPayAmount(formatAmountInput(e.target.value))}
                placeholder="أدخل مبلغ التسديد (مثال: 100,000)..."
                className="w-full p-3 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-300 dark:border-emerald-800/80 rounded-2xl text-base font-black text-emerald-900 dark:text-emerald-200 outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-500/30 transition-all"
              />
              <span className="absolute left-3 text-xs font-extrabold text-emerald-700 dark:text-emerald-400">
                {currencySymbol}
              </span>
            </div>
            <button
              type="button"
              onClick={() => setPayAmount(formatAmountInput(String(currentAmount)))}
              className="text-[10px] font-bold text-emerald-600 hover:underline cursor-pointer pt-0.5 inline-block"
            >
              تسديد كامل الدين المتبقي ({formatNumber(currentAmount, numberFormat)} {currencySymbol})
            </button>
          </div>

          {/* Payment Date */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">تاريخ التسديد</label>
            <input
              type="date"
              value={payDate}
              onChange={(e) => setPayDate(e.target.value)}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
            />
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">ملاحظات / طريقة الدفع</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: نقداً / تحويل زين كاش / حوالة..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all"
            />
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-check text-xs"></i>
              <span>حفظ التسديد وإخصام الدين</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
