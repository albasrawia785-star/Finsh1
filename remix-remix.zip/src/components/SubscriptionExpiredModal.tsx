import React from 'react';
import { User } from '../types';
import { formatDateDigits } from '../utils/formatters';

interface SubscriptionExpiredModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
}

export const SubscriptionExpiredModal: React.FC<SubscriptionExpiredModalProps> = ({
  isOpen,
  onClose,
  currentUser,
}) => {
  if (!isOpen) return null;

  const adminPhone = '07700000000'; // Default admin contact

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-100 text-center space-y-5 animate-in zoom-in-95 duration-200">
        {/* Lock Header Icon */}
        <div className="relative inline-block mx-auto">
          <div className="w-18 h-18 rounded-3xl bg-rose-50 text-rose-600 flex items-center justify-center text-3xl shadow-lg border border-rose-200 mx-auto">
            <i className="fa-solid fa-lock text-rose-600"></i>
          </div>
          <span className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full bg-rose-600 text-white flex items-center justify-center text-xs font-bold border-2 border-white shadow-xs">
            <i className="fa-solid fa-exclamation"></i>
          </span>
        </div>

        {/* Title & Desc */}
        <div className="space-y-2">
          <h2 className="text-xl font-extrabold text-slate-900">
            تم قفل الحساب تلقائياً
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed max-w-xs mx-auto">
            لقد انتهت فترة الاشتراك الشهري الخاصة بهذا الفرع بتاريخ{' '}
            <span className="font-mono font-bold text-rose-700 dir-ltr inline-block">
              {formatDateDigits(currentUser?.subscriptionExpiresAt)}
            </span>
            . تم تعطيل عمليات الإضافة والتعديل لحماية البيانات.
          </p>
        </div>

        {/* Details Box */}
        <div className="bg-rose-50/70 border border-rose-200/80 rounded-2xl p-3.5 text-xs text-start space-y-2">
          <div className="flex items-center justify-between text-slate-700">
            <span className="font-semibold text-slate-500">اسم الفرع:</span>
            <span className="font-bold text-slate-900">{currentUser?.branch_name || 'الفرع الفرعي'}</span>
          </div>
          <div className="flex items-center justify-between text-slate-700 border-t border-rose-200/50 pt-2">
            <span className="font-semibold text-slate-500">اسم المستخدم:</span>
            <span className="font-bold font-mono text-slate-900">@{currentUser?.username}</span>
          </div>
          <div className="flex items-center justify-between text-slate-700 border-t border-rose-200/50 pt-2">
            <span className="font-semibold text-slate-500">حالة الحساب:</span>
            <span className="font-extrabold text-rose-700 bg-rose-100/80 px-2 py-0.5 rounded-md">
              مقفل (اشتراك منتهي)
            </span>
          </div>
        </div>

        {/* Notice */}
        <div className="p-3 bg-amber-50 border border-amber-200/80 rounded-xl text-[11px] text-amber-900 text-start flex items-start gap-2">
          <i className="fa-solid fa-circle-info text-amber-600 text-sm mt-0.5 shrink-0"></i>
          <span>
            لتفعيل وتجديد الاشتراك الشهري واستئناف العمل فوراً، يرجى التواصل مباشرة مع الإدارة العامة.
          </span>
        </div>

        {/* Buttons */}
        <div className="space-y-2 pt-1">
          <a
            href={`https://wa.me/?text=${encodeURIComponent(
              `مرحباً الإدارة العامة، أود تجديد اشتراك فرع: (${currentUser?.branch_name}) - اسم المستخدم: (${currentUser?.username})`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-2xl shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-brands fa-whatsapp text-base"></i>
            <span>التواصل عبر واتساب للإدارة العامة</span>
          </a>

          <button
            type="button"
            onClick={onClose}
            className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
