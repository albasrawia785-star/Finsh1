import React from 'react';
import { Supplier } from '../types';
import { useI18n } from '../i18n/index.tsx';

interface SupplierSettleCompleteModalProps {
  isOpen: boolean;
  supplier: Supplier | null;
  onKeep: () => void;
  onDelete: () => void;
}

export const SupplierSettleCompleteModal: React.FC<SupplierSettleCompleteModalProps> = ({
  isOpen,
  supplier,
  onKeep,
  onDelete,
}) => {
  const { currencySymbol = 'د.ع' } = useI18n();

  if (!isOpen || !supplier) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 select-none">
      <div
        className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-sm p-6 shadow-2xl relative border border-slate-100 dark:border-slate-800 text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Success Icon */}
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-2xl mx-auto mb-3.5 shadow-sm border border-emerald-100 dark:border-emerald-900/50">
          <i className="fa-solid fa-circle-check"></i>
        </div>

        <span className="text-[11px] font-bold bg-emerald-100/70 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 px-3 py-1 rounded-full inline-block mb-2">
          خالص الذمة 100%
        </span>

        <h3 className="font-black text-base text-slate-800 dark:text-white mb-1.5">
          تم تسديد كامل دين المورد
        </h3>

        <p className="text-xs text-slate-500 dark:text-slate-400 mb-2 leading-relaxed">
          تم تسديد جميع المستحقات المترتبة لصالح المورد <span className="font-bold text-slate-800 dark:text-slate-200">{supplier.name}</span> بالكامل وأصبح الرصيد <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">0 {currencySymbol}</span>.
        </p>

        <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-5 bg-slate-50 dark:bg-slate-800/80 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
          هل تريد حذف المورد من القائمة أم الإبقاء عليه في السجل كخالص الذمة؟
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={onKeep}
            className="w-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white py-2.5 rounded-xl font-bold text-xs shadow-md shadow-blue-500/20 cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <i className="fa-regular fa-circle-check"></i>
            <span>الاحتفاظ بالمورد في السجل</span>
          </button>

          <button
            type="button"
            onClick={onDelete}
            className="w-full bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 text-rose-600 dark:text-rose-400 py-2.5 rounded-xl font-bold text-xs border border-rose-200 dark:border-rose-900/60 cursor-pointer transition-all flex items-center justify-center gap-2 font-bold"
          >
            <i className="fa-regular fa-trash-can"></i>
            <span>حذف المورد من القائمة</span>
          </button>
        </div>
      </div>
    </div>
  );
};
