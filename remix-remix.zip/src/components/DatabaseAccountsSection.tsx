import React, { useState } from 'react';
import { DatabaseAccount } from '../types';
import {
  testDatabaseConnection,
  syncDatabasesToCloud,
  deleteDatabaseFromCloud,
  auditAllDatabasesSync,
  replicateDataToAllDatabases,
  testAllDatabasesConnection,
  DatabaseSyncReport,
} from '../services/turso';
import { ALDION_DATABASE_CONFIG, BACKUP_SYNC_DATABASES } from '../aldion';
import { useI18n } from '../i18n/index.tsx';

interface DatabaseAccountsSectionProps {
  databases: DatabaseAccount[];
  onRefreshDatabases: () => Promise<void> | void;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const DatabaseAccountsSection: React.FC<DatabaseAccountsSectionProps> = ({
  databases,
  onRefreshDatabases,
  onShowToast,
}) => {
  const { t, numberFormat } = useI18n();

  const [dbName, setDbName] = useState('');
  const [dbUrl, setDbUrl] = useState('');
  const [dbToken, setDbToken] = useState('');
  const [dbDesc, setDbDesc] = useState('');

  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string; latencyMs?: number } | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // In-App Confirm Delete State
  const [dbToDelete, setDbToDelete] = useState<{ id: string; name: string } | null>(null);
  const [isDeletingDb, setIsDeletingDb] = useState(false);

  // Multi-Database Audit & Replication State
  const [isAuditingSync, setIsAuditingSync] = useState(false);
  const [auditReports, setAuditReports] = useState<DatabaseSyncReport[] | null>(null);
  const [allMatched, setAllMatched] = useState<boolean | null>(null);

  const [isReplicating, setIsReplicating] = useState(false);
  const [isTestingAll, setIsTestingAll] = useState(false);

  // 1. تدقيق مطابقة البيانات وأعداد السجلات في جميع القواعد
  const handleAuditAllSync = async () => {
    setIsAuditingSync(true);
    try {
      if (onShowToast) onShowToast('جاري استعلام أعداد السجلات وحالة الاتصال من جميع القواعد الآن...', 'info');
      const res = await auditAllDatabasesSync();
      setAuditReports(res.reports);
      setAllMatched(res.allMatched);
      if (res.allMatched) {
        if (onShowToast) onShowToast('تم التحقق بنجاح: كافة القواعد متطابقة 100% بنفس أعداد البيانات!', 'success');
      } else {
        if (onShowToast) onShowToast('تنبيه: توجد اختلافات في أعداد البيانات بين القواعد. يمكنك الضغط على "مزامنة ونسخ البيانات لجميع القواعد" لتوحيدها فوراً!', 'error');
      }
    } catch (err: any) {
      if (onShowToast) onShowToast('فشل تدقيق القواعد: ' + (err?.message || 'خطأ في الاستعلام'), 'error');
    } finally {
      setIsAuditingSync(false);
    }
  };

  // 2. نسخ ومزامنة كامل بيانات القواعد لتوحيدها 100%
  const handleReplicateAllData = async () => {
    setIsReplicating(true);
    try {
      if (onShowToast) onShowToast('جاري نسخ وتحديث واستنساخ كافة بيانات الديون والأقساط والمستخدمين لجميع القواعد الثانوية...', 'info');
      const res = await replicateDataToAllDatabases();
      if (onShowToast) onShowToast(res.message, 'success');
      // إعادة التدقيق تلقائياً بعد المزامنة
      await handleAuditAllSync();
    } catch (err: any) {
      if (onShowToast) onShowToast('فشل مزامنة ونسخ البيانات: ' + (err?.message || 'خطأ أثناء النسخ'), 'error');
    } finally {
      setIsReplicating(false);
    }
  };

  // 3. فحص الاتصال بجميع القواعد دفعة واحدة
  const handleTestAllConnections = async () => {
    setIsTestingAll(true);
    try {
      if (onShowToast) onShowToast('جاري فحص وتجربة الاتصال بكافة القواعد المسجلة...', 'info');
      const res = await testAllDatabasesConnection();
      const failed = res.results.filter((r) => !r.ok);
      if (failed.length === 0) {
        if (onShowToast) onShowToast('جميع القواعد المسجلة بالنظام متصلة واستجابتها ممتازة! ⚡', 'success');
      } else {
        if (onShowToast) onShowToast(`تنبيه: تعذر الاتصال بـ (${failed.length}) قاعدة.`, 'error');
      }
      // إذا كان هناك تقرير مفتوح، قم بتحديثه
      await handleAuditAllSync();
    } catch (err: any) {
      if (onShowToast) onShowToast('فشل فحص القواعد: ' + (err?.message || 'خطأ غير متوقع'), 'error');
    } finally {
      setIsTestingAll(false);
    }
  };

  // Testing connection for form fields and bootstrapping schema
  const handleTestFormConnection = async () => {
    if (!dbUrl.trim() || !dbToken.trim()) {
      setTestResult({
        ok: false,
        message: 'يرجى كتابة رابط القاعدة ومفتاح التوكن أولاً لفحص الاتصال وتهيئتها',
      });
      return;
    }

    setIsTesting(true);
    setTestResult(null);

    try {
      const result = await testDatabaseConnection(dbUrl, dbToken, true);
      setIsTesting(false);
      setTestResult(result);
    } catch (err: any) {
      setIsTesting(false);
      setTestResult({
        ok: false,
        message: err?.message || 'فشل الاتصال أو تهيئة القاعدة، يرجى التحقق من الرابط والتوكن',
      });
    }
  };

  // Add Database Account and ensure schema is ready
  const handleAddDatabase = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const name = dbName.trim();
    const url = dbUrl.trim();
    const token = dbToken.trim();

    if (!name || !url || !token) {
      setError('يرجى كتابة اسم القاعدة، رابط القاعدة (libsql://...)، ومفتاح التوكن (JWT)');
      return;
    }

    try {
      setIsSaving(true);

      // التأكد من فحص وتهيئة القاعدة أولاً لاستقبال البيانات
      const testRes = await testDatabaseConnection(url, token, true);
      if (!testRes.ok) {
        throw new Error(testRes.message || 'تعذر الاتصال بالقاعدة أو تهيئتها');
      }

      const newAcc: DatabaseAccount = {
        id: 'db_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6),
        name,
        url,
        token,
        description: dbDesc.trim(),
        createdAt: new Date().toISOString(),
      };

      const updated = [...databases, newAcc];
      await syncDatabasesToCloud(updated);

      setDbName('');
      setDbUrl('');
      setDbToken('');
      setDbDesc('');
      setTestResult(null);

      if (onShowToast) {
        onShowToast('تم فحص وتهيئة وحفظ قاعدة البيانات بنجاح، وأصبحت جاهزة لاستقبال البيانات فوراً!', 'success');
      }

      await onRefreshDatabases();
    } catch (err: any) {
      setError(err?.message || 'حدث خطأ أثناء حفظ قاعدة البيانات');
    } finally {
      setIsSaving(false);
    }
  };

  const promptDeleteDb = (id: string, name: string) => {
    setDbToDelete({ id, name });
  };

  const executeDeleteDb = async () => {
    if (!dbToDelete) return;
    try {
      setIsDeletingDb(true);
      await deleteDatabaseFromCloud(dbToDelete.id);
      if (onShowToast) {
        onShowToast(`تم حذف قاعدة البيانات "${dbToDelete.name}" بنجاح`, 'info');
      }
      setDbToDelete(null);
      await onRefreshDatabases();
    } catch (err: any) {
      if (onShowToast) {
        onShowToast('فشل حذف القاعدة: ' + (err?.message || 'حدث خطأ غير متوقع'), 'error');
      }
    } finally {
      setIsDeletingDb(false);
    }
  };

  const handleTestExistingDb = async (db: DatabaseAccount) => {
    if (onShowToast) {
      onShowToast(`جاري فحص وتهيئة الاتصال بالقاعدة: ${db.name}...`, 'info');
    }
    const res = await testDatabaseConnection(db.url, db.token, true);
    if (onShowToast) {
      onShowToast(`${db.name}: ${res.message}`, res.ok ? 'success' : 'error');
    }
  };

  return (
    <div className="space-y-4 text-start">
      {/* Intro Banner */}
      <div className="p-3.5 bg-gradient-to-r from-blue-900 to-indigo-900 text-white rounded-2xl border border-blue-800 shadow-xs space-y-1.5">
        <div className="flex items-center gap-2 font-black text-xs">
          <i className="fa-solid fa-server text-cyan-400"></i>
          <span>تعدد قواعد البيانات (Multi-Tenant Cloud DBs)</span>
        </div>
        <p className="text-[11px] text-blue-100/90 leading-relaxed">
          يمكنك إضافة وتخصيص قواعد بيانات متعددة وتوزيع المدراء والمدراء الفرعيين عليها. يتم حفظ كافة بيانات قواعد البيانات الأخرى مشفرة ومحفوظة آمنًا في القاعدة الرئيسية الحالية.
        </p>
      </div>

      {/* Form: Add New Database */}
      <form onSubmit={handleAddDatabase} className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200/80 pb-2">
          <h3 className="font-bold text-xs text-slate-800 flex items-center gap-2">
            <i className="fa-solid fa-plus-circle text-blue-600"></i>
            <span>إضافة قاعدة بيانات سحابية جديدة</span>
          </h3>
          <span className="text-[10px] text-slate-500 font-medium">Turso / LibSQL</span>
        </div>

        {error && (
          <div className="p-2.5 bg-red-50 text-red-800 border border-red-200 rounded-xl text-xs font-bold flex items-center gap-2">
            <i className="fa-solid fa-circle-exclamation text-red-600"></i>
            <span>{error}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">اسم القاعدة / الفرع:</label>
            <input
              type="text"
              value={dbName}
              onChange={(e) => setDbName(e.target.value)}
              placeholder="مثال: قاعدة فرع النجف الأشرف"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">وصف القاعدة (اختياري):</label>
            <input
              type="text"
              value={dbDesc}
              onChange={(e) => setDbDesc(e.target.value)}
              placeholder="مثال: خاصة بديون وأقساط فرع النجف"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-blue-600"
            />
          </div>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 mb-1">رابط القاعدة (Database URL):</label>
          <input
            type="text"
            value={dbUrl}
            onChange={(e) => setDbUrl(e.target.value)}
            placeholder="libsql://your-db-name-org.turso.io"
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-800 outline-none focus:border-blue-600"
            dir="ltr"
          />
          <p className="text-[10px] text-slate-500 mt-1 flex items-center gap-1">
            <i className="fa-solid fa-circle-info text-blue-500"></i>
            <span>صيغة الرابط الصحيح: <code className="text-blue-700 font-mono bg-blue-50 px-1 py-0.5 rounded">libsql://db-name-org.turso.io</code> (تجنب نسخ رابط متصفح app.turso.tech)</span>
          </p>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-700 mb-1">مفتاح التوكن (Auth Token):</label>
          <textarea
            rows={2}
            value={dbToken}
            onChange={(e) => setDbToken(e.target.value)}
            placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-800 outline-none focus:border-blue-600 resize-none"
            dir="ltr"
          ></textarea>
        </div>

        {/* Test Result Feedback */}
        {testResult && (
          <div
            className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-between gap-2 ${
              testResult.ok
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <i className={`fa-solid ${testResult.ok ? 'fa-circle-check text-emerald-600' : 'fa-circle-xmark text-rose-600'}`}></i>
              <span>{testResult.message}</span>
            </div>
            {testResult.latencyMs !== undefined && (
              <span className="font-mono text-[10px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md border border-emerald-300">
                {testResult.latencyMs}ms
              </span>
            )}
          </div>
        )}

        {/* Action Buttons: Test Connection & Save Database */}
        <div className="flex items-center gap-2 pt-1 flex-wrap sm:flex-nowrap">
          <button
            type="button"
            onClick={handleTestFormConnection}
            disabled={isTesting || !dbUrl.trim() || !dbToken.trim()}
            className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 disabled:opacity-50 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5"
            title="فحص الاتصال وتجهيز كافة جداول الديون والأقساط"
          >
            {isTesting ? (
              <i className="fa-solid fa-spinner fa-spin text-blue-600"></i>
            ) : (
              <i className="fa-solid fa-wand-magic-sparkles text-blue-600"></i>
            )}
            <span>{isTesting ? 'جاري الفحص والتهيئة...' : 'فحص وتهيئة القاعدة'}</span>
          </button>

          <button
            type="submit"
            disabled={isSaving}
            className="flex-1 py-2.5 px-4 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow-xs transition-all cursor-pointer flex items-center justify-center gap-1.5"
          >
            {isSaving ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-floppy-disk"></i>
            )}
            <span>{isSaving ? 'جاري التجهيز والحفظ...' : 'حفظ إضافة القاعدة'}</span>
          </button>
        </div>
      </form>

      {/* Global Master Controls for All Databases */}
      <div className="bg-slate-100/90 border border-slate-200/90 p-3.5 rounded-2xl space-y-2.5">
        <div className="flex items-center justify-between text-xs font-bold text-slate-800">
          <span className="flex items-center gap-2">
            <i className="fa-solid fa-sliders text-blue-600"></i>
            <span>لوحة التحكم والفحص الشامل لجميع القواعد ({databases.length + 1 + (BACKUP_SYNC_DATABASES?.length || 0)})</span>
          </span>
          <span className="text-[10px] text-slate-500 font-medium">مزامنة تلقائية وتحول فوري</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {/* Button 1: Test All DB Connections */}
          <button
            type="button"
            onClick={handleTestAllConnections}
            disabled={isTestingAll}
            className="py-2.5 px-3 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-bold text-xs rounded-xl shadow-2xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            title="فحص سرعة استجابة كافة القواعد المسجلة دفعة واحدة"
          >
            {isTestingAll ? (
              <i className="fa-solid fa-spinner fa-spin text-blue-600"></i>
            ) : (
              <i className="fa-solid fa-bolt text-amber-500"></i>
            )}
            <span>{isTestingAll ? 'جاري الفحص الشامل...' : 'فحص اتصال جميع القواعد'}</span>
          </button>

          {/* Button 2: Audit All DB Records Match */}
          <button
            type="button"
            onClick={handleAuditAllSync}
            disabled={isAuditingSync}
            className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            title="استعلام وقراءة أعداد السجلات من القواعد وإتاحة مطابقتها حيّة"
          >
            {isAuditingSync ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-scale-balanced"></i>
            )}
            <span>{isAuditingSync ? 'جاري الاستعلام والتدقيق...' : 'تدقيق مطابقة السجلات'}</span>
          </button>

          {/* Button 3: Replicate & Copy Data to All Secondary DBs */}
          <button
            type="button"
            onClick={handleReplicateAllData}
            disabled={isReplicating}
            className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-2xs transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
            title="نسخ واستنساخ وتحديث كامل بيانات الديون والأقساط والمستخدمين لجميع القواعد الثانوية فوراً"
          >
            {isReplicating ? (
              <i className="fa-solid fa-spinner fa-spin"></i>
            ) : (
              <i className="fa-solid fa-rotate text-white"></i>
            )}
            <span>{isReplicating ? 'جاري نسخ البيانات لجميع القواعد...' : 'مزامنة ونسخ البيانات الآن'}</span>
          </button>
        </div>
      </div>

      {/* Full Audit Detailed Table Report */}
      {auditReports && (
        <div className="bg-white border border-indigo-200 rounded-2xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between border-b border-indigo-100 pb-2">
            <div className="flex items-center gap-2 font-bold text-xs text-slate-900">
              <i className="fa-solid fa-list-check text-indigo-600"></i>
              <span>تقرير مطابقة وفحص أعداد السجلات المباشرة (Live Audit Report)</span>
            </div>
            <span
              className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                allMatched
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}
            >
              {allMatched ? 'جميع القواعد متطابقة 100% ✅' : 'توجد فروقات أعداد بين القواعد ⚠️'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-start text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-[11px] font-bold">
                  <th className="p-2 text-center">الرقم</th>
                  <th className="p-2">اسم القاعدة</th>
                  <th className="p-2 text-center">الحالة</th>
                  <th className="p-2 text-center">المستخدمين</th>
                  <th className="p-2 text-center">المدينين</th>
                  <th className="p-2 text-center">الأقساط</th>
                  <th className="p-2 text-center">الاستجابة</th>
                  <th className="p-2 text-center">المطابقة</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[11px] font-medium">
                {auditReports.map((report, idx) => (
                  <tr key={report.id} className={report.isPrimary ? 'bg-cyan-50/40 font-bold' : 'hover:bg-slate-50/80'}>
                    <td className="p-2 text-center text-slate-500 font-mono">#{idx + 1}</td>
                    <td className="p-2">
                      <div className="font-bold text-slate-800 flex items-center gap-1.5">
                        <span>{report.name}</span>
                        {report.isPrimary && (
                          <span className="text-[9px] bg-cyan-100 text-cyan-800 px-1.5 py-0.2 rounded-md">الرئيسية</span>
                        )}
                      </div>
                      <div className="text-[9.5px] font-mono text-slate-400 truncate max-w-[200px]" dir="ltr">
                        {report.rawUrl || report.url}
                      </div>
                    </td>
                    <td className="p-2 text-center">
                      {report.ok ? (
                        <span className="inline-flex items-center gap-1 text-emerald-700 font-bold text-[10px] bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                          متصلة
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-rose-700 font-bold text-[10px] bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200">
                          عطل/تعذر
                        </span>
                      )}
                    </td>
                    <td className="p-2 text-center font-mono font-bold text-slate-800">{report.users}</td>
                    <td className="p-2 text-center font-mono font-bold text-cyan-700">{report.debtors}</td>
                    <td className="p-2 text-center font-mono font-bold text-indigo-700">{report.installments}</td>
                    <td className="p-2 text-center font-mono text-slate-500 text-[10px]">
                      {report.latencyMs > 0 ? `${report.latencyMs}ms` : '-'}
                    </td>
                    <td className="p-2 text-center">
                      {report.isPrimary ? (
                        <span className="text-[10px] text-cyan-800 font-extrabold bg-cyan-100 px-2 py-0.5 rounded-full">
                          المرجع
                        </span>
                      ) : report.matchedWithPrimary ? (
                        <span className="text-[10px] text-emerald-800 font-black bg-emerald-100 px-2 py-0.5 rounded-full">
                          مطابقة ✅
                        </span>
                      ) : (
                        <span className="text-[10px] text-amber-800 font-black bg-amber-100 px-2 py-0.5 rounded-full">
                          تغير أعداد ⚠️
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Ordered List of Configured Databases */}
      <div className="space-y-3 pt-2">
        <h4 className="font-bold text-xs text-slate-700 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <i className="fa-solid fa-list-ol text-blue-600"></i>
            <span>قواعد البيانات المسجلة بالترتيب والتسلسل ({databases.length + 1 + (BACKUP_SYNC_DATABASES?.length || 0)}):</span>
          </span>
        </h4>

        {/* 1. Primary Database Card */}
        <div className="p-3.5 bg-cyan-50/70 border border-cyan-200 rounded-2xl space-y-2.5 shadow-2xs">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-xl bg-cyan-600 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-xs">
                #1
              </div>
              <div className="truncate text-start">
                <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                  <span>القاعدة 1: القاعدة الرئيسية (الافتراضية)</span>
                  <span className="text-[9.5px] bg-cyan-100 text-cyan-800 font-extrabold px-2 py-0.2 rounded-full border border-cyan-300">
                    سجل القواعد والمرجع الرئيسي
                  </span>
                </div>
                <p className="text-[10px] text-slate-500 truncate mt-0.5 font-mono" dir="ltr">
                  {ALDION_DATABASE_CONFIG.rawUrl || ALDION_DATABASE_CONFIG.url}
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={async () => {
                if (onShowToast) onShowToast('جاري فحص الاتصال بالقاعدة الرئيسية...', 'info');
                try {
                  const res = await testDatabaseConnection(
                    ALDION_DATABASE_CONFIG.url,
                    ALDION_DATABASE_CONFIG.token
                  );
                  if (onShowToast) onShowToast(res.message, res.ok ? 'success' : 'error');
                } catch (e: any) {
                  if (onShowToast) onShowToast('فشل فحص القاعدة الرئيسية: ' + (e?.message || 'خطأ في الاتصال'), 'error');
                }
              }}
              className="px-3 py-1.5 bg-white hover:bg-cyan-100 text-cyan-900 border border-cyan-300 rounded-xl text-[11px] font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1 shadow-2xs"
            >
              <i className="fa-solid fa-bolt text-cyan-600"></i>
              <span>فحص الاتصال</span>
            </button>
          </div>
        </div>

        {/* 2. Secondary Standby / Dual-Sync Database Cards */}
        {BACKUP_SYNC_DATABASES.map((bDb, idx) => {
          const dbIndexNumber = idx + 2; // #2, #3...
          const auditInfo = auditReports?.find((r) => r.rawUrl === bDb.rawUrl || r.url === bDb.url);

          return (
            <div key={idx} className="p-3.5 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-2.5 shadow-2xs">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-xs">
                    #{dbIndexNumber}
                  </div>
                  <div className="truncate text-start">
                    <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                      <span>القاعدة {dbIndexNumber}: {bDb.name}</span>
                      <span className="text-[9.5px] bg-indigo-100 text-indigo-800 font-extrabold px-2 py-0.2 rounded-full border border-indigo-300">
                        مزامنة لحظية وتحول تلقائي
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-500 truncate mt-0.5 font-mono" dir="ltr">
                      {bDb.rawUrl || bDb.url}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={async () => {
                      if (onShowToast) onShowToast(`جاري فحص الاتصال بـ ${bDb.name}...`, 'info');
                      try {
                        const res = await testDatabaseConnection(bDb.url, bDb.token);
                        if (onShowToast) onShowToast(`${bDb.name}: ${res.message}`, res.ok ? 'success' : 'error');
                      } catch (e: any) {
                        if (onShowToast) onShowToast(`فشل فحص ${bDb.name}: ` + (e?.message || 'خطأ في الاتصال'), 'error');
                      }
                    }}
                    className="px-3 py-1.5 bg-white hover:bg-indigo-100 text-indigo-900 border border-indigo-300 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs"
                  >
                    <i className="fa-solid fa-bolt text-indigo-600"></i>
                    <span>فحص الاتصال</span>
                  </button>
                </div>
              </div>

              {auditInfo && (
                <div className="p-2.5 bg-white rounded-xl border border-indigo-200 flex items-center justify-between text-[11px] font-bold text-slate-800">
                  <div className="flex items-center gap-3">
                    <span>المدينين: <strong className="text-cyan-700">{auditInfo.debtors}</strong></span>
                    <span>الأقساط: <strong className="text-indigo-700">{auditInfo.installments}</strong></span>
                    <span>المستخدمين: <strong className="text-slate-800">{auditInfo.users}</strong></span>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${auditInfo.matchedWithPrimary ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                    {auditInfo.matchedWithPrimary ? 'نفس بيانات الرئيسية 100% ✅' : 'تغير أعداد ⚠️'}
                  </span>
                </div>
              )}
            </div>
          );
        })}

        {/* 3. Custom Registered Databases Cards */}
        {databases.map((db, idx) => {
          const customDbNumber = 1 + (BACKUP_SYNC_DATABASES?.length || 0) + idx + 1; // #4, #5...
          const auditInfo = auditReports?.find((r) => r.id === db.id || r.url === db.url);

          return (
            <div
              key={db.id}
              className="p-3.5 bg-white border border-slate-200 rounded-2xl space-y-2 hover:border-slate-300 transition-all shadow-2xs"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-slate-800 text-white flex items-center justify-center font-black text-xs shrink-0">
                    #{customDbNumber}
                  </div>
                  <div className="truncate text-start">
                    <div className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
                      <span>القاعدة {customDbNumber}: {db.name}</span>
                      {typeof db.description === 'string' && db.description.trim() ? (
                        <span className="text-[10px] text-slate-500 font-normal">({db.description.trim()})</span>
                      ) : null}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono truncate mt-0.5" dir="ltr">
                      {db.url}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleTestExistingDb(db)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1"
                    title="فحص الاتصال بهذه القاعدة"
                  >
                    <i className="fa-solid fa-plug text-blue-600"></i>
                    <span>فحص</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => promptDeleteDb(db.id, db.name)}
                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 active:scale-95"
                    title="حذف هذه القاعدة"
                  >
                    <i className="fa-solid fa-trash-can text-rose-600"></i>
                    <span>حذف</span>
                  </button>
                </div>
              </div>

              {auditInfo && (
                <div className="p-2 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-[11px] font-bold text-slate-800">
                  <div className="flex items-center gap-3">
                    <span>المدينين: <strong className="text-cyan-700">{auditInfo.debtors}</strong></span>
                    <span>الأقساط: <strong className="text-indigo-700">{auditInfo.installments}</strong></span>
                    <span>المستخدمين: <strong className="text-slate-800">{auditInfo.users}</strong></span>
                  </div>
                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${auditInfo.matchedWithPrimary ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                    {auditInfo.matchedWithPrimary ? 'مطابقة ✅' : 'تغير أعداد ⚠️'}
                  </span>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal for Deleting Database */}
      {dbToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => !isDeletingDb && setDbToDelete(null)}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-5 shadow-2xl border border-slate-200 text-start space-y-4 animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
            dir="rtl"
          >
            {/* Modal Header */}
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center text-lg shrink-0 shadow-2xs">
                <i className="fa-solid fa-triangle-exclamation"></i>
              </div>
              <div className="min-w-0">
                <h3 className="font-extrabold text-sm text-slate-900">
                  تأكيد حذف قاعدة البيانات
                </h3>
                <p className="text-xs text-slate-500 truncate mt-0.5">
                  إزالة إعدادات الربط من النظام
                </p>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-3.5 bg-rose-50/70 border border-rose-200/80 rounded-2xl space-y-2 text-xs text-rose-950">
              <p className="font-bold">
                هل أنت متأكد من رغبتك في حذف قاعدة البيانات:
              </p>
              <div className="p-2.5 bg-white/90 rounded-xl font-black text-slate-900 border border-rose-200 text-xs flex items-center gap-2">
                <i className="fa-solid fa-database text-rose-600"></i>
                <span className="truncate">{dbToDelete.name}</span>
              </div>
              <p className="text-[11px] text-rose-700 leading-relaxed">
                ملاحظة: سيتم إزالة ربط القاعدة من التطبيق، ولن يتم حذف البيانات الفعلية الموجودة على سيرفر Turso السحابي.
              </p>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-2.5 pt-1">
              <button
                type="button"
                onClick={() => setDbToDelete(null)}
                disabled={isDeletingDb}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              >
                إلغاء التراجع
              </button>

              <button
                type="button"
                onClick={executeDeleteDb}
                disabled={isDeletingDb}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer flex items-center gap-1.5 disabled:opacity-50 active:scale-95"
              >
                {isDeletingDb ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin text-xs"></i>
                    <span>جاري الحذف...</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-trash-can text-xs"></i>
                    <span>نعم، تأكيد الحذف</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
