import React, { useState, useEffect, useRef, useCallback } from 'react';
import { AppLayoutTheme, User } from '../types';
import { formatNumber, formatDateArabic, getSubscriptionDaysRemaining, isSubscriptionExpired } from '../utils/formatters';
import { getUserBranchDisplayName, getUserRoleDisplayName } from '../utils/userUtils';
import { PWAInstallButton } from './PWAInstallButton';
import { useI18n } from '../i18n/index.tsx';

export type HeaderMode = 'debts' | 'installments' | 'suppliers';

interface HeaderCardProps {
  currentUser: User;
  debtorsCount: number;
  totalAmount: number;
  installmentsCount?: number;
  totalInstallmentsRemaining?: number;
  suppliersCount?: number;
  totalSuppliersRemaining?: number;
  headerMode?: HeaderMode;
  mode?: HeaderMode;
  onHeaderModeChange?: (mode: HeaderMode) => void;
  onModeChange?: (mode: HeaderMode) => void;
  onLogout: () => void;
  isSaving?: boolean;
  searchTerm?: string;
  onSearchChange?: (val: string) => void;
  onSecretAdminUnlock?: () => void;
  layoutTheme?: AppLayoutTheme;
  onToggleTheme?: () => void;
}

export const HeaderCard: React.FC<HeaderCardProps> = React.memo(({
  currentUser,
  debtorsCount,
  totalAmount,
  installmentsCount = 0,
  totalInstallmentsRemaining = 0,
  suppliersCount = 0,
  totalSuppliersRemaining = 0,
  headerMode,
  mode,
  onHeaderModeChange,
  onModeChange,
  onLogout,
  isSaving = false,
  searchTerm = '',
  onSearchChange,
  onSecretAdminUnlock,
  layoutTheme = 'fintech',
  onToggleTheme,
}) => {
  const { t, formatMoney, getCurrencySymbol, numberFormat } = useI18n();
  const currentMode: HeaderMode = headerMode || mode || 'debts';
  const isInstallments = currentMode === 'installments';
  const isSuppliers = currentMode === 'suppliers';
  const canSwitchModules =
    currentUser.role === 'admin' ||
    !currentUser.allowedModules ||
    currentUser.allowedModules === 'both';

  const handleSwitchMode = (newMode: HeaderMode) => {
    if (onHeaderModeChange) onHeaderModeChange(newMode);
    if (onModeChange) onModeChange(newMode);
    setIsDropdownOpen(false);
  };

  const [isSearchOpen, setIsSearchOpen] = useState(Boolean(searchTerm));
  const [localSearchInput, setLocalSearchInput] = useState(searchTerm);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const debounceTimerRef = useRef<any>(null);

  const [secretClicks, setSecretClicks] = useState(0);
  const secretTimerRef = useRef<any>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync with external searchTerm if changed externally
  useEffect(() => {
    setLocalSearchInput(searchTerm);
    if (searchTerm) {
      setIsSearchOpen(true);
    }
  }, [searchTerm]);

  const handleSearchInputChange = (val: string) => {
    setLocalSearchInput(val);
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    debounceTimerRef.current = setTimeout(() => {
      if (onSearchChange) {
        onSearchChange(val);
      }
    }, 180);
  };

  const handleClearSearch = () => {
    setLocalSearchInput('');
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current);
    if (onSearchChange) onSearchChange('');
  };

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleTitleTripleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSecretClicks((prev) => {
      const next = prev + 1;
      if (next >= 3) {
        if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
        if (onSecretAdminUnlock) {
          onSecretAdminUnlock();
        }
        return 0;
      }
      if (secretTimerRef.current) clearTimeout(secretTimerRef.current);
      secretTimerRef.current = setTimeout(() => {
        setSecretClicks(0);
      }, 1200);
      return next;
    });
  };

  // When search is opened, focus the input
  useEffect(() => {
    if (isSearchOpen && searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, [isSearchOpen]);

  const handleToggleSearch = () => {
    if (isSearchOpen) {
      handleClearSearch();
      setIsSearchOpen(false);
    } else {
      setIsSearchOpen(true);
    }
  };

  const currentTotal = isSuppliers ? totalSuppliersRemaining : isInstallments ? totalInstallmentsRemaining : totalAmount;
  const formattedMoneyString = formatMoney(currentTotal);
  const digitsCount = String(Math.round(Math.abs(currentTotal))).length;

  return (
    <div
      id="mainHeaderCard"
      className={`text-white px-3.5 sm:px-4 header-safe-top pb-3.5 sm:pb-4 rounded-b-3xl border-b relative z-20 text-start select-none transition-colors duration-300 ${
        isSuppliers
          ? 'bg-gradient-to-br from-amber-950 via-amber-900 to-slate-950 border-amber-800/60'
          : isInstallments
          ? 'bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-950 border-emerald-800/60'
          : 'bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 border-slate-800/80'
      }`}
    >
      {/* Row 1: Branch Name & Action Controls */}
      <div className="flex justify-between items-center gap-2 relative z-30 mb-2.5">
        {/* Branch Name Display (Click 3 times for secret admin) */}
        <div
          id="headerBranchNameDisplay"
          onClick={handleTitleTripleClick}
          className="flex items-center gap-2 cursor-pointer select-none py-0.5 group min-w-0 flex-1 text-start"
          title={getUserBranchDisplayName(currentUser, t)}
        >
          <div className="text-start min-w-0 flex-1">
            <h1 className="font-black text-xs sm:text-sm md:text-base text-white tracking-tight truncate leading-tight">
              {getUserBranchDisplayName(currentUser, t)}
            </h1>
            <span className="text-[10px] text-slate-400 font-medium block truncate leading-tight mt-0.5">
              {getUserRoleDisplayName(currentUser, t)}
            </span>
          </div>
        </div>

        {/* Controls: PWA Install, Search Button */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          <PWAInstallButton />

          {/* Search Button */}
          {onSearchChange && (
            <button
              id="headerSearchBtn"
              type="button"
              onClick={handleToggleSearch}
              title={isSearchOpen ? t('common.close', 'إغلاق البحث') : t('common.search', 'بحث')}
              className={`w-7.5 h-7.5 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs transition-all cursor-pointer relative border ${
                isSearchOpen || localSearchInput || searchTerm
                  ? isInstallments
                    ? 'bg-emerald-600 border-emerald-400 text-white shadow-md shadow-emerald-600/30 font-bold scale-105'
                    : 'bg-blue-600 border-blue-400 text-white shadow-md shadow-blue-600/30 font-bold scale-105'
                  : 'bg-white/8 hover:bg-white/15 border-white/10 text-slate-300 active:scale-95'
              }`}
            >
              <i className="fa-solid fa-magnifying-glass text-[11px] sm:text-[11.5px]"></i>
              {(localSearchInput || searchTerm) && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900 animate-pulse"></span>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Expandable Live Search Input */}
      {isSearchOpen && onSearchChange && (
        <div className="relative z-10 mb-2.5 animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="relative flex items-center">
            <input
              ref={searchInputRef}
              type="text"
              id="headerSearchInput"
              className={`w-full pl-8 pr-9 py-2 bg-slate-900/90 text-white placeholder:text-slate-400 rounded-xl text-xs font-medium outline-none shadow-inner border border-slate-700/80 transition-all ${
                isInstallments
                  ? 'focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30'
                  : 'focus:border-blue-500 focus:ring-2 focus:ring-blue-500/30'
              }`}
              placeholder={isInstallments ? t('common.searchPlaceholder', "ابحث بالاسم أو السلعة أو الهاتف...") : t('common.searchPlaceholder', "ابحث بالاسم أو رقم الهاتف...")}
              value={localSearchInput}
              onChange={(e) => handleSearchInputChange(e.target.value)}
            />
            <i className="fa-solid fa-magnifying-glass absolute right-3 text-slate-400 text-xs pointer-events-none"></i>
            {localSearchInput ? (
              <button
                type="button"
                onClick={handleClearSearch}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title={t('common.clear', "مسح البحث")}
              >
                <i className="fa-solid fa-xmark text-xs"></i>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleToggleSearch}
                className="absolute left-2.5 text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
                title={t('common.close', "إغلاق البحث")}
              >
                <i className="fa-solid fa-chevron-up text-[10px]"></i>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Row 2: Outstanding Balance / Remaining Installments / Suppliers & Compact Dropdown */}
      <div className="flex items-center justify-between gap-2 relative z-10 pt-2 border-t border-white/10 min-w-0">
        <div className="text-start min-w-0 flex-1">
          <div className="text-[10px] sm:text-[10.5px] text-slate-400 font-medium flex items-center gap-1.5 truncate">
            <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${isSuppliers ? 'bg-amber-400' : isInstallments ? 'bg-emerald-400' : 'bg-blue-400'}`}></span>
            <span className="truncate">{isSuppliers ? 'الموردين' : isInstallments ? t('header.totalInstallments', 'إجمالي الأقساط المتبقية') : t('header.totalDebts', 'إجمالي الديون القائمة (لك)')}</span>
          </div>
          <div
            className={`font-bold tracking-tight font-mono text-white leading-tight mt-0.5 truncate select-all text-start ${
              digitsCount > 10
                ? 'text-[12px] sm:text-[13px] md:text-sm'
                : digitsCount > 7
                ? 'text-[13px] sm:text-[14px] md:text-[15px]'
                : 'text-[14.5px] sm:text-[15.5px] md:text-base'
            }`}
            id="totalAmount"
            title={formattedMoneyString}
          >
            <span className="truncate inline-block text-start">{formattedMoneyString}</span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {isSaving && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-lg bg-white/5 border border-white/10 text-slate-300 text-[10px] sm:text-[11px]">
              <i className="fa-solid fa-spinner animate-spin text-[10px] text-blue-400"></i>
              <span className="hidden xs:inline">{t('header.savingCloud', 'جارِ الحفظ...')}</span>
            </div>
          )}

          {/* COMPACT BOTTOM-LEFT DROPDOWN (ONLY IF ACCESSIBLE TO BOTH DEPARTMENTS) */}
          {canSwitchModules && (
            <div className="relative z-30" ref={dropdownRef}>
              <button
                type="button"
                id="headerModeDropdownBtn"
                onClick={() => setIsDropdownOpen((prev) => !prev)}
                className={`px-2 sm:px-2.5 py-1 rounded-xl flex items-center gap-1 sm:gap-1.5 border shadow-xs transition-all cursor-pointer text-[11px] sm:text-xs font-bold select-none active:scale-95 whitespace-nowrap ${
                  isSuppliers
                    ? 'bg-amber-900/90 hover:bg-amber-800 border-amber-400/60 text-amber-100 ring-1 ring-amber-400/30'
                    : isInstallments
                    ? 'bg-emerald-900/90 hover:bg-emerald-800 border-emerald-400/60 text-emerald-100 ring-1 ring-emerald-400/30'
                    : 'bg-slate-800/95 hover:bg-slate-700 border-blue-400/50 text-blue-100 ring-1 ring-blue-400/25'
                }`}
                title={t('common.filter', "تبديل القسم المعروض")}
              >
                <div className={`w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-md flex items-center justify-center text-[9px] sm:text-[10px] shrink-0 ${
                  isSuppliers ? 'bg-amber-400 text-slate-950 font-black' : isInstallments ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-blue-500 text-white font-black'
                }`}>
                  <i className={`fa-solid ${isSuppliers ? 'fa-truck-field' : isInstallments ? 'fa-clock-rotate-left' : 'fa-users'}`}></i>
                </div>
                <span>{isSuppliers ? 'الموردين' : isInstallments ? t('nav.installments', 'الأقساط') : t('debts.title', 'الديون')}</span>
              </button>

              {/* Dropdown Options Menu */}
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-1.5 w-52 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 space-y-1 text-start">
                  <div className="px-2 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-800/80">
                    {t('common.actions', 'تبديل عرض القسم')}:
                  </div>

                  {/* Option 1: Debts */}
                  <button
                    type="button"
                    id="selectModeDebtsBtn"
                    onClick={() => handleSwitchMode('debts')}
                    className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                      currentMode === 'debts'
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="fa-solid fa-users text-xs text-blue-400"></i>
                      <span>{t('header.debtsMode', 'دفتر الديون (لك)')}</span>
                    </div>
                    {currentMode === 'debts' && <i className="fa-solid fa-check text-xs"></i>}
                  </button>

                  {/* Option 2: Installments */}
                  <button
                    type="button"
                    id="selectModeInstallmentsBtn"
                    onClick={() => handleSwitchMode('installments')}
                    className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                      currentMode === 'installments'
                        ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="fa-solid fa-clock-rotate-left text-xs text-emerald-400"></i>
                      <span>{t('header.installmentsMode', 'نظام الأقساط')}</span>
                    </div>
                    {currentMode === 'installments' && <i className="fa-solid fa-check text-xs"></i>}
                  </button>

                  {/* Option 3: Suppliers */}
                  <button
                    type="button"
                    id="selectModeSuppliersBtn"
                    onClick={() => handleSwitchMode('suppliers')}
                    className={`w-full px-2.5 py-2 rounded-xl text-xs font-bold flex items-center justify-between transition-all cursor-pointer ${
                      currentMode === 'suppliers'
                        ? 'bg-gradient-to-r from-amber-600 to-orange-600 text-white shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <i className="fa-solid fa-truck-field text-xs text-amber-400"></i>
                      <span>الموردين</span>
                    </div>
                    {currentMode === 'suppliers' && <i className="fa-solid fa-check text-xs"></i>}
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
});

HeaderCard.displayName = 'HeaderCard';
