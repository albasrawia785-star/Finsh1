import React from 'react';
import { Debtor } from '../types';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';

interface SettleCompleteModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  onKeep: () => void;
  onDelete: () => void;
  isLoading?: boolean;
}

export const SettleCompleteModal: React.FC<SettleCompleteModalProps> = ({
  isOpen,
  debtor,
  onKeep,
  onDelete,
  isLoading = false,
}) => {
  const { t, currency } = useI18n();

  if (!isOpen || !debtor) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 select-none">
      <div
        className="bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl relative border border-slate-100 text-center animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Success / Settlement Icon */}
        <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl mx-auto mb-3.5 shadow-sm border border-emerald-100">
          <i className="fa-solid fa-circle-check"></i>
        </div>

        <span className="text-[11px] font-bold bg-emerald-100/70 text-emerald-800 px-3 py-1 rounded-full inline-block mb-2">
          {t('status.debtFree', 'خالي من الدين')}
        </span>

        <h3 className="font-black text-base text-slate-800 mb-1.5">
          {t('debts.fullDebtSettledTitle', 'تم تسديد كامل المبلغ')}
        </h3>

        <p className="text-xs text-slate-500 mb-2 leading-relaxed">
          {t('debts.fullDebtSettledDesc', 'قام المدين بتسديد كافة المستحقات المترتبة بذمته بالكامل وأصبح رصيده')} <span className="font-bold text-slate-800">{debtor.name}</span> <span className="font-mono font-bold text-emerald-600">0 {currency}</span>.
        </p>

        <p className="text-xs font-semibold text-slate-600 mb-5 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
          {t('debts.settleKeepOrDeletePrompt', 'هل ترغب في الاحتفاظ بالمدين في سجلك (ضمن قائمة خالي من الدين)، أم حذفه نهائياً؟')}
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={onKeep}
            disabled={isLoading}
            className="w-full bg-blue-600 hover:bg-blue-700 active:scale-95 text-white py-2.5 rounded-xl font-bold text-xs shadow-md shadow-blue-500/20 cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <i className="fa-regular fa-circle-check"></i>
            <span>{t('debts.keepDebtorRecord', 'الاحتفاظ بالمدين في السجل')}</span>
          </button>

          <button
            type="button"
            onClick={onDelete}
            disabled={isLoading}
            className="w-full bg-rose-50 hover:bg-rose-100 active:scale-95 text-rose-600 py-2.5 rounded-xl font-bold text-xs border border-rose-200 cursor-pointer transition-all flex items-center justify-center gap-2"
          >
            <i className="fa-regular fa-trash-can"></i>
            <span>{t('debtors.deleteDebtorPermanently', 'حذف المدين نهائياً')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
