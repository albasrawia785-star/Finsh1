import React from 'react';
import { useI18n } from '../i18n/index.tsx';
import { formatNumber } from '../utils/formatters';

export type SupplierFilterType = 'all' | 'active' | 'settled';

interface SupplierControlsProps {
  searchTerm?: string;
  filter: SupplierFilterType;
  onFilterChange: (f: SupplierFilterType) => void;
  totalCount: number;
  activeCount: number;
  settledCount: number;
  displayedCount?: number;
}

export const SupplierControls: React.FC<SupplierControlsProps> = React.memo(({
  searchTerm,
  filter,
  onFilterChange,
  totalCount,
  activeCount,
  settledCount,
  displayedCount,
}) => {
  const { t, numberFormat } = useI18n();

  const filterTabs: {
    id: SupplierFilterType;
    label: string;
    count: number;
    icon: string;
    activeIconColor: string;
    badgeActiveColor: string;
  }[] = [
    {
      id: 'all',
      label: 'الكل',
      count: totalCount,
      icon: 'fa-solid fa-layer-group',
      activeIconColor: 'text-blue-600',
      badgeActiveColor: 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300',
    },
    {
      id: 'active',
      label: 'عليك دين',
      count: activeCount,
      icon: 'fa-solid fa-truck-field',
      activeIconColor: 'text-amber-600',
      badgeActiveColor: 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300',
    },
    {
      id: 'settled',
      label: 'خالية من الدين',
      count: settledCount,
      icon: 'fa-solid fa-circle-check',
      activeIconColor: 'text-emerald-600',
      badgeActiveColor: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300',
    },
  ];

  return (
    <div className="bg-slate-50 dark:bg-slate-900 px-4 pt-2.5 pb-2.5 flex flex-col gap-2 select-none border-b border-slate-200 dark:border-slate-800 relative z-10">
      {/* Segmented Filter Bar */}
      <div className="w-full bg-slate-200/80 dark:bg-slate-800/80 p-1.5 rounded-2xl flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth border border-slate-200 dark:border-slate-700 touch-pan-x">
        {filterTabs.map((tab) => {
          const isActive = filter === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onFilterChange(tab.id)}
              className={`flex-1 py-2 px-2.5 sm:px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 sm:gap-2 transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-[0_2px_8px_rgba(0,0,0,0.08)] border border-slate-200/80 dark:border-slate-700 scale-[1.01]'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-white/50 dark:hover:bg-slate-800/50'
              }`}
            >
              <i className={`${tab.icon} text-xs ${isActive ? tab.activeIconColor : 'text-slate-400'}`}></i>
              <span className="text-xs font-bold tracking-tight">{tab.label}</span>
              <span
                className={`text-[11px] font-mono px-2 py-0.5 rounded-full font-bold transition-colors ${
                  isActive ? tab.badgeActiveColor : 'bg-slate-300/60 dark:bg-slate-700/80 text-slate-700 dark:text-slate-300'
                }`}
              >
                {formatNumber(tab.count, numberFormat)}
              </span>
            </button>
          );
        })}
      </div>

      {/* Optional Search Indicator */}
      {searchTerm && displayedCount !== undefined && (
        <div className="flex items-center gap-1.5 px-1 text-xs text-slate-500 dark:text-slate-400 font-medium select-none">
          <i className="fa-solid fa-magnifying-glass text-[11px] text-blue-500"></i>
          <span className="text-[11.5px] text-slate-600 dark:text-slate-300">
            {t('common.search', 'نتائج البحث')}: <span className="font-mono font-extrabold text-slate-900 dark:text-white">{formatNumber(displayedCount, numberFormat)}</span>
          </span>
        </div>
      )}
    </div>
  );
});

SupplierControls.displayName = 'SupplierControls';
