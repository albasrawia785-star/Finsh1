import React, { useState, useMemo } from 'react';
import { Debtor, DebtorTransaction, User } from '../types';
import {
  formatNumber,
  formatIraqiPhoneNumber,
  formatDateDigits,
} from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface DebtorShareModalProps {
  isOpen: boolean;
  debtor: Debtor | null;
  currentUser?: User | null;
  storeName?: string;
  onClose: () => void;
  onShowToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const DebtorShareModal: React.FC<DebtorShareModalProps> = ({
  isOpen,
  debtor,
  currentUser,
  storeName,
  onClose,
  onShowToast,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const [shareMode, setShareMode] = useState<'statement' | 'summary'>('statement');
  const [customPhone, setCustomPhone] = useState('');
  const [copied, setCopied] = useState(false);

  // Sync phone when debtor changes
  React.useEffect(() => {
    if (debtor?.phone) {
      setCustomPhone(debtor.phone);
    } else {
      setCustomPhone('');
    }
    setCopied(false);
  }, [debtor]);

  const defaultStoreName = t('common.appName', 'دفتر الديون والأقساط');
  const activeStoreName = storeName?.trim() || defaultStoreName;

  // Generate formatted text based on mode without any emojis
  const generatedText = useMemo(() => {
    if (!debtor) return '';

    const currentBalance = debtor.amount || 0;
    const titleHeader = `*${activeStoreName}*`;
    const clientName = (debtor.name || '').trim();
    const currSym = getCurrencySymbol();

    // Build history list
    const rawHistory: DebtorTransaction[] = debtor.history && debtor.history.length > 0
      ? debtor.history
      : [
          {
            id: `initial-${debtor.id}`,
            debtorId: debtor.id,
            type: 'initial',
            amount: debtor.amount,
            balanceAfter: debtor.amount,
            date: debtor.createdAt || new Date().toISOString(),
            description: t('debtorShare.initialType', 'رصيد أولي'),
          },
        ];

    const sortedHistory = [...rawHistory].sort(
      (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
    );

    const totalAdded = rawHistory
      .filter((h) => h.type === 'add' || h.type === 'initial')
      .reduce((sum, h) => sum + h.amount, 0);

    const totalPaid = rawHistory
      .filter((h) => h.type === 'pay')
      .reduce((sum, h) => sum + h.amount, 0);

    if (shareMode === 'statement') {
      let text = `${t('debtorShare.greeting', 'السلام عليكم ورحمة الله وبركاته')}\n`;
      text += `${t('debtorShare.dearClient', 'أخي الكريم:')} *${clientName}*\n`;
      text += `${t('debtorShare.statementIntro', 'تحية طيبة، مرفق لكم كشف الحساب المالي بذمتكم لدى')} ${titleHeader}:\n\n`;
      text += `* ${t('debtorShare.currentBalance', 'الرصيد الحالي المتبقي:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorShare.totalDebts', 'إجمالي الديون المسجلة:')} ${formatNumber(totalAdded, numberFormat)} ${currSym}\n`;
      text += `* ${t('debtorShare.totalPaid', 'إجمالي المبالغ المسددة:')} ${formatNumber(totalPaid, numberFormat)} ${currSym}\n`;

      if (sortedHistory.length > 0) {
        text += `\n--------------------\n`;
        text += `*${t('debtorShare.recentOperations', 'آخر العمليات المسجلة:')}*\n`;
        sortedHistory.slice(0, 5).forEach((tx, idx) => {
          const typeLabel =
            tx.type === 'pay'
              ? t('debtorShare.paymentType', 'تسديد')
              : tx.type === 'initial'
              ? t('debtorShare.initialType', 'رصيد أولي')
              : t('debtorShare.debtType', 'دين جديد');
          const sign = tx.type === 'pay' ? '-' : '+';
          const dateStr = formatDateDigits(tx.date, numberFormat);
          text += `${idx + 1}. ${typeLabel}: ${sign}${formatNumber(tx.amount, numberFormat)} ${currSym} (${dateStr})\n`;
        });
        if (sortedHistory.length > 5) {
          text += `${t('debtorShare.moreOperations', '... وهناك عمليات سابقة أخرى')}\n`;
        }
      }

      text += `--------------------\n`;
      text += `${t('debtorShare.closingNote', 'يرجى التكرم بمراجعة الحساب وإتمام التسديد في أقرب وقت. شاكرين حسن تعاونكم.')}\n`;
      text += `${titleHeader}`;
      return text;
    } else {
      // Summary mode
      let text = `${t('debtorShare.greeting', 'السلام عليكم ورحمة الله وبركاته')}\n`;
      text += `${t('debtorShare.dearClient', 'أخي الكريم:')} *${clientName}*\n\n`;
      text += `${t('debtorShare.summaryIntro', 'نود تذكيركم بلطف بالرصيد المالي القائم بذمتكم لدى')} ${titleHeader}:\n`;
      text += `* ${t('debtorShare.amountDue', 'المبلغ المطلوب تسديده:')} ${formatNumber(currentBalance, numberFormat)} ${currSym}\n`;
      if (debtor.createdAt) {
        text += `* ${t('debtorShare.regDate', 'تاريخ التسجيل:')} ${formatDateDigits(debtor.createdAt, numberFormat)}\n`;
      }
      text += `\n${t('debtorShare.summaryClosing', 'يرجى التكرم بمراجعة الحساب وإتمام التسديد مع جزيل الشكر والامتنان.')}\n`;
      text += `${titleHeader}`;
      return text;
    }
  }, [shareMode, debtor, activeStoreName, t, numberFormat, getCurrencySymbol]);

  // If not open or no debtor, return null after all hooks have been invoked
  if (!isOpen || !debtor) return null;

  const currentBalance = debtor.amount || 0;

  const handleCopyText = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(generatedText);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = generatedText;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      onShowToast(t('toast.copiedToClipboard', 'تم النسخ إلى الحافظة بنجاح'), 'success');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onShowToast(t('toast.copyFailed', 'تعذر نسخ النص إلى الحافظة'), 'error');
    }
  };

  const handleSendWhatsApp = () => {
    const targetPhone = customPhone.trim() || debtor.phone?.trim();
    if (!targetPhone) {
      onShowToast(t('toast.phoneRequiredWhatsApp', 'يرجى تحديد أو كتابة رقم هاتف العميل أولاً للإرسال عبر واتساب'), 'error');
      return;
    }

    const formatted = formatIraqiPhoneNumber(targetPhone);
    if (!formatted || formatted.length < 9) {
      onShowToast(t('toast.invalidPhone', 'رقم الهاتف غير صالح'), 'error');
      return;
    }

    const waUrl = `https://wa.me/${formatted}?text=${encodeURIComponent(generatedText)}`;
    window.open(waUrl, '_blank');
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${t('debtorShare.modalTitle', 'كشف حساب')} - ${debtor.name}`,
          text: generatedText,
        });
        onShowToast(t('toast.copiedToClipboard', 'تمت المشاركة بنجاح'), 'success');
      } catch {
        // User cancelled or share failed silently
      }
    } else {
      handleCopyText();
    }
  };

  return (
    <div
      id="debtorShareModalBackdrop"
      className="fixed inset-0 bg-slate-950/60 z-50 flex items-center justify-center p-3 sm:p-4 backdrop-blur-xs animate-in fade-in duration-150 select-none"
      onClick={onClose}
      dir={dir}
    >
      <div
        id="debtorShareModal"
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[92vh] border border-slate-100 animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/80">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-md shadow-blue-500/20">
              <i className="fa-solid fa-share-nodes"></i>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900">
                  {t('debtorShare.modalTitle', 'مشاركة كشف الحساب')}
                </h2>
                <span className="text-[11px] font-bold bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-full font-mono">
                  {formatNumber(currentBalance, numberFormat)} {getCurrencySymbol()}
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                {t('common.name', 'العميل')}: <strong className="text-slate-800 font-bold">{debtor.name}</strong>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-300 text-slate-500 hover:text-slate-800 flex items-center justify-center text-xs transition-colors cursor-pointer"
            title={t('common.close', 'إغلاق')}
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          {/* Format Selector Tabs */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              {t('common.status', 'صيغة ونوع الرسالة')}:
            </label>
            <div className="grid grid-cols-2 gap-2 bg-slate-100 p-1 rounded-2xl border border-slate-200/60">
              <button
                type="button"
                onClick={() => setShareMode('statement')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'statement'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-file-invoice-dollar text-xs"></i>
                <span>{t('debtorShare.statementMode', 'كشف حساب تفصيلي')}</span>
              </button>
              <button
                type="button"
                onClick={() => setShareMode('summary')}
                className={`py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  shareMode === 'summary'
                    ? 'bg-white text-blue-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <i className="fa-solid fa-bell text-xs"></i>
                <span>{t('debtorShare.summaryMode', 'تذكير مباشر وتفاصيل الدين')}</span>
              </button>
            </div>
          </div>

          {/* Optional Phone input if empty or needs correction */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-solid fa-phone text-[11px] text-slate-400"></i>
                <span>{t('debtorShare.recipientPhone', 'رقم هاتف المستلم (واتساب):')}</span>
              </label>
              {debtor.phone && (
                <span className="text-[11px] text-slate-400 font-mono dir-ltr">
                  {debtor.phone}
                </span>
              )}
            </div>
            <input
              type="tel"
              value={customPhone}
              onChange={(e) => setCustomPhone(e.target.value)}
              placeholder="07XXXXXXXXX"
              className="w-full py-2.5 px-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-blue-600 focus:bg-white text-left dir-ltr transition-colors"
            />
          </div>

          {/* Formatted Text Preview */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <i className="fa-regular fa-message text-[11px] text-slate-400"></i>
                <span>{t('debtorShare.preview', 'معاينة نص كشف الحساب للمشاركة:')}</span>
              </label>
              <button
                type="button"
                onClick={handleCopyText}
                className="text-xs text-blue-600 hover:text-blue-700 font-bold flex items-center gap-1 cursor-pointer transition-colors"
              >
                <i className={`fa-regular ${copied ? 'fa-circle-check text-emerald-600' : 'fa-copy'}`}></i>
                <span>{copied ? t('common.copied', 'تم النسخ!') : t('common.copy', 'نسخ النص')}</span>
              </button>
            </div>

            <div className="relative group">
              <textarea
                readOnly
                value={generatedText}
                rows={7}
                className="w-full p-3.5 bg-slate-50 border border-slate-200/90 rounded-2xl text-[12px] leading-relaxed text-slate-800 font-sans resize-none focus:outline-none select-all"
              />
              <div className="text-[10px] text-slate-400 mt-1 flex items-center justify-between">
                <span>{t('debtorShare.readyToSend', 'النص منسق وجاهز للإرسال الفوري')}</span>
                <span>{generatedText.length} {t('debtorShare.characters', 'حرف')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/50 flex flex-col sm:flex-row gap-2.5">
          {/* WhatsApp Primary Action Button */}
          <button
            type="button"
            id="btnShareWhatsApp"
            onClick={handleSendWhatsApp}
            className="flex-1 py-3 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <i className="fa-brands fa-whatsapp text-base"></i>
            <span>{t('debtorShare.sendViaWhatsApp', 'إرسال عبر واتساب')}</span>
          </button>

          {/* Copy Formatted Text Button */}
          <button
            type="button"
            id="btnCopyFormattedStatement"
            onClick={handleCopyText}
            className={`py-3 px-4 rounded-2xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer border ${
              copied
                ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200 active:scale-[0.99] shadow-xs'
            }`}
          >
            <i className={`fa-regular ${copied ? 'fa-circle-check text-emerald-600' : 'fa-copy text-blue-600'}`}></i>
            <span>{copied ? t('common.copied', 'تم النسخ بنجاح') : t('debtorShare.copyText', 'نسخ النص')}</span>
          </button>

          {/* Native Share button (if supported on device/browser) */}
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              type="button"
              id="btnNativeShare"
              onClick={handleNativeShare}
              className="py-3 px-3.5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer border border-slate-200/70"
              title={t('debtorShare.otherApps', 'مشاركة عبر تطبيقات أخرى')}
            >
              <i className="fa-solid fa-arrow-up-from-bracket text-xs"></i>
              <span className="hidden sm:inline">{t('debtorShare.otherApps', 'تطبيقات أخرى')}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
