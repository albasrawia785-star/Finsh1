import React, { useState } from 'react';
import { Supplier, SupplierTransaction } from '../types';
import { formatNumber, formatDateArabic, formatDateDigits, formatAmountInput, parseFormattedNumber } from '../utils/formatters';
import { useI18n } from '../i18n/index.tsx';

interface SupplierHistoryModalProps {
  supplier: Supplier | null;
  isOpen: boolean;
  onClose: () => void;
  onAddMoreDebt: (supplierId: number, addedAmount: number, notes?: string) => void;
  onDeleteSupplier: (supplierId: number) => void;
  onUpdateTransaction?: (supplierId: number, txId: string, newAmount: number, newNotes?: string, newDate?: string) => void;
  onDeleteTransaction?: (supplierId: number, txId: string) => void;
  onUpdateSupplierItemType?: (supplierId: number, newItemType: string) => void;
  currencySymbol?: string;
}

export const SupplierHistoryModal: React.FC<SupplierHistoryModalProps> = ({
  supplier,
  isOpen,
  onClose,
  onAddMoreDebt,
  onDeleteSupplier,
  onUpdateTransaction,
  onDeleteTransaction,
  onUpdateSupplierItemType,
  currencySymbol = 'د.ع',
}) => {
  const { numberFormat } = useI18n();
  const [showAddDebtForm, setShowAddDebtForm] = useState(false);
  const [addAmount, setAddAmount] = useState('');
  const [addNotes, setAddNotes] = useState('');

  // Item Type Editing State
  const [isEditingItemType, setIsEditingItemType] = useState(false);
  const [itemTypeInput, setItemTypeInput] = useState(supplier?.itemType || '');

  // Keep itemTypeInput synced when supplier changes
  React.useEffect(() => {
    if (supplier) {
      setItemTypeInput(supplier.itemType || '');
      setIsEditingItemType(false);
    }
  }, [supplier]);

  // Filtering & Search State
  const [filterType, setFilterType] = useState<'all' | 'add_debt' | 'pay_supplier'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Transaction Edit & Delete State
  const [editingTx, setEditingTx] = useState<SupplierTransaction | null>(null);
  const [editAmount, setEditAmount] = useState<string>('');
  const [editItemType, setEditItemType] = useState<string>('');
  const [editNotes, setEditNotes] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('');
  const [deletingTx, setDeletingTx] = useState<SupplierTransaction | null>(null);

  // Supplier Delete Confirm Modal State
  const [showDeleteSupplierConfirm, setShowDeleteSupplierConfirm] = useState(false);

  // Accordions collapse state by Month
  const [collapsedMonths, setCollapsedMonths] = useState<Record<string, boolean>>({});

  if (!isOpen || !supplier) return null;

  const currentAmount = supplier.amount || 0;
  const rawHistory = supplier.history && supplier.history.length > 0
    ? supplier.history
    : [
        {
          id: `initial-sup-${supplier.id}`,
          supplierId: supplier.id,
          type: 'initial' as const,
          amount: supplier.amount,
          balanceAfter: supplier.amount,
          date: supplier.createdAt || new Date().toISOString(),
          description: 'فتح حساب وتدوين الدين المطلوب الأولي للمورد',
        },
      ];

  // Helper for Month-Year title in Arabic
  const getMonthYearTitle = (dateStr?: string) => {
    if (!dateStr) return 'حركات سابقة';
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return 'حركات سابقة';
      const monthNames = [
        'كانون الثاني (يناير)', 'شباط (فبراير)', 'آذار (مارس)', 'نيسان (أبريل)',
        'أيار (مايو)', 'حزيران (يونيو)', 'تموز (يوليو)', 'آب (أغسطس)',
        'أيلول (سبتمبر)', 'تشرين الأول (أكتوبر)', 'تشرين الثاني (نوفمبر)', 'كانون الأول (ديسمبر)'
      ];
      const mName = monthNames[d.getMonth()];
      const yStr = formatDateDigits(String(d.getFullYear()), numberFormat);
      return `${mName} ${yStr}`;
    } catch {
      return 'حركات سابقة';
    }
  };

  const handleAddDebtSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(addAmount);
    if (isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى كتابة مبلغ الدين المضاف بشكل صحيح.');
      return;
    }

    onAddMoreDebt(supplier.id, numAmount, addNotes.trim() || undefined);

    setAddAmount('');
    setAddNotes('');
    setShowAddDebtForm(false);
  };

  const handleDeleteSupplierClick = () => {
    setShowDeleteSupplierConfirm(true);
  };

  const handleConfirmDeleteSupplier = () => {
    onDeleteSupplier(supplier.id);
    setShowDeleteSupplierConfirm(false);
    onClose();
  };

  // Start Editing Transaction
  const handleStartEditTx = (tx: SupplierTransaction) => {
    setEditingTx(tx);
    setEditAmount(formatAmountInput(String(tx.amount)));
    setEditItemType(tx.itemType || '');
    setEditNotes(tx.notes || '');
    setEditDate(tx.date ? new Date(tx.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0]);
  };

  // Save Edited Transaction
  const handleSaveEditTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTx) return;

    const numAmount = parseFormattedNumber(editAmount);
    if (isNaN(numAmount) || numAmount < 0) {
      alert('يرجى كتابة المبلغ المعدل بشكل صحيح.');
      return;
    }

    if (onUpdateTransaction) {
      onUpdateTransaction(
        supplier.id,
        editingTx.id,
        numAmount,
        editNotes.trim() || undefined,
        editDate,
        editItemType.trim() || undefined
      );
    }
    setEditingTx(null);
  };

  // Confirm Delete Transaction
  const handleConfirmDeleteTx = () => {
    if (!deletingTx) return;
    if (onDeleteTransaction) {
      onDeleteTransaction(supplier.id, deletingTx.id);
    }
    setDeletingTx(null);
  };

  // Filter & Search History
  const filteredHistory = [...rawHistory]
    .filter((tx) => {
      if (filterType === 'add_debt' && tx.type === 'pay_supplier') return false;
      if (filterType === 'pay_supplier' && tx.type !== 'pay_supplier') return false;

      if (searchQuery.trim()) {
        const q = searchQuery.trim().toLowerCase();
        const descMatch = (tx.description || '').toLowerCase().includes(q);
        const notesMatch = (tx.notes || '').toLowerCase().includes(q);
        const amtMatch = String(tx.amount).includes(q);
        if (!descMatch && !notesMatch && !amtMatch) return false;
      }
      return true;
    })
    .reverse();

  // Group History into Monthly Accordions Dropdowns
  interface SupplierMonthGroup {
    monthKey: string;
    monthTitle: string;
    transactions: SupplierTransaction[];
    totalAdded: number;
    totalPaid: number;
  }

  const monthGroups: SupplierMonthGroup[] = [];
  const groupMap: Record<string, SupplierMonthGroup> = {};

  filteredHistory.forEach((tx) => {
    let monthKey = 'other';
    try {
      const d = new Date(tx.date);
      if (!isNaN(d.getTime())) {
        monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      }
    } catch {}

    if (!groupMap[monthKey]) {
      const title = getMonthYearTitle(tx.date);
      groupMap[monthKey] = {
        monthKey,
        monthTitle: title,
        transactions: [],
        totalAdded: 0,
        totalPaid: 0,
      };
      monthGroups.push(groupMap[monthKey]);
    }

    groupMap[monthKey].transactions.push(tx);
    if (tx.type === 'pay_supplier') {
      groupMap[monthKey].totalPaid += tx.amount;
    } else {
      groupMap[monthKey].totalAdded += tx.amount;
    }
  });

  const toggleMonth = (mKey: string) => {
    setCollapsedMonths((prev) => ({ ...prev, [mKey]: !(prev[mKey] ?? true) }));
  };

  const toggleAllMonths = () => {
    const allCollapsed = monthGroups.every((g) => (collapsedMonths[g.monthKey] ?? true));
    const newState: Record<string, boolean> = {};
    monthGroups.forEach((g) => {
      newState[g.monthKey] = !allCollapsed;
    });
    setCollapsedMonths(newState);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 p-4 text-white flex items-center justify-between shrink-0 border-b border-amber-800/40">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 text-lg shrink-0">
              <i className="fa-solid fa-file-invoice-dollar"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">
                {typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '')}
              </h3>
              <p className="text-[11px] text-slate-300 font-medium flex items-center gap-2 flex-wrap">
                {typeof supplier.companyName === 'string' && supplier.companyName.trim()
                  ? `شركة: ${supplier.companyName.trim()}`
                  : 'سجل كشف الحساب والعمليات للمورد'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Balance Card Banner */}
        <div className="p-4 bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent dark:from-amber-950/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-start flex-wrap gap-2">
          <div>
            <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 block">الدين المتبقي للمورد عليك</span>
            <span className="text-xl font-black text-amber-600 dark:text-amber-400 font-mono">
              {formatNumber(currentAmount, numberFormat)} {currencySymbol}
            </span>
          </div>
        </div>

        {/* Dedicated Independent Card/Box for Goods Type (نوع البضاعة) - Viewing Only */}
        <div className="mx-4 my-2.5 p-3 bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-slate-50 dark:from-amber-950/40 dark:to-slate-800/80 rounded-2xl border border-amber-200/80 dark:border-amber-800/60 flex items-center justify-between text-start gap-3 shadow-2xs">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="w-8.5 h-8.5 rounded-xl bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-500/30 flex items-center justify-center text-sm shrink-0">
              <i className="fa-solid fa-boxes-packing"></i>
            </div>
            <div className="min-w-0 flex-1">
              <span className="text-[10.5px] font-bold text-slate-500 dark:text-slate-400 block">نوع البضاعة / المواد الحالية</span>
              <span className="text-xs font-black text-slate-800 dark:text-slate-100 block truncate">
                {supplier.itemType && supplier.itemType.trim() ? supplier.itemType.trim() : 'غير محدد'}
              </span>
            </div>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-start flex-wrap">
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'all'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              الكل
            </button>
            <button
              type="button"
              onClick={() => setFilterType('add_debt')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'add_debt'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              الديون المضافة
            </button>
            <button
              type="button"
              onClick={() => setFilterType('pay_supplier')}
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                filterType === 'pay_supplier'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
              }`}
            >
              التسديدات
            </button>
          </div>

          <div className="relative flex-1 min-w-[140px]">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في السجل..."
              className="w-full pl-2 pr-7 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-white outline-none"
            />
            <i className="fa-solid fa-magnifying-glass absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 text-[10px]"></i>
          </div>
        </div>

        {/* History List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-3 text-start">
          <div className="flex items-center justify-between gap-2 mb-1">
            <h4 className="text-xs font-black text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <span>سجل المعاملات والتسديدات ({formatNumber(filteredHistory.length, numberFormat)}):</span>
            </h4>

            {monthGroups.length > 1 && (
              <button
                type="button"
                onClick={toggleAllMonths}
                className="px-2.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 rounded-lg text-[10.5px] font-bold text-slate-700 dark:text-slate-300 transition-colors shrink-0 flex items-center gap-1 cursor-pointer"
                title="طي/فتح جميع الأقسام الشهرية"
              >
                <i className="fa-solid fa-layer-group text-[10px] text-amber-500"></i>
                <span>طي/فتح الأقسام</span>
              </button>
            )}
          </div>

          {monthGroups.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-dashed border-slate-200 dark:border-slate-800">
              لا توجد سجلات سابقة مطابقة لهذا العرض.
            </div>
          ) : (
            monthGroups.map((group) => {
              const isCollapsed = collapsedMonths[group.monthKey] ?? true;

              return (
                <div key={group.monthKey} className="space-y-2">
                  {/* ACCORDION HEADER FOR EACH MONTH */}
                  <div
                    onClick={() => toggleMonth(group.monthKey)}
                    className="bg-slate-100 dark:bg-slate-800/90 hover:bg-slate-200/80 dark:hover:bg-slate-700/90 transition-colors p-2.5 rounded-2xl flex items-center justify-between cursor-pointer border border-slate-200/80 dark:border-slate-700 select-none shadow-2xs"
                  >
                    <div className="flex items-center gap-2">
                      <i
                        className={`fa-solid fa-chevron-down text-[10px] text-amber-500 transition-transform duration-200 ${
                          isCollapsed ? '-rotate-90' : 'rotate-0'
                        }`}
                      ></i>
                      <span className="text-xs font-black text-slate-900 dark:text-white">
                        {group.monthTitle}
                      </span>
                      <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2 py-0.5 rounded-full border border-slate-200 dark:border-slate-700 font-mono">
                        {group.transactions.length}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[10.5px] font-mono">
                      {group.totalAdded > 0 && (
                        <span className="text-amber-600 dark:text-amber-400 font-bold">
                          +{formatNumber(group.totalAdded, numberFormat)} {currencySymbol}
                        </span>
                      )}
                      {group.totalPaid > 0 && (
                        <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                          -{formatNumber(group.totalPaid, numberFormat)} {currencySymbol}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* MONTH TRANSACTIONS LIST */}
                  {!isCollapsed && (
                    <div className="space-y-2 pr-1 pl-1">
                      {group.transactions.map((tx) => {
                        const isPayment = tx.type === 'pay_supplier';
                        return (
                          <div
                            key={tx.id}
                            className={`p-3 rounded-2xl border transition-all ${
                              isPayment
                                ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800/60'
                                : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80'
                            }`}
                          >
                            <div className="flex items-center justify-between gap-2">
                              <div className="flex items-center gap-2">
                                <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs shrink-0 ${
                                  isPayment ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/60 dark:text-emerald-300' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/60 dark:text-amber-300'
                                }`}>
                                  <i className={`fa-solid ${isPayment ? 'fa-arrow-down-long' : 'fa-arrow-up-long'}`}></i>
                                </div>
                                <div>
                                  <span className="text-xs font-black text-slate-900 dark:text-white block">
                                    {isPayment ? 'تسديد دفعة للمورد' : tx.type === 'initial' ? 'دين بضاعة أولي' : 'إضافة شحنة بضاعة بالأجل'}
                                  </span>
                                  <div className="flex items-center gap-1.5 flex-wrap mt-0.5">
                                    <span className="text-[10px] text-slate-400 font-medium">
                                      {tx.date ? formatDateArabic(tx.date) : ''}
                                    </span>
                                    {tx.itemType ? (
                                      <span className="text-[9.5px] bg-amber-100/80 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-200/80 dark:border-amber-800/60 inline-flex items-center gap-1">
                                        <i className="fa-solid fa-box text-[8px]"></i>
                                        <span>{tx.itemType}</span>
                                      </span>
                                    ) : tx.type === 'initial' && supplier.itemType ? (
                                      <span className="text-[9.5px] bg-amber-100/80 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-200/80 dark:border-amber-800/60 inline-flex items-center gap-1">
                                        <i className="fa-solid fa-box text-[8px]"></i>
                                        <span>{supplier.itemType}</span>
                                      </span>
                                    ) : null}
                                  </div>
                                </div>
                              </div>

                              <div className="text-left flex items-center gap-2">
                                <div>
                                  <span className={`text-xs font-black font-mono block ${isPayment ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}`}>
                                    {isPayment ? '-' : '+'}{formatNumber(tx.amount, numberFormat)} {currencySymbol}
                                  </span>
                                  <span className="text-[9.5px] text-slate-400 block font-mono">
                                    المتبقي: {formatNumber(tx.balanceAfter, numberFormat)}
                                  </span>
                                </div>

                                {/* Edit/Delete Transaction Actions */}
                                <div className="flex items-center gap-1 border-s border-slate-200 dark:border-slate-700 ps-2">
                                  {onUpdateTransaction && (
                                    <button
                                      type="button"
                                      onClick={() => handleStartEditTx(tx)}
                                      className="w-6 h-6 rounded-lg bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 flex items-center justify-center text-[10px] transition-colors cursor-pointer"
                                      title="تعديل هذه الحركة"
                                    >
                                      <i className="fa-solid fa-pen"></i>
                                    </button>
                                  )}
                                  {onDeleteTransaction && (
                                    <button
                                      type="button"
                                      onClick={() => setDeletingTx(tx)}
                                      className="w-6 h-6 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 flex items-center justify-center text-[10px] transition-colors cursor-pointer"
                                      title="حذف هذه الحركة"
                                    >
                                      <i className="fa-solid fa-trash-can"></i>
                                    </button>
                                  )}
                                </div>
                              </div>
                            </div>

                            {((typeof tx.notes === 'string' && tx.notes.trim()) || (typeof tx.description === 'string' && tx.description.trim())) ? (
                              <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60">
                                <div className="p-2.5 bg-slate-100/70 dark:bg-slate-800/80 rounded-xl border border-slate-200/80 dark:border-slate-700/80 text-xs text-slate-800 dark:text-slate-200 leading-relaxed break-words font-medium space-y-1">
                                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-amber-600 dark:text-amber-400">
                                    <i className="fa-solid fa-note-sticky text-amber-500"></i>
                                    <span>تفاصيل الملاحظات والوصل الكاملة:</span>
                                  </div>
                                  <p className="text-slate-900 dark:text-white font-bold select-text leading-relaxed whitespace-pre-wrap" dir="auto">
                                    {(typeof tx.notes === 'string' && tx.notes.trim()) ? tx.notes.trim() : String(tx.description || '').trim()}
                                  </p>
                                </div>
                              </div>
                            ) : null}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700/80 shrink-0 flex items-center justify-between">
          <button
            type="button"
            onClick={handleDeleteSupplierClick}
            className="text-xs font-bold text-rose-600 hover:text-rose-700 dark:text-rose-400 flex items-center gap-1 px-2.5 py-1.5 rounded-xl hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-trash-can text-xs"></i>
            <span>حذف المورد نهائياً</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold rounded-xl text-xs transition-all cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>

      {/* Edit Transaction Sub-Modal */}
      {editingTx && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 w-full max-w-sm shadow-2xl text-start space-y-3">
            <div className="flex items-center justify-between border-b pb-2">
              <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">تعديل حركة المورد</h4>
              <button
                type="button"
                onClick={() => setEditingTx(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            <form onSubmit={handleSaveEditTx} className="space-y-2.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">المبلغ</label>
                <input
                  type="text"
                  inputMode="numeric"
                  required
                  value={editAmount}
                  onChange={(e) => setEditAmount(formatAmountInput(e.target.value))}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">نوع البضاعة / المواد</label>
                <input
                  type="text"
                  value={editItemType}
                  onChange={(e) => setEditItemType(e.target.value)}
                  placeholder="مثال: أجهزة كهربائية / مواد غذائية..."
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500/20"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">التاريخ</label>
                <input
                  type="date"
                  value={editDate}
                  onChange={(e) => setEditDate(e.target.value)}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">الملاحظات / الوصل والتفاصيل</label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500/20 leading-relaxed resize-y"
                  placeholder="اكتب الملاحظات والتفاصيل الكاملة هنا..."
                />
              </div>
              <div className="pt-2 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-amber-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  حفظ التعديلات
                </button>
                <button
                  type="button"
                  onClick={() => setEditingTx(null)}
                  className="py-2 px-3 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Transaction Confirmation Sub-Modal */}
      {deletingTx && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 w-full max-w-sm shadow-2xl text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-lg">
              <i className="fa-solid fa-trash-can"></i>
            </div>
            <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">تأكيد حذف الحركة</h4>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              هل أنت أصل ومقتنع بحذف هذه الحركة بمبلغ ({formatNumber(deletingTx.amount, numberFormat)} {currencySymbol}) وإعادة احتساب رصيد المورد تلقائياً؟
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmDeleteTx}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                تأكيد الحذف
              </button>
              <button
                type="button"
                onClick={() => setDeletingTx(null)}
                className="py-2 px-3 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
              >
                تراجُع
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Delete Supplier Confirmation Sub-Modal */}
      {showDeleteSupplierConfirm && (
        <div className="fixed inset-0 z-[65] flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 w-full max-w-sm shadow-2xl text-center space-y-3.5 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto text-xl shadow-xs">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h4 className="font-extrabold text-base text-slate-900 dark:text-white">تأكيد حذف المورد نهائياً</h4>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              هل أنت أصل ومقتنع بحذف المورد <span className="font-black text-rose-600 dark:text-rose-400">({supplier.name})</span> وكافة سجله المعاملاتي نهائياً؟
            </p>
            <div className="pt-2 flex items-center gap-2">
              <button
                type="button"
                onClick={handleConfirmDeleteSupplier}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-md transition-all active:scale-95"
              >
                تأكيد الحذف النهائياً
              </button>
              <button
                type="button"
                onClick={() => setShowDeleteSupplierConfirm(false)}
                className="py-2.5 px-4 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-all"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
