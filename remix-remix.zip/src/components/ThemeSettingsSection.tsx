import React from 'react';
import { AppLayoutTheme } from '../types';
import { LAYOUT_THEMES } from '../utils/layoutThemes';
import { useI18n } from '../i18n/index.tsx';

interface ThemeSettingsSectionProps {
  currentTheme: AppLayoutTheme;
  onSelectTheme: (theme: AppLayoutTheme) => void;
  isAdmin?: boolean;
}

export const ThemeSettingsSection: React.FC<ThemeSettingsSectionProps> = ({
  currentTheme = 'fintech',
  onSelectTheme,
  isAdmin = false,
}) => {
  const { t } = useI18n();

  return (
    <div className="space-y-4 text-start">
      <div className="flex items-center justify-between gap-2">
        <div>
          <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <i className="fa-solid fa-palette text-blue-600"></i>
            <span>تصميم واجهة التطبيق (UI/UX)</span>
          </h4>
          <p className="text-xs text-slate-500 mt-0.5">
            يمكنك التبديل بين تصميم 1 الحديث (المنصة المصرفية) والرجوع إلى التصميم الأصلي للتطبيق في أي وقت بنقرة واحدة.
          </p>
        </div>

        <div className="shrink-0 bg-blue-50 border border-blue-200 text-blue-700 px-2.5 py-1 rounded-xl text-xs font-bold">
          خياران متاحان
        </div>
      </div>

      {/* Grid of 2 Themes: Fintech (Design 1) vs Classic (Original) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
        {LAYOUT_THEMES.map((item) => {
          const isSelected = currentTheme === item.id;
          return (
            <div
              key={item.id}
              onClick={() => onSelectTheme(item.id)}
              className={`relative rounded-2xl p-4 border-2 transition-all cursor-pointer flex flex-col justify-between gap-3 select-none ${
                isSelected
                  ? item.id === 'fintech'
                    ? 'border-emerald-600 bg-emerald-50/40 shadow-sm ring-2 ring-emerald-500/20'
                    : 'border-blue-600 bg-blue-50/40 shadow-sm ring-2 ring-blue-500/20'
                  : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50/60'
              }`}
            >
              {/* Top Row: Icon + Title + Badge + Active Radio */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-base shrink-0 border shadow-2xs ${item.accentColor}`}>
                    <i className={item.icon}></i>
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-black text-sm text-slate-900 leading-tight">
                        {item.title}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        item.id === 'fintech'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {item.badge}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
                      {item.englishTitle}
                    </div>
                  </div>
                </div>

                <div className="shrink-0">
                  <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all ${
                    isSelected
                      ? item.id === 'fintech'
                        ? 'border-emerald-600 bg-emerald-600 text-white'
                        : 'border-blue-600 bg-blue-600 text-white'
                      : 'border-slate-300 bg-white'
                  }`}>
                    {isSelected && <i className="fa-solid fa-check text-[10px]"></i>}
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-600 leading-relaxed">
                {item.description}
              </p>

              {/* Key Features Tags */}
              <div className="flex items-center gap-1.5 flex-wrap pt-2 border-t border-slate-100">
                {item.keyFeatures.map((feat, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-medium text-slate-600 bg-slate-100/90 px-2 py-0.5 rounded-md"
                  >
                    • {feat}
                  </span>
                ))}
              </div>

              {/* Action Button */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectTheme(item.id);
                }}
                className={`w-full mt-1 py-2 px-3 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs ${
                  isSelected
                    ? item.id === 'fintech'
                      ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {isSelected ? (
                  <>
                    <i className="fa-solid fa-circle-check text-xs"></i>
                    <span>التصميم المفعّل حالياً</span>
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-arrow-rotate-right text-xs"></i>
                    <span>{item.id === 'classic' ? 'الرجوع إلى هذا التصميم الأصلي' : 'تفعيل هذا التصميم'}</span>
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
