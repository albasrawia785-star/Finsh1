import React, { useState, useMemo } from 'react';
import { Supplier, User } from '../types';
import { formatNumber, formatDateDigits } from '../utils/formatters';
import { getUserBranchDisplayName } from '../utils/userUtils';
import { useI18n } from '../i18n/index.tsx';

export type SupplierReportPeriod = 'today' | 'week' | 'month' | 'custom' | 'all';
export type SupplierTxFilterType = 'all' | 'add_debt' | 'pay_supplier';

interface SuppliersReportProps {
  suppliers: Supplier[];
  currentUser: User;
  onShowToast?: (message: string, type: 'success' | 'error' | 'info') => void;
}

export const SuppliersReport: React.FC<SuppliersReportProps> = React.memo(({
  suppliers,
  currentUser,
  onShowToast,
}) => {
  const { t, numberFormat, currency } = useI18n();

  const [period, setPeriod] = useState<SupplierReportPeriod>('all');
  const [txTypeFilter, setTxTypeFilter] = useState<SupplierTxFilterType>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [expandedSupplierIds, setExpandedSupplierIds] = useState<number[]>([]);

  // Toggle expanded accordion
  const toggleExpand = (id: number) => {
    setExpandedSupplierIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const expandAll = () => {
    setExpandedSupplierIds(suppliers.map((s) => s.id));
  };

  const collapseAll = () => {
    setExpandedSupplierIds([]);
  };

  // Date range bounds calculation
  const { startMs, endMs } = useMemo(() => {
    const now = new Date();
    let s = 0;
    let e = Infinity;

    if (period === 'today') {
      const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'week') {
      const start = new Date(now);
      const day = start.getDay();
      const diff = start.getDate() - day + (day === 0 ? -6 : 1);
      start.setDate(diff);
      start.setHours(0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
      s = start.getTime();
      e = Date.now();
    } else if (period === 'custom') {
      if (startDate) {
        s = new Date(`${startDate}T00:00:00`).getTime();
      }
      if (endDate) {
        e = new Date(`${endDate}T23:59:59.999`).getTime();
      }
    }

    return { startMs: s, endMs: e };
  }, [period, startDate, endDate]);

  // Aggregate supplier statistics and filtered history
  const { supplierSummaries, totalOwed, totalPaidInPeriod, totalAddedInPeriod, activeCount } = useMemo(() => {
    let owed = 0;
    let paidPeriod = 0;
    let addedPeriod = 0;
    let active = 0;

    const term = searchTerm.toLowerCase().trim();

    const summaries = suppliers
      .filter((sup) => {
        if (!term) return true;
        return (
          sup.name.toLowerCase().includes(term) ||
          (sup.companyName && sup.companyName.toLowerCase().includes(term)) ||
          (sup.itemType && sup.itemType.toLowerCase().includes(term)) ||
          (sup.phone && sup.phone.includes(term))
        );
      })
      .map((sup) => {
        const curAmount = Number(sup.amount) || 0;
        if (curAmount > 0) {
          owed += curAmount;
          active++;
        }

        // Filter transactions
        const history = sup.history || [];
        const filteredTx = history.filter((tx) => {
          const txTime = new Date(tx.date).getTime();
          if (isNaN(txTime)) return true;
          if (txTime < startMs || txTime > endMs) return false;

          if (txTypeFilter === 'add_debt' && tx.type !== 'add_debt') return false;
          if (txTypeFilter === 'pay_supplier' && tx.type !== 'pay_supplier') return false;

          return true;
        });

        let supplierPaid = 0;
        let supplierAdded = 0;

        filteredTx.forEach((tx) => {
          const amt = Number(tx.amount) || 0;
          if (tx.type === 'pay_supplier') {
            supplierPaid += amt;
            paidPeriod += amt;
          } else if (tx.type === 'add_debt') {
            supplierAdded += amt;
            addedPeriod += amt;
          }
        });

        return {
          supplier: sup,
          filteredTx,
          supplierPaid,
          supplierAdded,
        };
      });

    return {
      supplierSummaries: summaries,
      totalOwed: owed,
      totalPaidInPeriod: paidPeriod,
      totalAddedInPeriod: addedPeriod,
      activeCount: active,
    };
  }, [suppliers, searchTerm, startMs, endMs, txTypeFilter]);

  // Copy or WhatsApp text report
  const generateReportText = () => {
    const branchName = getUserBranchDisplayName(currentUser, t);
    const dateStr = formatDateDigits(new Date().toISOString());

    let text = `📋 *تقرير ديون الموردين والشركات*\n`;
    text += `🏢 الفرع: ${branchName}\n`;
    text += `📅 التاريخ: ${dateStr}\n`;
    text += `------------------------------\n`;
    text += `💵 إجمالي المستحقات للموردين: ${formatNumber(totalOwed, numberFormat)} ${currency}\n`;
    text += `✅ إجمالي التسديدات خلال الفترة: ${formatNumber(totalPaidInPeriod, numberFormat)} ${currency}\n`;
    text += `📦 إجمالي البضائع والديون الجديدة: ${formatNumber(totalAddedInPeriod, numberFormat)} ${currency}\n`;
    text += `👥 عدد الموردين المستحقين: ${formatNumber(activeCount, numberFormat)}\n`;
    text += `------------------------------\n\n`;

    supplierSummaries.forEach(({ supplier, supplierPaid, supplierAdded }) => {
      const curAmt = Number(supplier.amount) || 0;
      if (curAmt > 0 || supplierPaid > 0 || supplierAdded > 0) {
        text += `• *${supplier.name}* ${supplier.companyName ? `(${supplier.companyName})` : ''}\n`;
        text += `  المستحق القائم: ${formatNumber(curAmt, numberFormat)} ${currency}\n`;
        if (supplierAdded > 0) text += `  بضاعة جديدة: ${formatNumber(supplierAdded, numberFormat)} ${currency}\n`;
        if (supplierPaid > 0) text += `  مسدد خلال الفترة: ${formatNumber(supplierPaid, numberFormat)} ${currency}\n`;
        text += `\n`;
      }
    });

    return text;
  };

  const handleCopyReport = () => {
    const reportText = generateReportText();
    navigator.clipboard.writeText(reportText);
    if (onShowToast) {
      onShowToast('تم نسخ تقرير الموردين إلى الحافظة بنجاح', 'success');
    }
  };

  return (
    <div className="space-y-4 pb-28 text-start select-none">
      {/* Header Bar & Quick Actions */}
      <div className="bg-gradient-to-r from-amber-950 via-amber-900 to-slate-950 p-4 rounded-3xl text-white shadow-xl border border-amber-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-black flex items-center gap-2">
            <i className="fa-solid fa-truck-field text-amber-400"></i>
            <span>تقرير الموردين والشركات</span>
          </h3>
          <p className="text-xs text-amber-200/80 font-medium mt-0.5">
            ملخص حركة المشتريات والتسديدات والديون القائمة للموردين
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleCopyReport}
            className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-white text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            title="نسخ التقرير نصياً"
          >
            <i className="fa-solid fa-copy"></i>
            <span>نسخ التقرير</span>
          </button>
        </div>
      </div>

      {/* Filter Options Controls */}
      <div className="bg-white dark:bg-slate-900 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        {/* Period Selector Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {(
            [
              { id: 'all', label: 'الكل' },
              { id: 'today', label: 'اليوم' },
              { id: 'week', label: 'هذا الأسبوع' },
              { id: 'month', label: 'هذا الشهر' },
              { id: 'custom', label: 'تاريخ مخصص' },
            ] as { id: SupplierReportPeriod; label: string }[]
          ).map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => setPeriod(p.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                period === p.id
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>

        {/* Custom Date Bounds */}
        {period === 'custom' && (
          <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-slate-800">
            <div>
              <label className="block text-[10px] font-extrabold text-slate-500 dark:text-slate-400 mb-1">من تاريخ:</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-[10px] font-extrabold text-slate-500 dark:text-slate-400 mb-1">إلى تاريخ:</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 dark:text-white"
              />
            </div>
          </div>
        )}

        {/* Search & Transaction Type Filter */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-slate-800">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="ابحث باسم المورد أو الشركة أو السلعة..."
              className="w-full pl-3 pr-8 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-white placeholder-slate-400 focus:outline-none focus:border-amber-500"
            />
            <i className="fa-solid fa-magnifying-glass absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
          </div>

          <div className="flex items-center gap-1.5">
            {(
              [
                { id: 'all', label: 'جميع المعاملات' },
                { id: 'add_debt', label: 'بضائع جديدة' },
                { id: 'pay_supplier', label: 'مدفوعات' },
              ] as { id: SupplierTxFilterType; label: string }[]
            ).map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setTxTypeFilter(f.id)}
                className={`flex-1 py-1.5 rounded-xl text-[11px] font-bold transition-all cursor-pointer ${
                  txTypeFilter === f.id
                    ? 'bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-200 border border-amber-300 dark:border-amber-700'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Stats KPI Summary Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <div className="bg-gradient-to-br from-amber-500 to-orange-600 text-white p-3.5 rounded-2xl shadow-md border border-amber-400/30">
          <div className="flex items-center justify-between text-amber-100 mb-1">
            <span className="text-[10px] font-black">إجمالي المستحق القائم</span>
            <i className="fa-solid fa-coins text-xs"></i>
          </div>
          <div className="text-base font-black font-mono">
            {formatNumber(totalOwed, numberFormat)} {currency}
          </div>
          <div className="text-[10px] text-amber-100/80 font-medium mt-0.5">
            الديون المطلوبة لصالح الموردين
          </div>
        </div>

        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-3.5 rounded-2xl shadow-md border border-emerald-400/30">
          <div className="flex items-center justify-between text-emerald-100 mb-1">
            <span className="text-[10px] font-black">إجمالي المدفوعات</span>
            <i className="fa-solid fa-hand-holding-dollar text-xs"></i>
          </div>
          <div className="text-base font-black font-mono">
            {formatNumber(totalPaidInPeriod, numberFormat)} {currency}
          </div>
          <div className="text-[10px] text-emerald-100/80 font-medium mt-0.5">
            مسدد للموردين في الفترة
          </div>
        </div>

        <div className="bg-gradient-to-br from-rose-600 to-orange-700 text-white p-3.5 rounded-2xl shadow-md border border-rose-400/30">
          <div className="flex items-center justify-between text-rose-100 mb-1">
            <span className="text-[10px] font-black">بضائع جديدة</span>
            <i className="fa-solid fa-boxes-packing text-xs"></i>
          </div>
          <div className="text-base font-black font-mono">
            {formatNumber(totalAddedInPeriod, numberFormat)} {currency}
          </div>
          <div className="text-[10px] text-rose-100/80 font-medium mt-0.5">
            مشتريات بالأجل في الفترة
          </div>
        </div>

        <div className="bg-gradient-to-br from-slate-800 to-slate-900 text-white p-3.5 rounded-2xl shadow-md border border-slate-700">
          <div className="flex items-center justify-between text-slate-300 mb-1">
            <span className="text-[10px] font-black">الموردين النشطين</span>
            <i className="fa-solid fa-users text-xs"></i>
          </div>
          <div className="text-base font-black font-mono">
            {formatNumber(activeCount, numberFormat)} مورد
          </div>
          <div className="text-[10px] text-slate-400 font-medium mt-0.5">
            لهم مبالغ قائمة حالياً
          </div>
        </div>
      </div>

      {/* Accordion List Header Actions */}
      <div className="flex items-center justify-between pt-1">
        <div className="text-xs font-black text-slate-800 dark:text-white flex items-center gap-1.5">
          <i className="fa-solid fa-list-check text-amber-500"></i>
          <span>تفاصيل سجلات الموردين ({formatNumber(supplierSummaries.length, numberFormat)})</span>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <button
            type="button"
            onClick={expandAll}
            className="text-amber-600 dark:text-amber-400 font-bold hover:underline cursor-pointer"
          >
            توسيع الكل
          </button>
          <span className="text-slate-300 dark:text-slate-700">•</span>
          <button
            type="button"
            onClick={collapseAll}
            className="text-slate-500 font-bold hover:underline cursor-pointer"
          >
            طي الكل
          </button>
        </div>
      </div>

      {/* Supplier Items Detailed List */}
      {supplierSummaries.length === 0 ? (
        <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 text-slate-500">
          <i className="fa-solid fa-truck-field text-2xl text-amber-400 mb-2"></i>
          <p className="text-xs font-bold">لا يوجد نتائج طابقت محددات البحث والتصفية</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {supplierSummaries.map(({ supplier, filteredTx, supplierPaid, supplierAdded }) => {
            const isExpanded = expandedSupplierIds.includes(supplier.id);
            const curAmount = Number(supplier.amount) || 0;

            return (
              <div
                key={supplier.id}
                className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/90 dark:border-slate-800 shadow-2xs overflow-hidden transition-all"
              >
                {/* Header Summary Row */}
                <div
                  onClick={() => toggleExpand(supplier.id)}
                  className="p-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center font-black text-xs shrink-0 border border-amber-500/20">
                      <i className="fa-solid fa-truck"></i>
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-extrabold text-xs text-slate-900 dark:text-white truncate">
                          {typeof supplier.name === 'string' ? supplier.name : String(supplier.name || '')}
                        </span>
                        {typeof supplier.companyName === 'string' && supplier.companyName.trim() ? (
                          <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-[10px] px-1.5 py-0.5 rounded-md font-medium truncate">
                            {supplier.companyName}
                          </span>
                        ) : null}
                        {typeof supplier.itemType === 'string' && supplier.itemType.trim() ? (
                          <span className="bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 text-[10px] px-1.5 py-0.5 rounded-md font-medium truncate border border-amber-200 dark:border-amber-800">
                            {supplier.itemType}
                          </span>
                        ) : null}
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium flex items-center gap-2 mt-0.5">
                        {typeof supplier.phone === 'string' && supplier.phone.trim() ? (
                          <span>
                            <i className="fa-solid fa-phone text-[9px] me-1"></i>
                            {supplier.phone}
                          </span>
                        ) : null}
                        <span>
                          عدد المعاملات: {formatNumber(filteredTx.length, numberFormat)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0 text-end">
                    <div>
                      <div className="text-[10px] text-slate-400 font-bold">المستحق القائم</div>
                      <div
                        className={`text-xs font-black font-mono ${
                          curAmount > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {formatNumber(curAmount, numberFormat)} {currency}
                      </div>
                    </div>
                    <i
                      className={`fa-solid fa-chevron-down text-xs text-slate-400 transition-transform ${
                        isExpanded ? 'rotate-180 text-amber-500' : ''
                      }`}
                    ></i>
                  </div>
                </div>

                {/* Expanded Transactions Accordion Details */}
                {isExpanded && (
                  <div className="border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/40 p-3 space-y-2">
                    <div className="flex items-center justify-between text-[11px] font-bold text-slate-600 dark:text-slate-400 pb-1">
                      <span>حركة الحساب في الفترة المحدد:</span>
                      <div className="flex items-center gap-3">
                        <span className="text-rose-600 dark:text-rose-400">
                          إضافة: +{formatNumber(supplierAdded, numberFormat)}
                        </span>
                        <span className="text-emerald-600 dark:text-emerald-400">
                          مسدد: -{formatNumber(supplierPaid, numberFormat)}
                        </span>
                      </div>
                    </div>

                    {filteredTx.length === 0 ? (
                      <div className="text-[11px] text-slate-400 italic py-2 text-center">
                        لا يوجد معاملات مسجلة لهذا المورد خلال الفترة المحددة
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {filteredTx.map((tx) => {
                          const isPay = tx.type === 'pay_supplier';
                          const txAmt = Number(tx.amount) || 0;
                          return (
                            <div
                              key={tx.id}
                              className="bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200/70 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <span
                                  className={`w-6 h-6 rounded-lg flex items-center justify-center text-[10px] font-black shrink-0 ${
                                    isPay
                                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                                      : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                                  }`}
                                >
                                  <i className={`fa-solid ${isPay ? 'fa-arrow-down' : 'fa-arrow-up'}`}></i>
                                </span>
                                <div className="min-w-0">
                                  <div className="font-bold text-slate-800 dark:text-white truncate flex items-center gap-1.5 flex-wrap">
                                    <span>{isPay ? 'دفعة مسددة للمورد' : 'بضاعة/دين جديد'}</span>
                                    {tx.itemType ? (
                                      <span className="bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 text-[9.5px] px-1.5 py-0.2 rounded font-medium border border-amber-200 dark:border-amber-700">
                                        📦 {tx.itemType}
                                      </span>
                                    ) : null}
                                    {tx.description && <span className="font-normal text-slate-500 me-1"> - {tx.description}</span>}
                                  </div>
                                  {(tx.notes && tx.notes.trim()) && (
                                    <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                                      ملاحظة: {tx.notes}
                                    </div>
                                  )}
                                  <div className="text-[10px] text-slate-400 font-mono">
                                    {formatDateDigits(tx.date)}
                                  </div>
                                </div>
                              </div>

                              <div className="text-end shrink-0">
                                <div
                                  className={`font-black font-mono ${
                                    isPay ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                                  }`}
                                >
                                  {isPay ? '-' : '+'}{formatNumber(txAmt, numberFormat)} {currency}
                                </div>
                                <div className="text-[9.5px] text-slate-400 font-mono">
                                  الرصيد بعدها: {formatNumber(tx.balanceAfter, numberFormat)}
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
});

SuppliersReport.displayName = 'SuppliersReport';
