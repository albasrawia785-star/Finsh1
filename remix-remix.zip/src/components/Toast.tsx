import React, { useEffect } from 'react';
import { useI18n } from '../i18n/index.tsx';

export interface ToastMessage {
  id: string;
  message: string;
  type?: 'success' | 'error' | 'info';
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

const ToastItem: React.FC<{
  toast: ToastMessage;
  onDismiss: (id: string) => void;
}> = ({ toast, onDismiss }) => {
  const { t, dir } = useI18n();

  useEffect(() => {
    const timer = setTimeout(() => {
      onDismiss(toast.id);
    }, 1000); // 1 second duration
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const isError = toast.type === 'error';
  const isSuccess = toast.type === 'success' || !toast.type;

  return (
    <div
      dir={dir}
      onClick={() => onDismiss(toast.id)}
      className={`pointer-events-auto p-3 rounded-2xl shadow-xl text-xs font-semibold flex items-center justify-between gap-2 border transition-all animate-in fade-in slide-in-from-top-2 duration-150 ${
        isError
          ? 'bg-red-600 text-white border-red-700 shadow-red-950/40'
          : isSuccess
          ? 'bg-slate-900/95 text-white border-slate-800 backdrop-blur-sm shadow-slate-950/40'
          : 'bg-blue-600 text-white border-blue-700 shadow-blue-950/40'
      }`}
    >
      <div className="flex items-center gap-2">
        <i
          className={`text-sm ${
            isError
              ? 'fa-solid fa-circle-xmark text-red-200'
              : 'fa-solid fa-circle-check text-emerald-400'
          }`}
        ></i>
        <span>{toast.message}</span>
      </div>
      <button
        type="button"
        className="text-white/60 hover:text-white text-xs cursor-pointer"
        aria-label={t('common.close', 'إغلاق')}
      >
        <i className="fa-solid fa-xmark"></i>
      </button>
    </div>
  );
};

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 left-1/2 -translate-x-1/2 w-full max-w-xs z-50 flex flex-col gap-2 pointer-events-none px-4">
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} onDismiss={onDismiss} />
      ))}
    </div>
  );
};
