import React, { useState, useRef } from 'react';
import { AppSettings, Debtor, User, InstallmentRecord, Manager, SubscriptionType, ManagerModuleAccess, Supplier } from '../types';
import { formatNumber } from '../utils/formatters';
import { getLocalDebtorHistory, sanitizeSupplier } from '../services/turso';
import { useI18n } from '../i18n/index.tsx';

interface BackupRestoreSectionProps {
  currentUser: User;
  debtors: Debtor[];
  installments?: InstallmentRecord[];
  suppliers?: Supplier[];
  managers?: Manager[];
  settings: AppSettings;
  onImportBackup?: (
    importedDebtors: Debtor[],
    importedInstallments: InstallmentRecord[],
    mode: 'merge' | 'replace',
    importedManagers?: Manager[],
    importedSuppliers?: Supplier[]
  ) => Promise<void>;
  onImportDebtors?: (importedDebtors: Debtor[], mode: 'merge' | 'replace') => Promise<void>;
  onShowToast: (message: string, type: 'success' | 'error' | 'info') => void;
  flat?: boolean;
}

interface ImportPreview {
  fileName: string;
  exportDate?: string;
  sourceBranch?: string;
  managersCount: number;
  managersList: Manager[];
  debtorsCount: number;
  totalDebt: number;
  debtorsList: Debtor[];
  installmentsCount: number;
  totalInstallmentsRemaining: number;
  installmentsList: InstallmentRecord[];
  suppliersCount: number;
  totalSuppliersDebt: number;
  suppliersList: Supplier[];
}

export const BackupRestoreSection: React.FC<BackupRestoreSectionProps> = ({
  currentUser,
  debtors,
  installments = [],
  suppliers = [],
  managers = [],
  settings,
  onImportBackup,
  onImportDebtors,
  onShowToast,
  flat = false,
}) => {
  const { t, numberFormat, getCurrencySymbol, dir } = useI18n();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge');
  const [preview, setPreview] = useState<ImportPreview | null>(null);

  const isAdmin = currentUser.role === 'admin';
  const branchDisplayName = currentUser.branch_name || currentUser.username || (isAdmin ? 'الإدارة العامة' : 'الفرع الحالي');
  const currSym = getCurrencySymbol();

  // ----------------------------------------------------
  // 1. EXPORT BACKUP (FULL SYSTEM FOR ADMIN / LOCAL BRANCH FOR SUB-MANAGERS)
  // ----------------------------------------------------
  const handleExportBackup = () => {
    try {
      setIsExporting(true);

      const realDebtors = debtors.filter((d) => !d.isDemo);
      const historyMap = getLocalDebtorHistory(currentUser.id);
      const enrichedDebtors = realDebtors.map((d) => ({
        ...d,
        history: historyMap[d.id] || d.history || [],
      }));

      const totalDebt = realDebtors.reduce((sum, d) => sum + (Number(d.amount) || 0), 0);

      const realInstallments = installments.map((inst) => ({
        ...inst,
        payments: Array.isArray(inst.payments) ? inst.payments : [],
      }));
      const totalInstallmentsAmount = realInstallments.reduce(
        (sum, i) => sum + (Number(i.totalAmount) || 0),
        0
      );
      const totalInstallmentsRemaining = realInstallments.reduce(
        (sum, i) => sum + (Number(i.remainingAmount) || 0),
        0
      );

      const realSuppliers = (suppliers || []).filter((s) => !s.isDemo).map(sanitizeSupplier);
      const totalSuppliersDebt = realSuppliers.reduce(
        (sum, s) => sum + (Number(s.amount) || Number(s.totalDebt) || 0),
        0
      );

      const realManagers = isAdmin
        ? (managers || []).map((m) => ({
            id: m.id,
            username: m.username,
            branch: m.branch,
            isActive: m.isActive,
            subscriptionType: m.subscriptionType,
            subscriptionExpiresAt: m.subscriptionExpiresAt,
            allowedModules: m.allowedModules,
            plainPassword:
              m.plainPassword ||
              localStorage.getItem(`user_pwd_${m.id}`) ||
              localStorage.getItem(`user_pwd_${m.username}`) ||
              '',
            createdAt: m.createdAt,
          }))
        : [];

      const now = new Date();
      const dateStr = now.toISOString().slice(0, 10);

      const backupPayload = {
        appName: 'دفتر الديون والأقساط والموردين',
        version: '3.5',
        backupType: isAdmin ? 'full_system' : 'branch_local',
        exportTimestamp: now.toISOString(),
        branchName: currentUser.branch_name || (isAdmin ? 'Main Branch' : currentUser.username),
        username: currentUser.username,
        userId: currentUser.id,
        userRole: currentUser.role,
        totalManagersCount: realManagers.length,
        totalDebtorsCount: realDebtors.length,
        totalDebtAmount: totalDebt,
        totalInstallmentsCount: realInstallments.length,
        totalInstallmentsAmount,
        totalInstallmentsRemaining,
        totalSuppliersCount: realSuppliers.length,
        totalSuppliersDebtAmount: totalSuppliersDebt,
        settings,
        ...(isAdmin ? { managers: realManagers } : {}),
        debtors: enrichedDebtors,
        installments: realInstallments,
        suppliers: realSuppliers,
      };

      const jsonStr = JSON.stringify(backupPayload, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8;' });
      const url = URL.createObjectURL(blob);

      const downloadLink = document.createElement('a');
      downloadLink.href = url;
      const cleanBranchFile = (currentUser.branch_name || currentUser.username || 'branch')
        .trim()
        .replace(/[\s/\\:*?"<>|]+/g, '_');
      downloadLink.download = isAdmin
        ? `backup_full_system_${dateStr}.json`
        : `backup_branch_${cleanBranchFile}_${dateStr}.json`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);

      if (isAdmin) {
        onShowToast(
          `${t('common.success', 'تم التصدير بنجاح')} (${realManagers.length} مدراء • ${realDebtors.length} مدينين • ${realInstallments.length} أقساط • ${realSuppliers.length} موردين)`,
          'success'
        );
      } else {
        onShowToast(
          `${t('common.success', 'تم تصدير النسخة الاحتياطية للفرع بنجاح')} (${realDebtors.length} مدينين • ${realInstallments.length} أقساط • ${realSuppliers.length} موردين)`,
          'success'
        );
      }
    } catch (err: any) {
      console.error('Error exporting backup:', err);
      onShowToast(`${t('common.error', 'خطأ')}: ${err?.message || 'Error'}`, 'error');
    } finally {
      setIsExporting(false);
    }
  };

  // ----------------------------------------------------
  // 2. PARSE & PREVIEW IMPORT FILE
  // ----------------------------------------------------
  const processSelectedFile = (file: File) => {
    if (!file.name.endsWith('.json') && file.type !== 'application/json') {
      onShowToast(t('backup.invalidJson', 'يرجى اختيار ملف نسخة احتياطية بصيغة JSON (.json)'), 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('File is empty');
        }

        const parsed = JSON.parse(text);

        let rawDebtorsList: any[] = [];
        let rawInstallmentsList: any[] = [];
        let rawManagersList: any[] = [];
        let rawSuppliersList: any[] = [];
        let exportDate: string | undefined;
        let sourceBranch: string | undefined;

        if (Array.isArray(parsed)) {
          rawDebtorsList = parsed;
        } else if (parsed && typeof parsed === 'object') {
          if (Array.isArray(parsed.debtors)) {
            rawDebtorsList = parsed.debtors;
          }
          if (Array.isArray(parsed.installments)) {
            rawInstallmentsList = parsed.installments;
          }
          if (Array.isArray(parsed.managers)) {
            rawManagersList = parsed.managers;
          }
          if (Array.isArray(parsed.suppliers)) {
            rawSuppliersList = parsed.suppliers;
          }
          exportDate = parsed.exportDateFormatted || parsed.exportTimestamp;
          sourceBranch = parsed.branchName;
        } else {
          throw new Error('Unsupported backup file format');
        }

        if (
          rawDebtorsList.length === 0 &&
          rawInstallmentsList.length === 0 &&
          rawManagersList.length === 0 &&
          rawSuppliersList.length === 0
        ) {
          throw new Error('Backup file does not contain any manager, debt, installment or supplier records');
        }

        const cleanedManagers: Manager[] = rawManagersList.map((item, index) => ({
          id: Number(item.id) || Date.now() + 5000 + index,
          username: String(item.username || '').trim() || `manager_${index + 1}`,
          branch: String(item.branch || item.branch_name || '').trim() || `فرع ${index + 1}`,
          isActive: item.isActive !== undefined ? Boolean(item.isActive) : true,
          subscriptionType: (item.subscriptionType as SubscriptionType) || 'permanent',
          subscriptionExpiresAt: item.subscriptionExpiresAt || null,
          allowedModules: (item.allowedModules as ManagerModuleAccess) || 'both',
          plainPassword: String(item.plainPassword || item.password || '').trim(),
          createdAt: item.createdAt || new Date().toISOString(),
        }));

        const cleanedDebtors: Debtor[] = rawDebtorsList.map((item, index) => {
          const name = String(item.name || '').trim();
          if (!name) {
            throw new Error(`Invalid name in record #${index + 1}`);
          }
          const amount = Math.max(0, Number(item.amount) || 0);
          const phone = String(item.phone || '').trim();
          const status = String(item.status || (amount === 0 ? 'cleared' : 'active'));

          return {
            id: Number(item.id) || Date.now() + index,
            name,
            phone,
            amount,
            status,
            userId: currentUser.id,
            createdAt: item.createdAt || new Date().toISOString(),
            lastDebtDate: item.lastDebtDate,
            history: Array.isArray(item.history) ? item.history : [],
          };
        });

        const cleanedInstallments: InstallmentRecord[] = rawInstallmentsList.map((item, index) => {
          const name = String(item.name || '').trim();
          const phone = String(item.phone || '').trim();
          const itm = String(item.item || 'Item').trim();
          const totalAmount = Math.max(0, Number(item.totalAmount) || 0);
          const downPayment = Math.max(0, Number(item.downPayment) || 0);
          const remainingAmount = Number.isFinite(Number(item.remainingAmount))
            ? Number(item.remainingAmount)
            : Math.max(0, totalAmount - downPayment);
          const registrationDate = item.registrationDate || new Date().toISOString().slice(0, 10);
          const nextDueDate = item.nextDueDate || registrationDate;
          const status = item.status || (remainingAmount <= 0 ? 'completed' : 'active');

          return {
            id: Number(item.id) || Date.now() + 1000 + index,
            name: name || `Installment ${index + 1}`,
            phone,
            item: itm,
            totalAmount,
            downPayment,
            remainingAmount,
            monthlyInstallmentAmount: item.monthlyInstallmentAmount ? Number(item.monthlyInstallmentAmount) : undefined,
            registrationDate,
            nextDueDate,
            userId: currentUser.id,
            status,
            notes: item.notes || '',
            payments: Array.isArray(item.payments) ? item.payments : [],
            createdAt: item.createdAt || new Date().toISOString(),
          };
        });

        const cleanedSuppliers: Supplier[] = rawSuppliersList.map((item, index) => {
          const name = String(item.name || '').trim();
          if (!name) {
            throw new Error(`اسم المورد غير صالح في السجل #${index + 1}`);
          }
          return sanitizeSupplier({
            id: Number(item.id) || Date.now() + 3000 + index,
            name,
            companyName: item.companyName ? String(item.companyName).trim() : '',
            phone: item.phone ? String(item.phone).trim() : '',
            notes: item.notes ? String(item.notes).trim() : '',
            itemType: item.itemType ? String(item.itemType).trim() : '',
            amount: Math.max(0, Number(item.amount) || Number(item.totalDebt) || 0),
            totalDebt: Math.max(0, Number(item.totalDebt) || Number(item.amount) || 0),
            totalPaid: Math.max(0, Number(item.totalPaid) || 0),
            status: item.status || 'active',
            userId: currentUser.id,
            createdAt: item.createdAt || new Date().toISOString(),
            lastTransactionDate: item.lastTransactionDate,
            history: Array.isArray(item.history) ? item.history : [],
          });
        });

        const totalDebt = cleanedDebtors.reduce((sum, d) => sum + d.amount, 0);
        const totalInstallmentsRemaining = cleanedInstallments.reduce(
          (sum, i) => sum + (i.remainingAmount || 0),
          0
        );
        const totalSuppliersDebt = cleanedSuppliers.reduce(
          (sum, s) => sum + (s.amount || 0),
          0
        );

        setPreview({
          fileName: file.name,
          exportDate,
          sourceBranch,
          managersCount: cleanedManagers.length,
          managersList: cleanedManagers,
          debtorsCount: cleanedDebtors.length,
          totalDebt,
          debtorsList: cleanedDebtors,
          installmentsCount: cleanedInstallments.length,
          totalInstallmentsRemaining,
          installmentsList: cleanedInstallments,
          suppliersCount: cleanedSuppliers.length,
          totalSuppliersDebt,
          suppliersList: cleanedSuppliers,
        });

        onShowToast(
          `${t('backup.importBtn', 'استيراد')}: ${cleanedManagers.length} مدراء • ${cleanedDebtors.length} مدينين • ${cleanedInstallments.length} أقساط • ${cleanedSuppliers.length} موردين`,
          'info'
        );
      } catch (parseErr: any) {
        console.error('JSON Parse error:', parseErr);
        onShowToast(
          `${t('backup.invalidJson', 'خطأ في قراءة الملف')}: ${parseErr.message || ''}`,
          'error'
        );
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    reader.onerror = () => {
      onShowToast(t('common.error', 'حدث خطأ أثناء قراءة الملف'), 'error');
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    reader.readAsText(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // ----------------------------------------------------
  // 3. CONFIRM & EXECUTE IMPORT
  // ----------------------------------------------------
  const handleConfirmImport = async () => {
    if (!preview) return;
    try {
      setIsImporting(true);
      if (onImportBackup) {
        await onImportBackup(
          preview.debtorsList,
          preview.installmentsList,
          importMode,
          preview.managersList,
          preview.suppliersList
        );
      } else if (onImportDebtors) {
        await onImportDebtors(preview.debtorsList, importMode);
      }
      setPreview(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    } catch (err: any) {
      console.error('Import execution error:', err);
    } finally {
      setIsImporting(false);
    }
  };

  const handleCancelImport = () => {
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const currentTotalDebt = debtors.reduce((sum, d) => sum + (d.amount || 0), 0);
  const currentTotalInstallmentsRemaining = installments.reduce(
    (sum, i) => sum + (Number(i.remainingAmount) || 0),
    0
  );
  const currentTotalSuppliersDebt = suppliers.reduce(
    (sum, s) => sum + (Number(s.amount) || Number(s.totalDebt) || 0),
    0
  );

  return (
    <div className={flat ? "space-y-4" : "bg-white rounded-3xl p-5 border border-slate-100 shadow-xs space-y-4"} dir={dir}>
      {/* Section Header */}
      {!flat && (
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center text-base font-bold shadow-xs">
              <i className="fa-solid fa-arrows-rotate"></i>
            </div>
            <div>
              <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                <span>
                  {isAdmin
                    ? t('backup.title', 'النسخ الاحتياطي الشامل للديون والأقساط والموردين')
                    : `النسخ الاحتياطي المحلي (${branchDisplayName})`}
                </span>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${isAdmin ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100'}`}>
                  {isAdmin ? t('login.secureBadge', 'آمن ومحمي') : 'خاص بالفرع'}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {isAdmin
                  ? 'تصدير نسخة متكاملة تشمل كافة سجلات المدينين وعقود الأقساط وحسابات الموردين أو استرجاعها'
                  : 'تصدير واسترجاع نسخة احتياطية محلية تشمل كافة سجلات المدينين وعقود الأقساط وحسابات الموردين لفرعك'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Current Data Overview */}
      {isAdmin ? (
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5 bg-slate-50 border border-slate-200/60 rounded-2xl p-3 text-xs">
          <div className="space-y-1.5 px-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('managers.title', 'المدراء والفروع')}:</span>
              <span className="font-bold font-mono text-purple-800 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {managers.length}
              </span>
            </div>
            <div className="text-[11px] text-slate-400">
              {t('settings.fullAdminOnly', 'خاص بالإدارة العامة')}
            </div>
          </div>

          <div className="space-y-1.5 px-2 border-s border-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('debts.title', 'المدينون')}:</span>
              <span className="font-bold font-mono text-slate-900 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {debtors.length}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('debtorHistory.totalDebts', 'إجمالي الديون')}:</span>
              <span className="font-bold font-mono text-blue-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalDebt, numberFormat)} {currSym}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 px-2 border-s border-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('installments.title', 'الأقساط')}:</span>
              <span className="font-bold font-mono text-emerald-800 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {installments.length}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('debtorHistory.currentBalance', 'المتبقي')}:</span>
              <span className="font-bold font-mono text-emerald-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalInstallmentsRemaining, numberFormat)} {currSym}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 px-2 border-s border-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">الموردون:</span>
              <span className="font-bold font-mono text-amber-800 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {suppliers.length}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">ديون الموردين:</span>
              <span className="font-bold font-mono text-amber-700 bg-white px-2 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalSuppliersDebt, numberFormat)} {currSym}
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-slate-50 border border-slate-200/60 rounded-2xl p-3 text-xs">
          <div className="space-y-1.5 px-2">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-1.5">
                <i className="fa-solid fa-users text-blue-500"></i>
                <span>{t('debts.title', 'مدينو الفرع')}:</span>
              </span>
              <span className="font-bold font-mono text-slate-900 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(debtors.length, numberFormat)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('debtorHistory.totalDebts', 'إجمالي الديون')}:</span>
              <span className="font-bold font-mono text-blue-700 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalDebt, numberFormat)} {currSym}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 px-2 sm:border-s sm:border-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-1.5">
                <i className="fa-solid fa-file-invoice-dollar text-emerald-500"></i>
                <span>{t('installments.title', 'عقود الأقساط')}:</span>
              </span>
              <span className="font-bold font-mono text-emerald-800 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(installments.length, numberFormat)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">{t('debtorHistory.currentBalance', 'المتبقي')}:</span>
              <span className="font-bold font-mono text-emerald-700 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalInstallmentsRemaining, numberFormat)} {currSym}
              </span>
            </div>
          </div>

          <div className="space-y-1.5 px-2 sm:border-s sm:border-slate-200">
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium flex items-center gap-1.5">
                <i className="fa-solid fa-truck-field text-amber-500"></i>
                <span>سجلات الموردين:</span>
              </span>
              <span className="font-bold font-mono text-amber-800 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(suppliers.length, numberFormat)}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500 font-medium">ديون الموردين:</span>
              <span className="font-bold font-mono text-amber-700 bg-white px-2.5 py-0.5 rounded-lg border border-slate-200">
                {formatNumber(currentTotalSuppliersDebt, numberFormat)} {currSym}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Action Cards: 1. Export, 2. Import */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        {/* Card 1: Export Backup */}
        <div className="bg-slate-50/70 border border-slate-200/70 rounded-2xl p-4 flex flex-col justify-between hover:border-blue-200 transition-all">
          <div>
            <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
              <i className="fa-solid fa-cloud-arrow-down text-blue-600"></i>
              <span>
                {isAdmin ? t('backup.exportBtn', 'تصدير نسخة احتياطية') : 'تصدير نسخة احتياطية للفرع'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              {isAdmin
                ? 'تنزيل ملف JSON يحتوي على كافة بيانات المدينين وسجلاتهم + كافة عقود الأقساط + حسابات الموردين.'
                : 'تنزيل ملف JSON يحتوي على كافة بيانات مديني فرعك وسجلاتهم وحركاتهم + عقود الأقساط + حسابات الموردين.'}
            </p>
          </div>

          <button
            type="button"
            onClick={handleExportBackup}
            disabled={isExporting || (debtors.length === 0 && installments.length === 0 && suppliers.length === 0)}
            className="mt-3.5 w-full bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isExporting ? (
              <>
                <i className="fa-solid fa-spinner fa-spin"></i>
                <span>{t('common.loading', 'جاري التصدير...')}</span>
              </>
            ) : (
              <>
                <i className="fa-solid fa-download text-xs"></i>
                <span>
                  {isAdmin
                    ? t('backup.exportBtn', 'تنزيل النسخة الاحتياطية (JSON)')
                    : 'تنزيل نسخة الفرع الاحتياطية (JSON)'}
                </span>
              </>
            )}
          </button>
        </div>

        {/* Card 2: Import Backup Trigger */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-2xl p-4 flex flex-col justify-between transition-all ${
            isDragging
              ? 'border-blue-500 bg-blue-50/50'
              : 'border-slate-200 bg-slate-50/70 hover:border-slate-300'
          }`}
        >
          <div>
            <div className="flex items-center gap-2 font-bold text-xs text-slate-800 mb-1">
              <i className="fa-solid fa-cloud-arrow-up text-emerald-600"></i>
              <span>
                {isAdmin ? t('backup.importBtn', 'استيراد واسترجاع نسخة') : 'استيراد واسترجاع نسخة للفرع'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 leading-relaxed">
              {isAdmin
                ? 'اسحب وأفلت ملف النسخة الاحتياطية هنا أو انقر لاختيار الملف من جهازك لاسترجاع الديون والأقساط والموردين.'
                : 'اسحب وأفلت ملف النسخة الاحتياطية (.json) هنا أو انقر لاختياره لاسترجاع ديون وأقساط فرعك وحسابات الموردين.'}
            </p>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileInputChange}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="mt-3.5 w-full bg-white hover:bg-slate-100 active:scale-[0.99] text-slate-700 border border-slate-200/80 py-2.5 px-3 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
          >
            <i className="fa-solid fa-folder-open text-xs text-slate-500"></i>
            <span>{t('backup.selectFile', 'اختيار ملف النسخة (.json)')}</span>
          </button>
        </div>
      </div>

      {/* Import Preview & Confirmation Dialog */}
      {preview && (
        <div className="mt-4 p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 animate-in fade-in zoom-in-95 duration-150 space-y-3">
          <div className="flex items-center justify-between border-b border-amber-200/70 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-xl bg-amber-500 text-white flex items-center justify-center text-xs">
                <i className="fa-solid fa-file-invoice"></i>
              </div>
              <div>
                <div className="font-extrabold text-xs text-slate-900">
                  {t('backup.title', 'معاينة محتويات النسخة الاحتياطية')}
                </div>
                <div className="text-[10.5px] text-slate-500 truncate max-w-[240px]">
                  {preview.fileName}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleCancelImport}
              className="text-slate-400 hover:text-slate-700 p-1 cursor-pointer transition-colors"
              title={t('common.cancel', 'إلغاء')}
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>
          </div>

          {!isAdmin && (
            <div className="bg-blue-50/80 border border-blue-200/70 rounded-xl p-2.5 text-xs text-blue-900 flex items-center gap-2">
              <i className="fa-solid fa-circle-info text-blue-600 shrink-0"></i>
              <span>
                سيتم استرجاع وتطبيق البيانات في حساب الفرع الحالي: <strong>{branchDisplayName}</strong>
              </span>
            </div>
          )}

          {/* Backup Meta Badges */}
          <div className={`grid grid-cols-2 ${isAdmin ? 'sm:grid-cols-6' : 'sm:grid-cols-5'} gap-2 text-xs`}>
            {isAdmin && (
              <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
                <span className="text-[10.5px] text-slate-400 block mb-0.5">{t('managers.title', 'المدراء')}</span>
                <span className="font-extrabold font-mono text-sm text-purple-800">
                  {preview.managersCount}
                </span>
              </div>
            )}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">{t('debts.title', 'المدينين')}</span>
              <span className="font-extrabold font-mono text-sm text-slate-800">
                {preview.debtorsCount}
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">{t('debtorHistory.totalDebts', 'إجمالي الديون')}</span>
              <span className="font-extrabold font-mono text-sm text-blue-700">
                {formatNumber(preview.totalDebt, numberFormat)} {currSym}
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">{t('installments.title', 'الأقساط')}</span>
              <span className="font-extrabold font-mono text-sm text-emerald-800">
                {preview.installmentsCount}
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">الموردين</span>
              <span className="font-extrabold font-mono text-sm text-amber-800">
                {preview.suppliersCount}
              </span>
            </div>
            <div className="bg-white p-2.5 rounded-xl border border-amber-200/50">
              <span className="text-[10.5px] text-slate-400 block mb-0.5">ديون الموردين</span>
              <span className="font-extrabold font-mono text-sm text-amber-700">
                {formatNumber(preview.totalSuppliersDebt, numberFormat)} {currSym}
              </span>
            </div>
          </div>

          {/* Import Mode Selector */}
          <div className="bg-white p-3 rounded-xl border border-amber-200/60 space-y-2">
            <span className="text-[11px] font-bold text-slate-700 block">{t('common.status', 'طريقة التطبيق')}:</span>
            <div className="space-y-1.5">
              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-slate-50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="merge"
                  checked={importMode === 'merge'}
                  onChange={() => setImportMode('merge')}
                  className="text-blue-600 focus:ring-blue-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-slate-800">{t('backup.modeMerge', 'دمج مع البيانات الحالية')}</span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    إضافة السجلات الجديدة وتحديث المبالغ دون مسح السجلات القديمة
                  </span>
                </div>
              </label>

              <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded-lg hover:bg-rose-50/50 transition-colors">
                <input
                  type="radio"
                  name="importMode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                  className="text-rose-600 focus:ring-rose-500 w-4 h-4 cursor-pointer"
                />
                <div className="text-xs">
                  <span className="font-bold text-rose-700">{t('backup.modeReplace', 'استبدال البيانات الحالية بالكامل')}</span>
                  <span className="text-[11px] text-slate-400 block mt-0.5">
                    مسح السجلات السابقة للحساب واستبدالها بمحتويات هذه النسخة بالكامل
                  </span>
                </div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleConfirmImport}
              disabled={isImporting}
              className={`flex-1 text-white py-2.5 px-4 rounded-xl font-bold text-xs transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs disabled:opacity-50 ${
                importMode === 'replace'
                  ? 'bg-rose-600 hover:bg-rose-700'
                  : 'bg-emerald-600 hover:bg-emerald-700'
              }`}
            >
              {isImporting ? (
                <>
                  <i className="fa-solid fa-spinner fa-spin"></i>
                  <span>{t('common.loading', 'جاري التطبيق...')}</span>
                </>
              ) : (
                <>
                  <i className="fa-solid fa-check text-xs"></i>
                  <span>{t('common.confirm', 'تأكيد واسترجاع البيانات')}</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleCancelImport}
              disabled={isImporting}
              className="bg-slate-200/80 hover:bg-slate-300 active:scale-95 text-slate-700 py-2.5 px-3 rounded-xl font-bold text-xs transition-all cursor-pointer"
            >
              {t('common.cancel', 'إلغاء')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

