import React, { useState } from 'react';
import { Supplier } from '../types';
import { formatAmountInput, parseFormattedNumber } from '../utils/formatters';

interface AddSupplierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddSupplier: (supplier: Omit<Supplier, 'id' | 'userId'>) => void;
  currencySymbol?: string;
}

export const AddSupplierModal: React.FC<AddSupplierModalProps> = ({
  isOpen,
  onClose,
  onAddSupplier,
  currencySymbol = 'د.ع',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [itemType, setItemType] = useState('');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [dateMode, setDateMode] = useState<'auto' | 'manual'>('auto');
  const [manualDate, setManualDate] = useState(new Date().toISOString().split('T')[0]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFormattedNumber(amount);
    if (!name.trim() || isNaN(numAmount) || numAmount <= 0) {
      alert('يرجى كتابة اسم المورد والمبلغ المطلوب بشكل صحيح.');
      return;
    }

    const cleanPhone = phone.trim();
    const finalIsoDate = dateMode === 'auto'
      ? new Date().toISOString()
      : new Date(`${manualDate}T12:00:00`).toISOString();

    onAddSupplier({
      name: name.trim(),
      phone: cleanPhone,
      companyName: companyName.trim() || undefined,
      itemType: itemType.trim() || undefined,
      amount: numAmount,
      status: 'active',
      notes: notes.trim() || undefined,
      createdAt: finalIsoDate,
      lastTransactionDate: finalIsoDate,
      history: [
        {
          id: Date.now().toString() + Math.random().toString(36).substring(2, 6),
          supplierId: 0,
          type: 'initial',
          amount: numAmount,
          balanceAfter: numAmount,
          date: finalIsoDate,
          description: 'تسجيل دين بضاعة مسبق / جديد',
          notes: notes.trim() || undefined,
          itemType: itemType.trim() || undefined,
        },
      ],
    });

    // Reset fields & Close
    setName('');
    setPhone('');
    setCompanyName('');
    setItemType('');
    setAmount('');
    setNotes('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh] animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-600 via-amber-700 to-orange-700 p-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-lg shrink-0">
              <i className="fa-solid fa-truck-field text-amber-100"></i>
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base">إضافة مورد أو شركة بضاعة جديدة</h3>
              <p className="text-[11px] text-amber-100/90 font-medium">تسجيل دين عليك لصالح المورد / المصنع</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors cursor-pointer"
          >
            <i className="fa-solid fa-xmark text-sm"></i>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 overflow-y-auto text-start">
          {/* Supplier Name & Phone */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                اسم المورد / المندوب <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثل: أحمد علي"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                رقم هاتف المورد (واتساب)
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0770xxxxxxx"
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all text-left dir-ltr"
              />
            </div>
          </div>

          {/* Company Name */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              اسم الشركة / المعمل / المكتب
            </label>
            <input
              type="text"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="مثال: شركة النور للأجهزة"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all"
            />
          </div>

          {/* Larger Item Type Field */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              تفاصيل ونوع البضاعة / المواد <span className="text-slate-400 font-normal">(موسع)</span>
            </label>
            <textarea
              rows={2}
              value={itemType}
              onChange={(e) => setItemType(e.target.value)}
              placeholder="اكتب نوع أو تفاصيل البضاعة (مثل: أجهزة كهربائية، ملابس، مواد غذائية...)"
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none leading-relaxed"
            />
          </div>

          {/* Amount Field */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              المبلغ المطلوب للمورد (الذمة القائمة عليك) <span className="text-rose-500">*</span>
            </label>
            <div className="relative flex items-center">
              <input
                type="text"
                inputMode="numeric"
                required
                value={amount}
                onChange={(e) => setAmount(formatAmountInput(e.target.value))}
                placeholder="أدخل المبلغ بالأرقام (مثال: 250,000)..."
                className="w-full p-3 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800/80 rounded-2xl text-sm font-extrabold text-amber-900 dark:text-amber-200 outline-none focus:border-amber-600 focus:ring-2 focus:ring-amber-500/30 transition-all"
              />
              <span className="absolute left-3 text-xs font-extrabold text-amber-700 dark:text-amber-400">
                {currencySymbol}
              </span>
            </div>
          </div>

          {/* Date Selector: Auto vs Manual */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <i className="fa-regular fa-calendar-days text-amber-600"></i>
                <span>تاريخ تسجيل المورد والدين:</span>
              </label>

              <div className="flex items-center gap-1 bg-slate-200/80 dark:bg-slate-700/80 p-0.5 rounded-xl text-[11px] font-bold">
                <button
                  type="button"
                  onClick={() => setDateMode('auto')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    dateMode === 'auto'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  تلقائي (اليوم)
                </button>
                <button
                  type="button"
                  onClick={() => setDateMode('manual')}
                  className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                    dateMode === 'manual'
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
                  }`}
                >
                  يدوي (تاريخ محدد)
                </button>
              </div>
            </div>

            {dateMode === 'manual' ? (
              <input
                type="date"
                required
                value={manualDate}
                onChange={(e) => setManualDate(e.target.value)}
                className="w-full p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-xl text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-amber-500"
              />
            ) : (
              <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                سيتم الاعتماد على تاريخ وساعة اليوم الحالية تلقائياً: <span className="font-bold text-amber-700 dark:text-amber-400">{new Date().toISOString().split('T')[0]}</span>
              </p>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
              ملاحظات أو تفاصيل الفاتورة/الوصل
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="تفاصيل العقد أو قائمة الشراء بالأجل..."
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-medium text-slate-900 dark:text-white outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 transition-all resize-none"
            />
          </div>

          {/* Submit Button */}
          <div className="pt-2 flex items-center gap-2">
            <button
              type="submit"
              className="flex-1 py-3 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer active:scale-98 flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-check text-xs"></i>
              <span>حفظ المورد</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="py-3 px-4 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs transition-all cursor-pointer"
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
