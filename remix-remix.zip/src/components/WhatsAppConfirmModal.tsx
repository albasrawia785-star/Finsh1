import React from 'react';
import { WhatsAppNotificationData } from '../utils/whatsapp';

interface WhatsAppConfirmModalProps {
  notice: WhatsAppNotificationData | null;
  onConfirm: (notice: WhatsAppNotificationData) => void;
  onCancel: () => void;
}

export const WhatsAppConfirmModal: React.FC<WhatsAppConfirmModalProps> = ({
  notice,
  onConfirm,
  onCancel,
}) => {
  if (!notice) return null;

  return (
    <div
      id="whatsappConfirmModal"
      className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex justify-center items-center z-50 p-4 animate-in fade-in duration-150 text-start"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl relative border border-slate-100 text-center animate-in zoom-in-95 duration-150">
        {/* Icon */}
        <div className="w-13 h-13 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-2xl mx-auto mb-3.5 border border-emerald-100 shadow-inner">
          <i className="fa-brands fa-whatsapp"></i>
        </div>

        {/* Title & Question */}
        <h3 className="font-bold text-base text-slate-800 mb-1.5">
          إرسال إشعار عبر واتساب
        </h3>

        <p className="text-xs text-slate-600 mb-1 leading-relaxed">
          هل ترغب في إرسال تفاصيل هذه العملية إلى العميل عبر تطبيق واتساب؟
        </p>

        {/* Customer info card */}
        <div className="my-3 py-2 px-3 bg-slate-50 border border-slate-100 rounded-xl text-center">
          <span className="font-bold text-slate-800 text-xs">{notice.customerName}</span>
          <span className="text-slate-400 mx-1.5">•</span>
          <span className="font-mono text-slate-600 text-xs" dir="ltr">{notice.phone}</span>
        </div>

        {/* Actions */}
        <div className="flex gap-2.5 mt-4">
          <button
            type="button"
            onClick={() => onConfirm(notice)}
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white py-2.5 px-3 rounded-xl font-bold text-xs shadow-md shadow-emerald-600/20 cursor-pointer transition-all flex items-center justify-center gap-1.5"
          >
            <i className="fa-brands fa-whatsapp text-sm"></i>
            <span>إرسال الآن</span>
          </button>

          <button
            type="button"
            onClick={onCancel}
            className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 py-2.5 px-3 rounded-xl font-bold text-xs cursor-pointer transition-all"
          >
            تخطي
          </button>
        </div>
      </div>
    </div>
  );
};
