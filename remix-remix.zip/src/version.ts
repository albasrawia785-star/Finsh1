export const CURRENT_APP_VERSION = 'v3.5';
