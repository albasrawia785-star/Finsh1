const fs = require('fs');
const path = require('path');

const ar = JSON.parse(fs.readFileSync('src/locales/ar.json', 'utf8'));

function flattenObj(obj, prefix = '') {
  let result = {};
  for (const key in obj) {
    const fullKey = prefix ? prefix + '.' + key : key;
    if (typeof obj[key] === 'object' && obj[key] !== null) {
      Object.assign(result, flattenObj(obj[key], fullKey));
    } else {
      result[fullKey] = obj[key];
    }
  }
  return result;
}

const arFlat = flattenObj(ar);
const arKeys = new Set(Object.keys(arFlat));

function getFiles(dir) {
  let results = [];
  const list = fs.readdirSync(dir);
  list.forEach(file => {
    const fullPath = path.join(dir, file);
    const stat = fs.statSync(fullPath);
    if (stat && stat.isDirectory()) {
      if (file !== 'locales' && file !== 'node_modules') {
        results = results.concat(getFiles(fullPath));
      }
    } else if (file.endsWith('.tsx') || file.endsWith('.ts')) {
      results.push(fullPath);
    }
  });
  return results;
}

const allFiles = getFiles('src');
const missingList = [];

allFiles.forEach(file => {
  const content = fs.readFileSync(file, 'utf8');
  // Match \bt('key', 'default') or \bt('key', `default`)
  const regex = /(?:^|[^a-zA-Z0-9_])t\(\s*['"]([a-zA-Z0-9_.]+)['"]\s*(?:,\s*(?:'([^']*)'|"([^"]*)"|`([^`]*)`))?/g;
  let match;
  while ((match = regex.exec(content)) !== null) {
    const key = match[1];
    const defaultVal = match[2] || match[3] || match[4] || '';
    if (!arKeys.has(key)) {
      missingList.push({ file, key, defaultVal });
    }
  }
});

console.log('Total real missing calls:', missingList.length);
// Group by key
const byKey = {};
missingList.forEach(item => {
  if (!byKey[item.key]) {
    byKey[item.key] = { defaults: new Set(), files: new Set() };
  }
  byKey[item.key].files.add(item.file);
  if (item.defaultVal) byKey[item.key].defaults.add(item.defaultVal);
});

console.log('Total unique missing real keys:', Object.keys(byKey).length);
fs.writeFileSync('missing_keys.json', JSON.stringify(byKey, (k, v) => v instanceof Set ? Array.from(v) : v, 2));
console.log('Saved to missing_keys.json');
