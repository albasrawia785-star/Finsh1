const sharp = require('sharp');
const fs = require('fs');
const path = require('path');

const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <!-- Background Gradient -->
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#000000"/>
      <stop offset="100%" stop-color="#050811"/>
    </linearGradient>

    <!-- White D Gradient -->
    <linearGradient id="dGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#ffffff"/>
      <stop offset="85%" stop-color="#f1f5f9"/>
      <stop offset="100%" stop-color="#cbd5e1"/>
    </linearGradient>

    <!-- Green Q Gradient -->
    <linearGradient id="qGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#34d399"/>
      <stop offset="50%" stop-color="#10b981"/>
      <stop offset="100%" stop-color="#059669"/>
    </linearGradient>

    <linearGradient id="greenAccentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#10b981"/>
      <stop offset="100%" stop-color="#34d399"/>
    </linearGradient>

    <!-- Soft Drop Shadows -->
    <filter id="dropShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="8" stdDeviation="12" flood-color="#000000" flood-opacity="0.6"/>
    </filter>
  </defs>

  <!-- Background Layer -->
  <rect width="512" height="512" fill="url(#bgGrad)"/>

  <g transform="translate(10, 0)">
    <!-- RIGHT SIDE: THE "Q" CIRCLE & TAIL -->
    <g filter="url(#dropShadow)">
      <!-- Q Tail -->
      <path d="M 360,330 L 440,380 C 455,390 440,410 420,400 L 340,350 Z" fill="url(#qGrad)"/>
      <path d="M 370,335 L 435,385 C 448,393 438,408 420,398 L 350,345 Z" fill="#059669"/>
      
      <!-- Q Outer Circle -->
      <circle cx="330" cy="256" r="120" fill="url(#qGrad)"/>
      
      <!-- Q Inner Black Hole -->
      <circle cx="330" cy="256" r="70" fill="#000000"/>

      <!-- Dollar Sign ($) inside Q -->
      <text x="330" y="280" font-family="Arial, Helvetica, sans-serif" font-size="78" font-weight="900" fill="#ffffff" text-anchor="middle">$</text>
    </g>

    <!-- LEFT SIDE: THE NOTEBOOK "D" -->
    <g filter="url(#dropShadow)">
      <!-- Underneath Green Ribbon/Fold under D -->
      <path d="M 120,320 C 180,380 270,395 285,280 C 240,360 170,370 120,320 Z" fill="url(#greenAccentGrad)"/>
      
      <!-- Main White "D" Body (Spiral Notebook shape) -->
      <path d="M 95,120 L 210,120 C 290,120 310,180 310,240 C 310,300 290,360 210,360 L 95,360 C 88,360 82,354 82,347 L 82,133 C 82,126 88,120 95,120 Z" fill="url(#dGrad)"/>

      <!-- D Inner Cutout (Black) -->
      <path d="M 135,160 L 200,160 C 245,160 255,200 255,240 C 255,280 245,320 200,320 L 135,320 Z" fill="#000000"/>

      <!-- 3 Green Horizontal Ledger Lines inside D -->
      <rect x="150" y="195" width="70" height="12" rx="6" fill="url(#greenAccentGrad)"/>
      <rect x="150" y="234" width="75" height="12" rx="6" fill="url(#greenAccentGrad)"/>
      <rect x="150" y="273" width="60" height="12" rx="6" fill="url(#greenAccentGrad)"/>

      <!-- 4 Green Binder Rings on the Spine (Left) -->
      <rect x="62" y="145" width="38" height="18" rx="9" fill="url(#greenAccentGrad)" stroke="#059669" stroke-width="2"/>
      <rect x="62" y="198" width="38" height="18" rx="9" fill="url(#greenAccentGrad)" stroke="#059669" stroke-width="2"/>
      <rect x="62" y="251" width="38" height="18" rx="9" fill="url(#greenAccentGrad)" stroke="#059669" stroke-width="2"/>
      <rect x="62" y="304" width="38" height="18" rx="9" fill="url(#greenAccentGrad)" stroke="#059669" stroke-width="2"/>
    </g>
  </g>
</svg>`;

async function generate() {
  const publicDir = path.join(__dirname, '..', 'public');
  const rootDir = path.join(__dirname, '..');

  // Write SVG
  fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf8');

  const svgBuffer = Buffer.from(svgContent);

  // Generate PNGs
  await sharp(svgBuffer).resize(512, 512).toFile(path.join(publicDir, 'og-image.png'));
  await sharp(svgBuffer).resize(512, 512).toFile(path.join(publicDir, 'pwa-512x512.png'));
  await sharp(svgBuffer).resize(512, 512).toFile(path.join(publicDir, 'pwa-maskable-512x512.png'));
  await sharp(svgBuffer).resize(192, 192).toFile(path.join(publicDir, 'pwa-192x192.png'));
  await sharp(svgBuffer).resize(180, 180).toFile(path.join(publicDir, 'apple-touch-icon.png'));
  await sharp(svgBuffer).resize(512, 512).toFile(path.join(rootDir, 'icon.png'));

  console.log('Successfully generated all logo assets!');
}

generate().catch(console.error);
