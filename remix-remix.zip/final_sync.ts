import { ALDION_DATABASE_CONFIG } from './aldion';

const primaryUrl = ALDION_DATABASE_CONFIG.url;
const primaryToken = ALDION_DATABASE_CONFIG.token;

const secondUrl = "https://aldin-albasrawia2026.aws-ap-south-1.turso.io/v2/pipeline";
const secondToken = "eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3OTAxNjI5ODgsImlkIjoiMDFhMGNlMDctMDIwMS03ZTdmLTlhNTQtMTA2NzRhNDVmZjI3Iiwia2lkIjoiQkxmRmNZbUs2YmhFMUIzaFBQLUFwb1BodVloaXczU1dYZXdLUjRvN0t0ZyIsInJpZCI6IjQ5YWVkZDU4LTgxYjAtNDc4Zi1iYjFkLWM3MjYyMDM0NGUyNCJ9.i_OKfJWt35_DvinmHnCqmHGL1B7PicsuLxajyWR4OkN8oM8DgHN2ETQI9OihAe0sHMSoLR2yjNsSLJuzHTH_DQ";

async function query(url, token, sql, args = []) {
  const formattedArgs = args.map((a) => {
    if (typeof a === "number") {
      return Number.isInteger(a) ? { type: "integer", value: String(a) } : { type: "float", value: String(a) };
    }
    if (a === null || a === undefined) return { type: "null" };
    return { type: "text", value: String(a) };
  });

  const res = await fetch(url, {
    method: "POST",
    headers: { "Authorization": "Bearer " + token, "Content-Type": "application/json" },
    body: JSON.stringify({
      requests: [
        { type: "execute", stmt: { sql, args: formattedArgs } },
        { type: "close" }
      ]
    })
  });
  return await res.json();
}

async function syncAll() {
  console.log("=== SYNC USERS ===");
  const uRes = await query(primaryUrl, primaryToken, "SELECT id, username, password, role, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, database_id FROM users;");
  for (const r of uRes.results[0].response.result.rows) {
    const val = (i) => r[i]?.value ?? r[i];
    await query(secondUrl, secondToken, `
      INSERT INTO users (id, username, password, role, branch_name, is_active, subscription_type, subscription_expires_at, plain_password, database_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET username=excluded.username, password=excluded.password, role=excluded.role, branch_name=excluded.branch_name, is_active=excluded.is_active, subscription_type=excluded.subscription_type, subscription_expires_at=excluded.subscription_expires_at, plain_password=excluded.plain_password, database_id=excluded.database_id;
    `, [val(0), val(1), val(2), val(3), val(4), val(5), val(6), val(7), val(8), val(9)]);
  }

  console.log("=== SYNC DEBTORS ===");
  const dRes = await query(primaryUrl, primaryToken, "SELECT id, name, phone, amount, status, user_id, created_at, history FROM debtors;");
  for (const r of dRes.results[0].response.result.rows) {
    const val = (i) => r[i]?.value ?? r[i];
    await query(secondUrl, secondToken, `
      INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone, amount=excluded.amount, status=excluded.status, user_id=excluded.user_id, created_at=excluded.created_at, history=excluded.history;
    `, [val(0), val(1), val(2), val(3), val(4), val(5), val(6), val(7)]);
  }

  console.log("=== SYNC INSTALLMENTS ===");
  const iRes = await query(primaryUrl, primaryToken, "SELECT id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, last_payment_date, total_paid FROM installments;");
  for (const r of iRes.results[0].response.result.rows) {
    const val = (i) => r[i]?.value ?? r[i];
    await query(secondUrl, secondToken, `
      INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, last_payment_date, total_paid)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET name=excluded.name, phone=excluded.phone, item=excluded.item, total_amount=excluded.total_amount, down_payment=excluded.down_payment, remaining_amount=excluded.remaining_amount, monthly_installment_amount=excluded.monthly_installment_amount, registration_date=excluded.registration_date, next_due_date=excluded.next_due_date, user_id=excluded.user_id, status=excluded.status, notes=excluded.notes, payments=excluded.payments, last_payment_date=excluded.last_payment_date, total_paid=excluded.total_paid;
    `, [val(0), val(1), val(2), val(3), val(4), val(5), val(6), val(7), val(8), val(9), val(10), val(11), val(12), val(13), val(14), val(15)]);
  }

  const uCount = await query(secondUrl, secondToken, "SELECT COUNT(*) FROM users;");
  const dCount = await query(secondUrl, secondToken, "SELECT COUNT(*) FROM debtors;");
  const iCount = await query(secondUrl, secondToken, "SELECT COUNT(*) FROM installments;");

  console.log("SYNC COMPLETE!", {
    users: uCount.results[0].response.result.rows[0][0].value,
    debtors: dCount.results[0].response.result.rows[0][0].value,
    installments: iCount.results[0].response.result.rows[0][0].value,
  });
}

syncAll().catch(console.error);
