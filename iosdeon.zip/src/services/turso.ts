import { AppSettings, Debtor, DebtorTransaction, Manager, User, InstallmentRecord, DatabaseAccount } from '../types';
import { generateShieldHeaders } from '../utils/securityShield';
import { ALDION_DATABASE_CONFIG, SECONDARY_DATABASE_CONFIG, BACKUP_SYNC_DATABASES, normalizeTursoUrl } from '../aldion';

/**
 * Returns the backend API server base URL.
 * Supports:
 * 1. Custom URL set in settings / APK config (localStorage: aldion_backend_server_url)
 * 2. Current origin in web browser (window.location.origin)
 * 3. Default production Cloud Run backend host
 */
export function getBackendBaseUrl(): string {
  if (typeof window === 'undefined') return '';

  const saved = localStorage.getItem('aldion_backend_server_url');
  if (saved && saved.trim()) {
    return saved.trim().replace(/\/+$/, '');
  }

  // If running directly on Cloud Run backend, return current origin
  if (
    typeof window !== 'undefined' &&
    window.location &&
    window.location.origin &&
    window.location.origin.startsWith('http') &&
    window.location.origin.includes('run.app')
  ) {
    return window.location.origin;
  }

  // Default production Cloud Run backend host for Netlify / external static domains / mobile APKs
  return 'https://ais-pre-3qeeb6jl5bktm64omzuibv-349740974703.europe-west2.run.app';
}

export function setBackendBaseUrl(url: string) {
  if (url && url.trim()) {
    localStorage.setItem('aldion_backend_server_url', url.trim().replace(/\/+$/, ''));
  } else {
    localStorage.removeItem('aldion_backend_server_url');
  }
}

/**
 * محرك استعلام مدمج مشفر (Embedded Encrypted Engine)
 * يعمل تلقائياً عند تحويل المشروع إلى PWA أو تطبيق هاتف أو استضافة ثابتة،
 * بحيث يستخرج الرابط والتوكن المشفرين بالبايتات ويتصل بالقاعدة مباشرة دون الحاجة لأي خادم خارجي.
 */
export async function queryCustomTursoDirect(
  url: string,
  token: string,
  trimmedSql: string,
  args: (string | number | null | undefined)[]
) {
  if (!url || !token) {
    throw new Error('بيانات الاتصال بقاعدة البيانات غير مهيأة');
  }

  if (url.includes('app.turso.tech')) {
    throw new Error('رابط لوحة التحكم غير صالح كإندبوينت لقاعدة البيانات. يرجى استخدام رابط الاتصال المباشر بصيغة libsql://your-db-org.turso.io');
  }

  const normalizedUrl = normalizeTursoUrl(url);

  const formattedArgs = args.map((a) => {
    if (typeof a === 'number') {
      return Number.isInteger(a)
        ? { type: 'integer', value: String(a) }
        : { type: 'float', value: String(a) };
    }
    if (a === null || a === undefined) {
      return { type: 'null' };
    }
    return { type: 'text', value: String(a) };
  });

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(normalizedUrl, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token.trim()}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        requests: [
          { type: 'execute', stmt: { sql: trimmedSql, args: formattedArgs } },
          { type: 'close' },
        ],
      }),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      if (normalizedUrl.includes('app.turso.tech')) {
        throw new Error('رابط لوحة التحكم غير صالح كإندبوينت لقاعدة البيانات. يرجى التوجه إلى لوحة Turso ونسخ رابط القراءة والكتابة بصيغة libsql://your-db-org.turso.io');
      }
      throw new Error(`تعذر الاتصال برابط قاعدة البيانات (${res.status}): يرجى التأكد من استخدام رابط القاعدة الصحيح بصيغة libsql://...turso.io`);
    }

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      throw new Error(`خطأ في قاعدة البيانات السحابية (${res.status}): ${errText.slice(0, 100) || res.statusText}`);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في استعلام قاعدة البيانات');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('انتهت مهلة الاتصال بقاعدة البيانات السحابية (Timeout)');
    }
    if (err.message === 'Failed to fetch' || err instanceof TypeError) {
      throw new Error('تعذر الاتصال بالقاعدة (Failed to fetch). يرجى التأكد من صحة رابط الاتصال المباشر المبتدئ بـ libsql:// وتوفر الإنترنت');
    }
    throw err;
  }
}

async function queryEmbeddedEncryptedTurso(trimmedSql: string, args: (string | number | null | undefined)[]) {
  const isWrite = /^(INSERT|UPDATE|DELETE|CREATE|DROP|ALTER)/i.test(trimmedSql);

  try {
    const res = await queryCustomTursoDirect(ALDION_DATABASE_CONFIG.url, ALDION_DATABASE_CONFIG.token, trimmedSql, args);
    // الكتابة المزدوجة اللحظية (Multi-Live Sync) في جميع القواعد الثانوية بشكل متوازي
    if (isWrite && Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
      BACKUP_SYNC_DATABASES.forEach((dbConfig) => {
        if (dbConfig.url && dbConfig.token) {
          queryCustomTursoDirect(dbConfig.url, dbConfig.token, trimmedSql, args).catch((e) => {
            console.warn(`Multi-sync to secondary DB (${dbConfig.name}) warning:`, e);
          });
        }
      });
    }
    return res;
  } catch (primaryErr) {
    console.warn('Primary DB unavailable, attempting fallback through backup databases:', primaryErr);
    // التبديل التلقائي السلس للقواعد الثانوية بالترتيب عند تعطل الرئيسية (Failover Chain)
    if (Array.isArray(BACKUP_SYNC_DATABASES) && BACKUP_SYNC_DATABASES.length > 0) {
      for (const dbConfig of BACKUP_SYNC_DATABASES) {
        if (dbConfig.url && dbConfig.token) {
          try {
            console.log(`Seamlessly failing over to backup database: ${dbConfig.name}`);
            return await queryCustomTursoDirect(dbConfig.url, dbConfig.token, trimmedSql, args);
          } catch (fallbackErr) {
            console.warn(`Backup DB (${dbConfig.name}) also failed:`, fallbackErr);
          }
        }
      }
    }
    throw primaryErr;
  }
}

/**
 * استعلام موجه حصراً للقاعدة الرئيسية (Central Main Database)
 * دون توجيهها للقواعد الفرعية للمدراء، لاستخدامها في مصادقة وإدارة الحسابات
 */
export async function queryMainTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (!res.ok) {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    return data;
  } catch {
    clearTimeout(timeoutId);
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }
}

export const DATABASE_SCHEMA_STATEMENTS = [
  `CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL
  );`,
  `CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    branch_name TEXT DEFAULT 'الفرع الرئيسي',
    phone_or_email TEXT,
    is_active INTEGER DEFAULT 1,
    is_new_registration INTEGER DEFAULT 0,
    subscription_type TEXT DEFAULT 'permanent',
    subscription_expires_at TEXT,
    plain_password TEXT,
    allowed_modules TEXT,
    created_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS debtors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    amount REAL DEFAULT 0,
    status TEXT DEFAULT 'دين مرتفع',
    user_id INTEGER DEFAULT 1,
    created_at TEXT,
    history TEXT,
    last_debt_date TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS installments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT,
    item TEXT NOT NULL,
    total_amount REAL DEFAULT 0,
    down_payment REAL DEFAULT 0,
    remaining_amount REAL DEFAULT 0,
    monthly_installment_amount REAL DEFAULT 0,
    registration_date TEXT,
    next_due_date TEXT,
    user_id INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active',
    notes TEXT,
    payments TEXT,
    created_at TEXT,
    national_id TEXT,
    address TEXT,
    guarantor_enabled INTEGER DEFAULT 0,
    guarantor_name TEXT,
    guarantor_address TEXT,
    guarantor_job TEXT,
    guarantor_relation TEXT,
    guarantor_phone TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS user_settings (
    user_id INTEGER PRIMARY KEY,
    settings_json TEXT NOT NULL,
    updated_at TEXT
  );`,
  `CREATE TABLE IF NOT EXISTS databases_registry (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    url TEXT NOT NULL,
    token TEXT NOT NULL,
    description TEXT,
    is_default INTEGER DEFAULT 0,
    created_at TEXT
  );`,
  "ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1;",
  "ALTER TABLE users ADD COLUMN subscription_type TEXT DEFAULT 'permanent';",
  "ALTER TABLE users ADD COLUMN subscription_expires_at TEXT;",
  "ALTER TABLE users ADD COLUMN plain_password TEXT;",
  "ALTER TABLE users ADD COLUMN allowed_modules TEXT;",
  "ALTER TABLE users ADD COLUMN phone_or_email TEXT;",
  "ALTER TABLE users ADD COLUMN is_new_registration INTEGER DEFAULT 0;",
  "ALTER TABLE users ADD COLUMN created_at TEXT;",
  "ALTER TABLE debtors ADD COLUMN created_at TEXT;",
  "ALTER TABLE debtors ADD COLUMN history TEXT;",
  "ALTER TABLE debtors ADD COLUMN last_debt_date TEXT;",
  "ALTER TABLE installments ADD COLUMN notes TEXT;",
  "ALTER TABLE installments ADD COLUMN payments TEXT;",
  "ALTER TABLE installments ADD COLUMN created_at TEXT;",
  "ALTER TABLE installments ADD COLUMN national_id TEXT;",
  "ALTER TABLE installments ADD COLUMN address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_enabled INTEGER DEFAULT 0;",
  "ALTER TABLE installments ADD COLUMN guarantor_name TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_address TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_job TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_relation TEXT;",
  "ALTER TABLE installments ADD COLUMN guarantor_phone TEXT;",
  "CREATE INDEX IF NOT EXISTS idx_debtors_user_id ON debtors(user_id);",
  "CREATE INDEX IF NOT EXISTS idx_debtors_name ON debtors(name);",
  "CREATE INDEX IF NOT EXISTS idx_installments_user_id ON installments(user_id);",
  "CREATE INDEX IF NOT EXISTS idx_installments_status ON installments(status);",
  "CREATE INDEX IF NOT EXISTS idx_installments_next_due_date ON installments(next_due_date);",
  "CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);",
];

/**
 * تهيئة وتجهيز قاعدة البيانات السحابية بالكامل فوراً
 * لإنشاء كافة جداول الديون والأقساط والمستخدمين والإعدادات
 */
export async function initializeCustomTursoDatabase(
  url: string,
  token: string
): Promise<{ ok: boolean; message: string; count?: number }> {
  if (!url || !token) {
    return { ok: false, message: 'رابط القاعدة أو التوكن غير متوفر' };
  }

  let successCount = 0;
  for (const sql of DATABASE_SCHEMA_STATEMENTS) {
    try {
      await queryCustomTursoDirect(url.trim(), token.trim(), sql, []);
      successCount++;
    } catch {
      // تجاهل أخطاء الأعمدة أو الجداول إذا كانت موجودة مسبقاً (Table/Column already exists)
    }
  }

  return {
    ok: true,
    message: 'تمت تهيئة وتجهيز هيكل قاعدة البيانات لاستقبال البيانات بنجاح',
    count: successCount,
  };
}

/**
 * تهيئة وتجهيز كافة القواعد الاحتياطية سحابياً والجداول الخاصة بها تلقائياً
 */
export async function bootstrapAllBackupDatabases(): Promise<void> {
  if (Array.isArray(BACKUP_SYNC_DATABASES)) {
    for (const dbConfig of BACKUP_SYNC_DATABASES) {
      if (dbConfig.url && dbConfig.token) {
        initializeCustomTursoDatabase(dbConfig.url, dbConfig.token).catch((err) => {
          console.warn(`Error initializing backup db (${dbConfig.name}):`, err);
        });
      }
    }
  }
}

// تشغيل التهيئة التلقائية للقواعد الرديفة فورياً في الخلفية
bootstrapAllBackupDatabases().catch(() => {});

/**
 * فحص الاتصال بقاعدة البيانات واختبار سرعة الاستجابة وتهيئة الجداول تلقائياً (Test Connection & Bootstrap)
 */
export async function testDatabaseConnection(
  url: string,
  token: string,
  autoBootstrap: boolean = true
): Promise<{ ok: boolean; message: string; latencyMs?: number; initialized?: boolean }> {
  if (!url || !token) {
    return { ok: false, message: 'يرجى إدخال رابط قاعدة البيانات ومفتاح التوكن' };
  }

  if (url.includes('app.turso.tech')) {
    return {
      ok: false,
      message: 'تنبيه: الرابط المدخل هو رابط لوحة التحكم (app.turso.tech). يرجى نسخ رابط الاتصال المباشر بالقاعدة والذي يبدأ بـ libsql:// أو ينتهي بـ .turso.io',
    };
  }

  const startTime = Date.now();
  try {
    await queryCustomTursoDirect(url.trim(), token.trim(), 'SELECT 1;', []);
    const latencyMs = Date.now() - startTime;

    if (autoBootstrap) {
      await initializeCustomTursoDatabase(url, token);
      return {
        ok: true,
        message: `تم فحص الاتصال بنجاح وتهيئة كافة جداول الديون والأقساط لاستقبال البيانات فوراً (${latencyMs}ms)`,
        latencyMs,
        initialized: true,
      };
    }

    return { ok: true, message: `الاتصال ناجح واستجابة القاعدة فائقة السرعة (${latencyMs}ms)`, latencyMs };
  } catch (err: any) {
    let errMsg = err?.message || 'فشل الاتصال بقاعدة البيانات، يرجى التأكد من صحة الرابط والتوكن';
    if (errMsg === 'Failed to fetch' || err instanceof TypeError) {
      errMsg = 'تعذر الاتصال بالقاعدة (Failed to fetch). يرجى التأكد من استخدام رابط الاتصال المباشر بصيغة libsql://your-db-org.turso.io وليس رابط متصفح لوحة التحكم (app.turso.tech)';
    }
    return { ok: false, message: errMsg };
  }
}

/**
 * تحليل نتيجة استعلام Turso وتفتيتها إلى مصفوفة كائنات
 */
export function parseQueryResult(res: any): Record<string, any>[] {
  try {
    const result = res?.results?.[0]?.response?.result;
    if (!result || !result.cols || !result.rows) return [];
    const cols = result.cols.map((c: any) => c.name);
    return result.rows.map((rowArr: any[]) => {
      const obj: Record<string, any> = {};
      rowArr.forEach((cell, idx) => {
        const colName = cols[idx];
        if (typeof cell === 'object' && cell !== null && 'value' in cell) {
          obj[colName] = cell.value;
        } else {
          obj[colName] = cell;
        }
      });
      return obj;
    });
  } catch {
    return [];
  }
}

export interface DatabaseSyncReport {
  id: string;
  name: string;
  url: string;
  rawUrl?: string;
  token: string;
  isPrimary: boolean;
  ok: boolean;
  users: number;
  debtors: number;
  installments: number;
  latencyMs: number;
  matchedWithPrimary: boolean;
  error?: string;
}

/**
 * فحص وتدقيق حالة المزامنة وأعداد السجلات لجميع القواعد المسجلة دفعة واحدة
 */
export async function auditAllDatabasesSync(): Promise<{
  reports: DatabaseSyncReport[];
  allMatched: boolean;
}> {
  const customDbs = getLocalDatabases();

  // تجميع القواعد: الرئيسية + الثانوية المدعومة + المخصصة
  const allTargets: { id: string; name: string; url: string; token: string; rawUrl?: string; isPrimary: boolean }[] = [
    {
      id: 'primary_db',
      name: 'القاعدة الرئيسية (الافتراضية)',
      url: ALDION_DATABASE_CONFIG.url,
      rawUrl: ALDION_DATABASE_CONFIG.rawUrl,
      token: ALDION_DATABASE_CONFIG.token,
      isPrimary: true,
    },
    ...BACKUP_SYNC_DATABASES.map((b, idx) => ({
      id: `backup_db_${idx + 1}`,
      name: b.name,
      url: b.url,
      rawUrl: b.rawUrl,
      token: b.token,
      isPrimary: false,
    })),
    ...customDbs.map((c) => ({
      id: c.id,
      name: c.name,
      url: c.url,
      rawUrl: c.url,
      token: c.token,
      isPrimary: false,
    })),
  ];

  const getCountsForDb = async (url: string, token: string) => {
    const start = Date.now();
    const uRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM users;', []);
    const dRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM debtors;', []);
    const iRes = await queryCustomTursoDirect(url, token, 'SELECT COUNT(*) FROM installments;', []);
    const latencyMs = Date.now() - start;

    const extractVal = (res: any) => {
      const val = res?.results?.[0]?.response?.result?.rows?.[0]?.[0];
      if (typeof val === 'object' && val !== null && 'value' in val) return Number(val.value);
      return Number(val || 0);
    };

    return {
      users: extractVal(uRes),
      debtors: extractVal(dRes),
      installments: extractVal(iRes),
      latencyMs,
    };
  };

  let primaryReport: DatabaseSyncReport | null = null;
  const reports: DatabaseSyncReport[] = [];

  for (const target of allTargets) {
    try {
      const counts = await getCountsForDb(target.url, target.token);
      const isMatched = primaryReport
        ? counts.users === primaryReport.users &&
          counts.debtors === primaryReport.debtors &&
          counts.installments === primaryReport.installments
        : true;

      const report: DatabaseSyncReport = {
        id: target.id,
        name: target.name,
        url: target.url,
        rawUrl: target.rawUrl,
        token: target.token,
        isPrimary: target.isPrimary,
        ok: true,
        users: counts.users,
        debtors: counts.debtors,
        installments: counts.installments,
        latencyMs: counts.latencyMs,
        matchedWithPrimary: isMatched,
      };

      if (target.isPrimary) {
        primaryReport = report;
      }
      reports.push(report);
    } catch (err: any) {
      reports.push({
        id: target.id,
        name: target.name,
        url: target.url,
        rawUrl: target.rawUrl,
        token: target.token,
        isPrimary: target.isPrimary,
        ok: false,
        users: 0,
        debtors: 0,
        installments: 0,
        latencyMs: 0,
        matchedWithPrimary: false,
        error: err?.message || 'فشل الاتصال بالقاعدة',
      });
    }
  }

  const allMatched = reports.every((r) => r.ok && r.matchedWithPrimary);
  return { reports, allMatched };
}

/**
 * فحص الاتصال بكافة القواعد المسجلة بالنظام دفعة واحدة
 */
export async function testAllDatabasesConnection(): Promise<{
  results: { name: string; ok: boolean; message: string; latencyMs?: number }[];
}> {
  const customDbs = getLocalDatabases();
  const allTargets = [
    { name: 'القاعدة الرئيسية (الافتراضية)', url: ALDION_DATABASE_CONFIG.url, token: ALDION_DATABASE_CONFIG.token },
    ...BACKUP_SYNC_DATABASES.map((b) => ({ name: b.name, url: b.url, token: b.token })),
    ...customDbs.map((c) => ({ name: c.name, url: c.url, token: c.token })),
  ];

  const results = [];
  for (const t of allTargets) {
    const res = await testDatabaseConnection(t.url, t.token, true);
    results.push({
      name: t.name,
      ok: res.ok,
      message: res.message,
      latencyMs: res.latencyMs,
    });
  }

  return { results };
}

/**
 * نسخ وتكشيف وصيانة بيانات جميع السجلات من القاعدة الرئيسية إلى جميع القواعد الثانوية
 */
export async function replicateDataToAllDatabases(): Promise<{
  ok: boolean;
  syncedDbsCount: number;
  message: string;
}> {
  const pUrl = ALDION_DATABASE_CONFIG.url;
  const pToken = ALDION_DATABASE_CONFIG.token;

  // 1. قراءة أحدث البيانات الشاملة من القاعدة الرئيسية
  const usersRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM users;', []);
  const debtorsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM debtors;', []);
  const installmentsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM installments;', []);
  const settingsRes = await queryCustomTursoDirect(pUrl, pToken, 'SELECT * FROM user_settings;', []).catch(() => null);

  const users = parseQueryResult(usersRes);
  const debtors = parseQueryResult(debtorsRes);
  const installments = parseQueryResult(installmentsRes);
  const settings = settingsRes ? parseQueryResult(settingsRes) : [];

  const secondaryTargets = [
    ...BACKUP_SYNC_DATABASES,
    ...getLocalDatabases(),
  ];

  let syncedCount = 0;
  for (const target of secondaryTargets) {
    if (!target.url || !target.token) continue;
    try {
      // تهيئة الجداول في القاعدة المستهدفة أولاً
      await initializeCustomTursoDatabase(target.url, target.token);

      // نسخ المستوردين / المستخدمين
      for (const u of users) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO users (id, username, password, role, branch_name, phone_or_email, is_active, is_new_registration, subscription_type, subscription_expires_at, plain_password, allowed_modules, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             username=excluded.username,
             password=excluded.password,
             role=excluded.role,
             branch_name=excluded.branch_name,
             phone_or_email=excluded.phone_or_email,
             is_active=excluded.is_active,
             is_new_registration=excluded.is_new_registration,
             subscription_type=excluded.subscription_type,
             subscription_expires_at=excluded.subscription_expires_at,
             plain_password=excluded.plain_password,
             allowed_modules=excluded.allowed_modules,
             created_at=excluded.created_at;`,
          [
            u.id,
            u.username,
            u.password,
            u.role || 'user',
            u.branch_name || 'الفرع الرئيسي',
            u.phone_or_email || '',
            u.is_active ?? 1,
            u.is_new_registration ?? 0,
            u.subscription_type || 'permanent',
            u.subscription_expires_at || '',
            u.plain_password || '',
            u.allowed_modules || '',
            u.created_at || '',
          ]
        ).catch(() => {});
      }

      // نسخ المدينين
      for (const d of debtors) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO debtors (id, name, phone, amount, status, user_id, created_at, history, last_debt_date)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name,
             phone=excluded.phone,
             amount=excluded.amount,
             status=excluded.status,
             user_id=excluded.user_id,
             created_at=excluded.created_at,
             history=excluded.history,
             last_debt_date=excluded.last_debt_date;`,
          [
            d.id,
            d.name,
            d.phone || '',
            d.amount ?? 0,
            d.status || 'دين مرتفع',
            d.user_id ?? 1,
            d.created_at || '',
            d.history || '',
            d.last_debt_date || '',
          ]
        ).catch(() => {});
      }

      // نسخ الأقساط
      for (const inst of installments) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO installments (id, name, phone, item, total_amount, down_payment, remaining_amount, monthly_installment_amount, registration_date, next_due_date, user_id, status, notes, payments, created_at, national_id, address, guarantor_enabled, guarantor_name, guarantor_address, guarantor_job, guarantor_relation, guarantor_phone)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON CONFLICT(id) DO UPDATE SET
             name=excluded.name,
             phone=excluded.phone,
             item=excluded.item,
             total_amount=excluded.total_amount,
             down_payment=excluded.down_payment,
             remaining_amount=excluded.remaining_amount,
             monthly_installment_amount=excluded.monthly_installment_amount,
             registration_date=excluded.registration_date,
             next_due_date=excluded.next_due_date,
             user_id=excluded.user_id,
             status=excluded.status,
             notes=excluded.notes,
             payments=excluded.payments,
             created_at=excluded.created_at,
             national_id=excluded.national_id,
             address=excluded.address,
             guarantor_enabled=excluded.guarantor_enabled,
             guarantor_name=excluded.guarantor_name,
             guarantor_address=excluded.guarantor_address,
             guarantor_job=excluded.guarantor_job,
             guarantor_relation=excluded.guarantor_relation,
             guarantor_phone=excluded.guarantor_phone;`,
          [
            inst.id,
            inst.name,
            inst.phone || '',
            inst.item || '',
            inst.total_amount ?? 0,
            inst.down_payment ?? 0,
            inst.remaining_amount ?? 0,
            inst.monthly_installment_amount ?? 0,
            inst.registration_date || '',
            inst.next_due_date || '',
            inst.user_id ?? 1,
            inst.status || 'active',
            inst.notes || '',
            inst.payments || '',
            inst.created_at || '',
            inst.national_id || '',
            inst.address || '',
            inst.guarantor_enabled ?? 0,
            inst.guarantor_name || '',
            inst.guarantor_address || '',
            inst.guarantor_job || '',
            inst.guarantor_relation || '',
            inst.guarantor_phone || '',
          ]
        ).catch(() => {});
      }

      // نسخ الإعدادات
      for (const st of settings) {
        await queryCustomTursoDirect(
          target.url,
          target.token,
          `INSERT INTO user_settings (user_id, settings_json, updated_at)
           VALUES (?, ?, ?)
           ON CONFLICT(user_id) DO UPDATE SET settings_json=excluded.settings_json, updated_at=excluded.updated_at;`,
          [st.user_id, st.settings_json, st.updated_at || '']
        ).catch(() => {});
      }

      syncedCount++;
    } catch (e) {
      console.warn(`Error replicating data to target DB (${target.name}):`, e);
    }
  }

  return {
    ok: true,
    syncedDbsCount: syncedCount,
    message: `تم نسخ وتحديث واستنساخ كافة بيانات الديون والأقساط والمستخدمين بنجاح إلى (${syncedCount}) قاعدة ثانوية!`,
  };
}

/**
 * فحص وتدقيق مطابقة أعداد البيانات بين القاعدة الرئيسية والقاعدة الثانوية ببيانات حية
 */
export async function verifyDataSyncMatch(): Promise<{
  ok: boolean;
  primaryCounts: { users: number; debtors: number; installments: number };
  secondaryCounts: { users: number; debtors: number; installments: number };
  matched: boolean;
}> {
  const audit = await auditAllDatabasesSync();
  const primary = audit.reports.find((r) => r.isPrimary);
  const secondary = audit.reports.find((r) => !r.isPrimary && r.ok);

  const primaryCounts = {
    users: primary?.users || 0,
    debtors: primary?.debtors || 0,
    installments: primary?.installments || 0,
  };

  const secondaryCounts = {
    users: secondary?.users || 0,
    debtors: secondary?.debtors || 0,
    installments: secondary?.installments || 0,
  };

  const matched =
    primaryCounts.users === secondaryCounts.users &&
    primaryCounts.debtors === secondaryCounts.debtors &&
    primaryCounts.installments === secondaryCounts.installments;

  return { ok: true, primaryCounts, secondaryCounts, matched };
}

// ---------------------- MULTI-DATABASE REGISTRY HELPERS ----------------------

export function getLocalDatabases(): DatabaseAccount[] {
  try {
    const raw = localStorage.getItem('aldion_database_accounts');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function setLocalDatabases(dbs: DatabaseAccount[]) {
  try {
    localStorage.setItem('aldion_database_accounts', JSON.stringify(dbs));
  } catch (e) {
    console.error("Error saving local databases:", e);
  }
}

export function getActiveUserDatabaseAccount(): DatabaseAccount | null {
  try {
    const user = getLocalSession();
    if (user && user.databaseId) {
      const dbs = getLocalDatabases();
      const found = dbs.find((d) => d.id === user.databaseId);
      if (found && found.url && found.token) {
        return found;
      }
    }
  } catch {}
  return null;
}

export async function fetchDatabasesFromCloud(): Promise<DatabaseAccount[]> {
  try {
    let res;
    try {
      res = await queryEmbeddedEncryptedTurso('SELECT id, name, url, token, description, is_default, created_at FROM databases_registry ORDER BY created_at DESC;', []);
    } catch {
      await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        token TEXT NOT NULL,
        description TEXT,
        is_default INTEGER DEFAULT 0,
        created_at TEXT
      );`, []).catch(() => {});
      return getLocalDatabases();
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }

    const dbs: DatabaseAccount[] = rows.map((r) => ({
      id: r[0]?.value ?? r[0],
      name: r[1]?.value ?? r[1],
      url: r[2]?.value ?? r[2],
      token: r[3]?.value ?? r[3],
      description: r[4]?.value ?? r[4] ?? '',
      isDefault: Boolean(r[5]?.value ?? r[5]),
      createdAt: r[6]?.value ?? r[6],
    }));

    setLocalDatabases(dbs);
    return dbs;
  } catch (e) {
    console.warn("Could not fetch databases from cloud:", e);
    return getLocalDatabases();
  }
}

export async function syncDatabasesToCloud(dbs: DatabaseAccount[]): Promise<void> {
  setLocalDatabases(dbs);
  try {
    await queryEmbeddedEncryptedTurso(`CREATE TABLE IF NOT EXISTS databases_registry (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      url TEXT NOT NULL,
      token TEXT NOT NULL,
      description TEXT,
      is_default INTEGER DEFAULT 0,
      created_at TEXT
    );`, []).catch(() => {});

    for (const dbAccount of dbs) {
      const now = dbAccount.createdAt || new Date().toISOString();
      await queryEmbeddedEncryptedTurso(
        `INSERT INTO databases_registry (id, name, url, token, description, is_default, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?) 
         ON CONFLICT(id) DO UPDATE SET 
           name = excluded.name, 
           url = excluded.url, 
           token = excluded.token, 
           description = excluded.description, 
           is_default = excluded.is_default;`,
        [dbAccount.id, dbAccount.name, dbAccount.url, dbAccount.token, dbAccount.description || '', dbAccount.isDefault ? 1 : 0, now]
      );
    }
  } catch (e) {
    console.warn("Could not sync databases to cloud:", e);
  }
}

export async function deleteDatabaseFromCloud(dbId: string): Promise<void> {
  const current = getLocalDatabases().filter((d) => d.id !== dbId);
  setLocalDatabases(current);

  // 1. Reset any local cached managers assigned to this deleted database to null (default DB)
  try {
    const rawMgrs = localStorage.getItem('local_managers_list');
    if (rawMgrs) {
      const list = JSON.parse(rawMgrs);
      if (Array.isArray(list)) {
        const updatedList = list.map((m: any) => (m.databaseId === dbId ? { ...m, databaseId: null } : m));
        localStorage.setItem('local_managers_list', JSON.stringify(updatedList));
      }
    }
  } catch (e) {
    console.warn("Error updating local managers on db delete:", e);
  }

  // 2. Delete from cloud database registry and reset users assigned to this database
  try {
    await queryEmbeddedEncryptedTurso('DELETE FROM databases_registry WHERE id = ?;', [dbId]);
    await queryEmbeddedEncryptedTurso('UPDATE users SET database_id = NULL WHERE database_id = ?;', [dbId]).catch(() => {});
  } catch (e) {
    console.warn("Could not delete database from cloud:", e);
  }
}

export function isStaticOrNetlifyEnv(): boolean {
  if (typeof window === 'undefined') return false;
  const origin = window.location.origin || '';
  // If on netlify, github.io, capacitor, file, or any non-localhost / non-run.app host
  return !origin.includes('localhost') && !origin.includes('127.0.0.1') && !origin.includes('run.app');
}

/**
 * Enterprise Resilient Database Proxy:
 * 1. إذا كان التطبيق يعمل على Netlify أو استضافة ثابتة أو PWA، يتصل مباشرة بالمحرك المشفر فائق السرعة دون أي تأخير أو خادم وسيط.
 * 2. إذا كان يعمل محلياً في بيئة التطوير، يحاول أولاً الاتصال عبر الخادم المحمي (API Proxy).
 */
export async function queryTurso(sql: string, args: (string | number | null | undefined)[] = []) {
  const trimmedSql = sql.trim();

  // إذا كان المستخدم ينتمي لقاعدة بيانات مخصصة تم تحديدها له من قبل الإدارة العامة
  const customDb = getActiveUserDatabaseAccount();
  if (customDb && customDb.url && customDb.token) {
    return await queryCustomTursoDirect(customDb.url, customDb.token, trimmedSql, args);
  }

  // على Netlify والتطبيقات الخارجية: اتصال فوري ومباشر بالمحرك المشفر السريع
  if (isStaticOrNetlifyEnv()) {
    return await queryEmbeddedEncryptedTurso(trimmedSql, args);
  }

  const baseUrl = getBackendBaseUrl();
  const endpoint = `${baseUrl}/api/turso`;

  const payloadStr = JSON.stringify({ sql: trimmedSql, args });
  const shieldHeaders = generateShieldHeaders(payloadStr);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...shieldHeaders,
      },
      body: payloadStr,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    // إذا أعاد الخادم صفحة HTML أو خطأ توجيه (302/404/PWA Standalone redirect)
    const contentType = res.headers.get('content-type') || '';
    if (!res.ok || !contentType.includes('application/json')) {
      // التحول التلقائي للمحرك المدمج المشفر
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    }

    const data = await res.json();
    if (data.results && data.results[0] && data.results[0].type === 'error') {
      throw new Error(data.results[0].error?.message || 'حدث خطأ في تنفيذ استعلام القاعدة');
    }

    return data;
  } catch (err: any) {
    clearTimeout(timeoutId);
    // إذا تعذر الوصول للخادم بسبب CORS أو انقطاع أو تشغيل في بيئة PWA مستقلة
    try {
      return await queryEmbeddedEncryptedTurso(trimmedSql, args);
    } catch (fallbackErr: any) {
      if (err.name === 'AbortError' || fallbackErr.name === 'AbortError') {
        throw new Error('انتهت مهلة الاتصال بالخادم، يرجى التحقق من اتصال الإنترنت');
      }
      throw fallbackErr || err;
    }
  }
}

// ---------------------- LOCAL STORAGE HELPERS ----------------------

export function getLocalDebtors(userId: number): Debtor[] | null {
  const data = localStorage.getItem(`debtors_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalDebtors(userId: number, debtors: Debtor[]) {
  localStorage.setItem(`debtors_user_${userId}`, JSON.stringify(debtors));
}

// Local Storage for Installments (نظام الأقساط المنفصل)
export function getLocalInstallments(userId: number): InstallmentRecord[] | null {
  const data = localStorage.getItem(`installments_user_${userId}`);
  return data ? JSON.parse(data) : null;
}

export function setLocalInstallments(userId: number, installments: InstallmentRecord[]) {
  localStorage.setItem(`installments_user_${userId}`, JSON.stringify(installments));
}

export function getLocalUsers(): User[] | null {
  try {
    const data = localStorage.getItem("local_users");
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setLocalUsers(users: User[]) {
  try {
    const safeUsers = users.map(({ password: _, ...u }) => u as User);
    localStorage.setItem("local_users", JSON.stringify(safeUsers));
  } catch {}
}

export const DEFAULT_USER: User = {
  id: 1,
  username: 'admin',
  role: 'admin',
  branch_name: 'الفرع الرئيسي',
  isActive: true,
  subscriptionType: 'permanent',
};

export function getLocalSession(): User | null {
  try {
    const data = localStorage.getItem("session_user");
    if (!data) return null;
    const user: User = JSON.parse(data);
    if (!user || !user.id) return null;

    if (user.role !== 'admin' && user.id) {
      const forceLogout = localStorage.getItem(`force_logout_user_${user.id}`);
      if (forceLogout) {
        localStorage.removeItem("session_user");
        return null;
      }
      const managersData = localStorage.getItem("local_managers_list");
      if (managersData) {
        const managers: Manager[] = JSON.parse(managersData);
        const found = managers.find((m) => m.id === user.id);
        if (found) {
          if (found.isActive === false) {
            localStorage.removeItem("session_user");
            return null;
          }
          if (found.subscriptionType) {
            user.subscriptionType = found.subscriptionType;
          }
        }
      }
    }
    if (!user.password) {
      const cachedPass = localStorage.getItem(`user_pwd_${user.id}`) || localStorage.getItem(`user_pwd_${user.username}`);
      if (cachedPass) {
        user.password = cachedPass;
      }
    }
    return user;
  } catch {
    return null;
  }
}

export function setLocalSession(user: User | null) {
  if (user) {
    localStorage.setItem("session_user", JSON.stringify(user));
    if (user.password) {
      localStorage.setItem(`user_pwd_${user.id}`, user.password);
      localStorage.setItem(`user_pwd_${user.username}`, user.password);
    }
  } else {
    localStorage.removeItem("session_user");
  }
}

// Multi-tab synchronization
export const sessionBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('submanager_auth_sync')
    : null;

export const debtorsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('debtors_realtime_sync')
    : null;

export const installmentsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('installments_realtime_sync')
    : null;

export const settingsBroadcastChannel =
  typeof window !== 'undefined' && 'BroadcastChannel' in window
    ? new BroadcastChannel('settings_realtime_sync')
    : null;

export function broadcastDebtorsChange(userId: number, actionType?: string) {
  try {
    if (debtorsBroadcastChannel) {
      debtorsBroadcastChannel.postMessage({
        type: 'DEBTORS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastInstallmentsChange(userId: number, actionType?: string) {
  try {
    if (installmentsBroadcastChannel) {
      installmentsBroadcastChannel.postMessage({
        type: 'INSTALLMENTS_UPDATED',
        userId,
        actionType,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastSettingsChange(userId: number, settings: AppSettings) {
  try {
    if (settingsBroadcastChannel) {
      settingsBroadcastChannel.postMessage({
        type: 'SETTINGS_UPDATED',
        userId,
        settings,
        timestamp: Date.now(),
      });
    }
  } catch {}
}

export function broadcastManagerStatusChange(targetUserId: number, isActive: boolean, reason?: string) {
  try {
    if (!isActive) {
      localStorage.setItem(
        `force_logout_user_${targetUserId}`,
        JSON.stringify({
          timestamp: Date.now(),
          reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
        })
      );
      const current = getLocalSession();
      if (current && current.id === targetUserId) {
        localStorage.removeItem("session_user");
      }
    } else {
      localStorage.removeItem(`force_logout_user_${targetUserId}`);
    }

    if (sessionBroadcastChannel) {
      sessionBroadcastChannel.postMessage({
        type: isActive ? 'MANAGER_ACTIVATED' : 'FORCE_LOGOUT',
        targetUserId,
        reason: reason || 'تم إيقاف حسابك من قبل الإدارة العامة فوراً',
      });
    }
  } catch (e) {
    console.warn('Broadcast error:', e);
  }
}

export function getLocalManagers(): Manager[] | null {
  try {
    const data = localStorage.getItem("local_managers_list");
    return data ? JSON.parse(data) : null;
  } catch {
    return null;
  }
}

export function setLocalManagers(managers: Manager[]) {
  try {
    localStorage.setItem("local_managers_list", JSON.stringify(managers));
  } catch {}
}

export const DEFAULT_SETTINGS: AppSettings = {
  enableDebtAlerts: true,
  alertDaysThreshold: 1,
  highDebtThreshold: 25000,
  numberFormat: 'english',
  language: 'ar',
  currency: 'IQD',
  layoutTheme: 'classic',
  enableUpdateNotice: false,
  updateNoticeMessage: 'يتوفر تحديث جديد للنظام، يرجى اضغط زر تنزيل التحديث الآن لتثبيت النسخة الجديدة.',
  updateNoticeTargetVersion: 'v3.5',
};

export function getLocalSettings(userId: number): AppSettings {
  try {
    const raw = localStorage.getItem(`app_settings_user_${userId}`);
    const globalLang = (localStorage.getItem('dftr_app_language') as any) || 'ar';
    const globalCurr = (localStorage.getItem('dftr_app_currency') as any) || 'IQD';
    const globalNumF = (localStorage.getItem('dftr_app_number_format') as any) || 'english';
    const globalTheme = (localStorage.getItem('dftr_app_theme') as any) || 'classic';

    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enableDebtAlerts: parsed.enableDebtAlerts ?? true,
        alertDaysThreshold: parsed.alertDaysThreshold ?? 1,
        highDebtThreshold: parsed.highDebtThreshold ?? 25000,
        numberFormat: parsed.numberFormat ?? globalNumF,
        language: parsed.language ?? globalLang,
        currency: parsed.currency ?? globalCurr,
        layoutTheme: 'classic',
        enableUpdateNotice: parsed.enableUpdateNotice ?? false,
        updateNoticeMessage: parsed.updateNoticeMessage || 'يتوفر تحديث جديد للنظام، يرجى اضغط زر تنزيل التحديث الآن لتثبيت النسخة الجديدة.',
        updateNoticeTargetVersion: parsed.updateNoticeTargetVersion || 'v3.5',
      };
    }
  } catch (e) {
    console.error("Error reading local settings:", e);
  }
  const globalTheme = (localStorage.getItem('dftr_app_theme') as any) || 'classic';
  return { ...DEFAULT_SETTINGS, layoutTheme: 'classic' };
}

export function setLocalSettings(userId: number, settings: AppSettings) {
  try {
    localStorage.setItem(`app_settings_user_${userId}`, JSON.stringify(settings));
    if (settings.layoutTheme) {
      localStorage.setItem('dftr_app_theme', settings.layoutTheme);
    }
  } catch (e) {
    console.error("Error saving local settings:", e);
  }
}

export function getLocalDebtorDates(userId: number): Record<number, string> {
  try {
    const raw = localStorage.getItem(`debtor_dates_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorDates(userId: number, dates: Record<number, string>) {
  try {
    localStorage.setItem(`debtor_dates_user_${userId}`, JSON.stringify(dates));
  } catch (e) {
    console.error("Error saving debtor dates:", e);
  }
}

export function getLocalDebtorHistory(userId: number): Record<number, DebtorTransaction[]> {
  try {
    const raw = localStorage.getItem(`debtor_history_user_${userId}`);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function setLocalDebtorHistory(userId: number, historyMap: Record<number, DebtorTransaction[]>) {
  try {
    localStorage.setItem(`debtor_history_user_${userId}`, JSON.stringify(historyMap));
  } catch (e) {
    console.error("Error saving debtor history:", e);
  }
}

/**
 * مزامنة الإعدادات (اللغة، العملة، الأرقام، التنبيهات، السقف) سحابياً لكل مستخدم/مدير فرعي
 */
export async function syncSettingsToCloud(userId: number, settings: AppSettings): Promise<void> {
  if (!userId || userId === 999999) return; // الحساب التجريبي محلي فقط
  try {
    const json = JSON.stringify(settings);
    const now = new Date().toISOString();
    await queryTurso(
      `INSERT INTO user_settings (user_id, settings_json, updated_at) 
       VALUES (?, ?, ?) 
       ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
      [userId, json, now]
    );
  } catch (err: any) {
    try {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`);
      const json = JSON.stringify(settings);
      const now = new Date().toISOString();
      await queryTurso(
        `INSERT INTO user_settings (user_id, settings_json, updated_at) 
         VALUES (?, ?, ?) 
         ON CONFLICT(user_id) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at;`,
        [userId, json, now]
      );
    } catch (e) {
      console.warn("Could not sync settings to cloud:", e);
    }
  }
}

/**
 * جلب الإعدادات السحابية للمستخدم عند تسجيل الدخول أو فتح الحساب من جهاز آخر
 */
export async function fetchSettingsFromCloud(userId: number): Promise<AppSettings | null> {
  if (!userId || userId === 999999) return null;
  try {
    let res;
    try {
      res = await queryTurso(
        `SELECT settings_json FROM user_settings WHERE user_id = ? LIMIT 1;`,
        [userId]
      );
    } catch {
      await queryTurso(`CREATE TABLE IF NOT EXISTS user_settings (
        user_id INTEGER PRIMARY KEY,
        settings_json TEXT NOT NULL,
        updated_at TEXT
      );`).catch(() => {});
      return null;
    }

    let rows: any[] = [];
    if (res?.results && res.results[0] && res.results[0].response?.result?.rows) {
      rows = res.results[0].response.result.rows;
    }
    if (rows.length > 0 && rows[0][0]) {
      const val = rows[0][0]?.value ?? rows[0][0];
      if (typeof val === 'string') {
        return JSON.parse(val) as AppSettings;
      }
    }
  } catch (err) {
    console.warn("Could not fetch settings from cloud:", err);
  }
  return null;
}

